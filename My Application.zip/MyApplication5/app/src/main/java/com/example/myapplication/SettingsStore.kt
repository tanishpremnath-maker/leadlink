package com.example.myapplication

import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "lead_link_settings")

object SettingsStore {
    private val BG_OPACITY = floatPreferencesKey("bg_opacity")
    private val PRIMARY_COLOR = intPreferencesKey("primary_color")
    private val HIGH_CONTRAST = booleanPreferencesKey("high_contrast")
    private val TEXT_SIZE = floatPreferencesKey("text_size_multiplier")
    private val SIMPLIFIED_UI = booleanPreferencesKey("simplified_ui")
    private val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
    private val PUBLIC_PROFILE = booleanPreferencesKey("public_profile")

    private const val DEFAULT_BG = 0.9f
    private val DEFAULT_PRIMARY_INT = 0xFFFFB800.toInt()
    private const val DEFAULT_HIGH_CONTRAST = false
    private const val DEFAULT_TEXT_SIZE = 1.0f
    private const val DEFAULT_SIMPLIFIED = false
    private const val DEFAULT_NOTIFICATIONS = true
    private const val DEFAULT_PUBLIC = true

    fun bgOpacityFlow(context: Context): Flow<Float> =
        context.dataStore.data.map { it[BG_OPACITY] ?: DEFAULT_BG }

    suspend fun saveBgOpacity(context: Context, value: Float) {
        context.dataStore.edit { it[BG_OPACITY] = value }
    }

    fun primaryColorFlow(context: Context): Flow<Color> =
        context.dataStore.data.map { Color(it[PRIMARY_COLOR] ?: DEFAULT_PRIMARY_INT) }

    suspend fun savePrimaryColor(context: Context, color: Color) {
        context.dataStore.edit { it[PRIMARY_COLOR] = color.toArgb() }
    }

    fun highContrastFlow(context: Context): Flow<Boolean> =
        context.dataStore.data.map { it[HIGH_CONTRAST] ?: DEFAULT_HIGH_CONTRAST }

    suspend fun saveHighContrast(context: Context, value: Boolean) {
        context.dataStore.edit { it[HIGH_CONTRAST] = value }
    }

    fun textSizeFlow(context: Context): Flow<Float> =
        context.dataStore.data.map { it[TEXT_SIZE] ?: DEFAULT_TEXT_SIZE }

    suspend fun saveTextSize(context: Context, value: Float) {
        context.dataStore.edit { it[TEXT_SIZE] = value }
    }

    fun simplifiedUiFlow(context: Context): Flow<Boolean> =
        context.dataStore.data.map { it[SIMPLIFIED_UI] ?: DEFAULT_SIMPLIFIED }

    suspend fun saveSimplifiedUi(context: Context, value: Boolean) {
        context.dataStore.edit { it[SIMPLIFIED_UI] = value }
    }

    fun notificationsEnabledFlow(context: Context): Flow<Boolean> =
        context.dataStore.data.map { it[NOTIFICATIONS_ENABLED] ?: DEFAULT_NOTIFICATIONS }

    suspend fun saveNotificationsEnabled(context: Context, value: Boolean) {
        context.dataStore.edit { it[NOTIFICATIONS_ENABLED] = value }
    }

    fun publicProfileFlow(context: Context): Flow<Boolean> =
        context.dataStore.data.map { it[PUBLIC_PROFILE] ?: DEFAULT_PUBLIC }

    suspend fun savePublicProfile(context: Context, value: Boolean) {
        context.dataStore.edit { it[PUBLIC_PROFILE] = value }
    }
}
