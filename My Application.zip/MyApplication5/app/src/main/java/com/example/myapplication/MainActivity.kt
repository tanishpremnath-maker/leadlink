//fix
package com.example.myapplication

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.layout.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import kotlin.math.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import kotlinx.coroutines.launch
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.myapplication.ui.theme.MyApplicationTheme
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.delay
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Removed enableEdgeToEdge() to prevent content from going under status bar

        // Create notification channel
        createNotificationChannel()

        setContent {
            MyApplicationTheme {
                MainScreen()
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelId = "chat_messages"
            val name = "Chat Messages"
            val descriptionText = "Notifications for new chat messages"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(channelId, name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }
}

fun sendMessageNotification(context: Context, senderName: String, message: String) {
    try {
        val notificationId = System.currentTimeMillis().toInt()
        val builder = NotificationCompat.Builder(context, "chat_messages")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("New message from $senderName")
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)

        val notificationManager = NotificationManagerCompat.from(context)
        try {
            notificationManager.notify(notificationId, builder.build())
        } catch (e: SecurityException) {
            // Permission denied on Android 13+
            android.util.Log.e("Notification", "Permission not granted", e)
        }
    } catch (e: Exception) {
        android.util.Log.e("Notification", "Error showing notification", e)
    }
}

data class CompetitionReminder(
    val name: String = "",
    val date: String = "",
    val timestamp: Long = 0L
)

data class UserProfile(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val school: String = "",
    val year: String = "",
    val state: String = "",
    val bio: String = "",
    val pfpUrl: String = "",
    val reminders: List<CompetitionReminder> = emptyList(),
    val instagram: String = "",
    val twitter: String = "",
    val facebook: String = "",
    val linkedin: String = ""
)

data class ConnectionRequest(
    val id: String = "",
    val fromUid: String = "",
    val fromName: String = "",
    val fromEmail: String = "",
    val fromSchool: String = "",
    val fromPfpUrl: String = "",
    val toUid: String = "",
    val toName: String = "",
    val status: String = "pending", // pending, accepted, declined
    val timestamp: Long = 0L
)

data class Connection(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val school: String = "",
    val year: String = "",
    val state: String = "",
    val pfpUrl: String = "",
    val reminders: List<CompetitionReminder> = emptyList(),
    val instagram: String = "",
    val twitter: String = "",
    val facebook: String = "",
    val linkedin: String = ""
)

data class ChatMessage(
    val id: String = "",
    val senderId: String = "",
    val receiverId: String = "",
    val message: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val senderName: String = ""
)

data class Conversation(
    val otherUserId: String = "",
    val otherUserName: String = "",
    val otherUserPfp: String = "",
    val lastMessage: String = "",
    val lastMessageTime: Long = 0,
    val unreadCount: Int = 0
)

data class TwoFactorCode(
    val code: String = "",
    val email: String = "",
    val expiresAt: Long = 0L,
    val verified: Boolean = false
)

@Composable
fun AuthScreen(onLoginSuccess: () -> Unit, onBack: () -> Unit, lightMode: Boolean = false) {
    // Inverted colors for this screen
    val bgColor = invertColorValues(Color.Black, lightMode)
    val iconBg = invertColorValues(Color(0xFFFFB800), lightMode)
    val textColor = invertColorValues(Color.White, lightMode)
    val textFaded = textColor.copy(alpha = 0.6f)
    val textMoreFaded = textColor.copy(alpha = 0.5f)
    val inputBorder = textColor.copy(alpha = 0.3f)
    val errorColor = invertColorValues(Color.Red, lightMode)

    var isLogin by remember { mutableStateOf(true) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var school by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }
    var statePref by remember { mutableStateOf("") }

    var isLoading by remember { mutableStateOf(false) }
    var show2FAVerification by remember { mutableStateOf(false) }
    var generated2FACode by remember { mutableStateOf("") }
    var userEmailFor2FA by remember { mutableStateOf("") }

    val context = LocalContext.current
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    val scope = rememberCoroutineScope()

    if (show2FAVerification) {
        TwoFactorVerificationScreen(
            email = userEmailFor2FA,
            expectedCode = generated2FACode,
            onVerified = {
                show2FAVerification = false
                onLoginSuccess()
            },
            onBack = {
                show2FAVerification = false
                auth.signOut()
                Toast.makeText(context, "Login cancelled", Toast.LENGTH_SHORT).show()
            }
        )
        return
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.fbla_bg),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.9f)))

        IconButton(onClick = onBack, modifier = Modifier.padding(top = 40.dp, start = 16.dp)) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            item {
                Icon(Icons.Default.AccountCircle, null, modifier = Modifier.size(80.dp), tint = Color(0xFFFFB800))
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = if (isLogin) "WELCOME TO LEADLINK" else "JOIN LEADLINK",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White,
                    fontWeight = FontWeight.Black
                )
                Spacer(modifier = Modifier.height(32.dp))

                if (!isLogin) {
                    AuthTextField(value = name, onValueChange = { name = it }, label = "Full Name")
                    Spacer(modifier = Modifier.height(12.dp))
                    AuthTextField(value = school, onValueChange = { school = it }, label = "School Name")
                    Spacer(modifier = Modifier.height(12.dp))
                    YearDropdown(selectedYear = year, onYearSelected = { year = it })
                    Spacer(modifier = Modifier.height(12.dp))
                    StateDropdown(selectedState = statePref, onStateSelected = { statePref = it })
                    Spacer(modifier = Modifier.height(12.dp))
                }

                AuthTextField(value = email, onValueChange = { email = it }, label = "Email Address")
                Spacer(modifier = Modifier.height(12.dp))
                AuthTextField(value = password, onValueChange = { password = it }, label = "Password", isPassword = true)
                if (!isLogin) {
                    Spacer(modifier = Modifier.height(12.dp))
                    AuthTextField(value = confirmPassword, onValueChange = { confirmPassword = it }, label = "Confirm Password", isPassword = true)
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = {
                        if (email.isEmpty() || password.isEmpty() || (!isLogin && (name.isEmpty() || school.isEmpty()))) {
                            Toast.makeText(context, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        if (!isLogin && password != confirmPassword) {
                            Toast.makeText(context, "Passwords do not match", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        isLoading = true
                        if (isLogin) {
                            auth.signInWithEmailAndPassword(email, password).addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    // Generate 6-digit 2FA code
                                    val code = (100000..999999).random().toString()
                                    generated2FACode = code
                                    userEmailFor2FA = email

                                    scope.launch {
                                        try {
                                            // Store code in Firestore (expires in 5 minutes)
                                            val twoFactorCode = TwoFactorCode(
                                                code = code,
                                                email = email,
                                                expiresAt = System.currentTimeMillis() + (5 * 60 * 1000),
                                                verified = false
                                            )
                                            db.collection("twoFactorCodes").document(email).set(twoFactorCode).await()

                                            // Proceed to 2FA verification
                                            isLoading = false
                                            show2FAVerification = true
                                        } catch (e: Exception) {
                                            isLoading = false
                                            Toast.makeText(context, "Error generating code: ${e.message}", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                } else {
                                    isLoading = false
                                    Toast.makeText(context, "Error: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        } else {
                            auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    val profile = UserProfile(uid = auth.currentUser?.uid ?: "", name = name, email = email, school = school, year = year, state = statePref)
                                    db.collection("users").document(auth.currentUser!!.uid).set(profile)
                                        .addOnSuccessListener { onLoginSuccess() }
                                        .addOnFailureListener { isLoading = false }
                                } else {
                                    isLoading = false
                                    Toast.makeText(context, "Error: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp).shadow(4.dp, RoundedCornerShape(12.dp)),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB800)),
                    shape = RoundedCornerShape(12.dp),
                    enabled = !isLoading
                ) {
                    if (isLoading) CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(24.dp))
                    else Text(if (isLogin) "SIGN IN" else "REGISTER", color = Color.Black, fontWeight = FontWeight.Bold)
                }

                TextButton(onClick = { isLogin = !isLogin }) {
                    Text(if (isLogin) "New here? Create an account" else "Have an account? Sign in", color = Color(0xFFFFB800))
                }
            }
        }
    }
}

@Composable
fun TwoFactorVerificationScreen(email: String, expectedCode: String, onVerified: () -> Unit, onBack: () -> Unit) {
    var enteredCode by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    val context = LocalContext.current
    val db = FirebaseFirestore.getInstance()
    val scope = rememberCoroutineScope()

    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.fbla_bg),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.9f)))

        IconButton(onClick = onBack, modifier = Modifier.padding(top = 40.dp, start = 16.dp)) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
        }

        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Default.Lock, null, modifier = Modifier.size(80.dp), tint = Color(0xFFFFB800))
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "TWO-FACTOR AUTHENTICATION",
                style = MaterialTheme.typography.headlineMedium,
                color = Color.White,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "A 6-digit verification code has been sent to:",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.7f),
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = email,
                style = MaterialTheme.typography.bodyLarge,
                color = Color(0xFFFFB800),
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(32.dp))

            OutlinedTextField(
                value = enteredCode,
                onValueChange = {
                    if (it.length <= 6 && it.all { char -> char.isDigit() }) {
                        enteredCode = it
                        errorMessage = ""
                    }
                },
                label = { Text("Enter 6-Digit Code", color = Color.White.copy(alpha = 0.7f)) },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedTextColor = Color.White,
                    focusedTextColor = Color.White,
                    unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
                    focusedBorderColor = Color(0xFFFFB800)
                ),
                textStyle = MaterialTheme.typography.headlineMedium.copy(
                    letterSpacing = 8.sp,
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Bold
                ),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            if (errorMessage.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = errorMessage,
                    color = Color.White,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    if (enteredCode.length != 6) {
                        errorMessage = "Please enter a 6-digit code"
                        return@Button
                    }

                    isLoading = true
                    scope.launch {
                        try {
                            val doc = db.collection("twoFactorCodes").document(email).get().await()
                            val storedCode = doc.toObject(TwoFactorCode::class.java)

                            if (storedCode == null) {
                                errorMessage = "No verification code found. Please try again."
                                isLoading = false
                            } else if (storedCode.expiresAt < System.currentTimeMillis()) {
                                errorMessage = "Code expired. Please request a new one."
                                isLoading = false
                            } else if (storedCode.code != enteredCode) {
                                errorMessage = "Invalid code. Please try again."
                                isLoading = false
                            } else {
                                // Code is valid!
                                db.collection("twoFactorCodes").document(email).delete().await()
                                Toast.makeText(context, "Verified successfully!", Toast.LENGTH_SHORT).show()
                                onVerified()
                            }
                        } catch (e: Exception) {
                            errorMessage = "Verification failed: ${e.message}"
                            isLoading = false
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp).shadow(4.dp, RoundedCornerShape(12.dp)),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB800)),
                shape = RoundedCornerShape(12.dp),
                enabled = !isLoading && enteredCode.length == 6
            ) {
                if (isLoading) {
                    CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(24.dp))
                } else {
                    Text("VERIFY", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Code expires in 5 minutes",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.5f)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // View verification code option
            var showCode by remember { mutableStateOf(false) }

            OutlinedButton(
                onClick = { showCode = !showCode },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = Color(0xFFFFB800)
                ),
                border = BorderStroke(2.dp, Color(0xFFFFB800)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = if (showCode) Icons.Default.Close else Icons.Default.Info,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (showCode) "Hide Code" else "View Verification Code",
                    fontWeight = FontWeight.Bold
                )
            }

            if (showCode) {
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A)),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(2.dp, Color(0xFFFFB800))
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Your Verification Code",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = expectedCode,
                            color = Color(0xFFFFB800),
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 8.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Enter this code above to verify",
                            color = Color.White.copy(alpha = 0.5f),
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AuthTextField(value: String, onValueChange: (String) -> Unit, label: String, isPassword: Boolean = false) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        visualTransformation = if (isPassword) PasswordVisualTransformation() else VisualTransformation.None,
        colors = OutlinedTextFieldDefaults.colors(
            unfocusedTextColor = Color.White,
            focusedTextColor = Color.White,
            unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
            focusedBorderColor = Color(0xFFFFB800)
        ),
        shape = RoundedCornerShape(12.dp)
    )
}

data class FblaEvent(val name: String, val date: String, val location: String, val timestamp: Long = 0L)
data class NewsArticle(val title: String, val summary: String, val date: String, val url: String, val tag: String = "NATIONAL", val timestamp: Long = 0L)
data class ResourceItem(val title: String, val description: String, val url: String, val icon: ImageVector)

// Helper function to parse event dates
fun parseEventDates(eventDateString: String): List<String> {
    val dates = mutableListOf<String>()

    // Patterns to match: "April 9–10, 2026", "June 29 - July 2, 2026", "Feb 7, 2026", etc.
    val patterns = listOf(
        // Single day: "Feb 7, 2026"
        Regex("""(\w+)\s+(\d+),\s+(\d{4})"""),
        // Date range same month: "April 9–10, 2026" or "April 9-10, 2026"
        Regex("""(\w+)\s+(\d+)[–-](\d+),\s+(\d{4})"""),
        // Date range different months: "June 29 - July 2, 2026"
        Regex("""(\w+)\s+(\d+)\s*[-–]\s*(\w+)\s+(\d+),\s+(\d{4})""")
    )

    val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }
    val parseFormat = SimpleDateFormat("MMMM d, yyyy", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    try {
        // Try single day pattern
        patterns[0].find(eventDateString)?.let { match ->
            val (month, day, year) = match.destructured
            val dateStr = "$month $day, $year"
            parseFormat.parse(dateStr)?.let { parsedDate ->
                dates.add(dateFormat.format(parsedDate))
            }
            return dates
        }

        // Try same-month range pattern
        patterns[1].find(eventDateString)?.let { match ->
            val (month, startDay, endDay, year) = match.destructured
            val start = startDay.toInt()
            val end = endDay.toInt()

            for (day in start..end) {
                val dateStr = "$month $day, $year"
                parseFormat.parse(dateStr)?.let { parsedDate ->
                    dates.add(dateFormat.format(parsedDate))
                }
            }
            return dates
        }

        // Try different-month range pattern
        patterns[2].find(eventDateString)?.let { match ->
            val (startMonth, startDay, endMonth, endDay, year) = match.destructured

            // Parse start and end dates
            val startDateStr = "$startMonth $startDay, $year"
            val endDateStr = "$endMonth $endDay, $year"

            val startDate = parseFormat.parse(startDateStr)
            val endDate = parseFormat.parse(endDateStr)

            if (startDate != null && endDate != null) {
                val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
                cal.time = startDate

                while (!cal.time.after(endDate)) {
                    dates.add(dateFormat.format(cal.time))
                    cal.add(Calendar.DAY_OF_MONTH, 1)
                }
            }
            return dates
        }
    } catch (e: Exception) {
        // If parsing fails, return empty list
    }

    return dates
}

// Animated button modifier for press effect
@Composable
fun Modifier.animatedClickable(
    onClick: () -> Unit
): Modifier {
    var isPressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.95f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "button_scale"
    )

    return this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null
        ) {
            onClick()
        }
        .pointerInput(Unit) {
            detectTapGestures(
                onPress = {
                    isPressed = true
                    tryAwaitRelease()
                    isPressed = false
                }
            )
        }
}

// Helper function to invert color lightness values (light ↔ dark)
fun invertColorValues(color: Color, invert: Boolean): Color {
    if (!invert) return color
    return Color(
        red = 1f - color.red,
        green = 1f - color.green,
        blue = 1f - color.blue,
        alpha = color.alpha
    )
}

@Composable
fun MainScreen() {
    var selectedTab by remember { mutableIntStateOf(2) }
    val auth = FirebaseAuth.getInstance()
    var currentUser by remember { mutableStateOf(auth.currentUser) }
    var showAuthFlow by remember { mutableStateOf(false) }
    var currentSubScreen by remember { mutableStateOf<String?>(null) }

    // User profile data for ResourcesScreen
    val db = FirebaseFirestore.getInstance()
    var userState by remember { mutableStateOf("") }
    var userSchool by remember { mutableStateOf("") }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Load user profile data
    LaunchedEffect(auth.currentUser?.uid) {
        val uid = auth.currentUser?.uid
        if (uid != null) {
            db.collection("users").document(uid).addSnapshotListener { snapshot, _ ->
                val profile = snapshot?.toObject(UserProfile::class.java)
                userState = profile?.state ?: ""
                userSchool = profile?.school ?: ""
            }
        }
    }

    // Persisted settings
    val bgOpacity by SettingsStore.bgOpacityFlow(context).collectAsState(initial = 0.9f)
    val lightMode = false // ALWAYS DARK MODE - forced
    val primaryColor by SettingsStore.primaryColorFlow(context).collectAsState(initial = Color(0xFFFFB800))
    val savedColors by SettingsStore.savedColorsFlow(context).collectAsState(initial = listOf())
    val textSizeMultiplier by SettingsStore.textSizeFlow(context).collectAsState(initial = 1.0f)
    val isSimplifiedUI by SettingsStore.simplifiedUiFlow(context).collectAsState(initial = false)
    val notificationsEnabled by SettingsStore.notificationsEnabledFlow(context).collectAsState(initial = true)
    val publicProfile by SettingsStore.publicProfileFlow(context).collectAsState(initial = true)

    val effectivePrimary = primaryColor
    val effectiveBgOpacity = bgOpacity

    val effectivePrimaryColor = invertColorValues(effectivePrimary, lightMode)

    // Dynamic navigation bar colors
    val navBarBgColor = if (lightMode) Color(0xFFF5F5F5) else Color(0xFF000D1A)
    val navBarContentColor = if (lightMode) Color.Black else Color.White

    Scaffold(
        bottomBar = {
            if (currentSubScreen == null) {
                NavigationBar(containerColor = navBarBgColor, contentColor = navBarContentColor) {
                    listOf(
                        Triple(0, Icons.Filled.Person, "Profile"),
                        Triple(1, Icons.Filled.Event, "Events"),
                        Triple(2, Icons.Filled.Home, "Home"),
                        Triple(3, Icons.AutoMirrored.Filled.Article, "News"),
                        Triple(4, Icons.AutoMirrored.Filled.MenuBook, "Resources")
                    ).forEach { (index, icon, label) ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, style = TextStyle(fontSize = (12 * textSizeMultiplier).sp)) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = effectivePrimaryColor,
                                selectedTextColor = effectivePrimaryColor,
                                unselectedIconColor = navBarContentColor.copy(alpha = 0.4f),
                                unselectedTextColor = navBarContentColor.copy(alpha = 0.4f),
                                indicatorColor = navBarContentColor.copy(alpha = 0.1f)
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        Crossfade(
            targetState = if (currentSubScreen != null) "subscreen" to currentSubScreen else "main" to selectedTab,
            animationSpec = tween(durationMillis = 600, easing = LinearEasing),
            label = "screen_transition",
            modifier = Modifier.fillMaxSize()
        ) { (screenType, screenId) ->
            Box(
                modifier = Modifier
                    .padding(if (screenType == "subscreen") PaddingValues(0.dp) else padding)
                    .fillMaxSize()
            ) {
                if (screenType == "subscreen") {
                    when {
                        screenId == "find_links" -> MemberSearchScreen(onBack = { currentSubScreen = null }, primaryColor = effectivePrimaryColor, bgOpacity = effectiveBgOpacity, isSimplifiedUI = isSimplifiedUI, textSizeMultiplier = textSizeMultiplier, lightMode = lightMode)
                        screenId == "connection_requests" -> ConnectionRequestsScreen(onBack = { currentSubScreen = null }, primaryColor = effectivePrimaryColor, bgOpacity = effectiveBgOpacity, isSimplifiedUI = isSimplifiedUI, textSizeMultiplier = textSizeMultiplier, lightMode = lightMode)
                        screenId == "my_connections" -> MyConnectionsScreen(onBack = { currentSubScreen = null }, primaryColor = effectivePrimaryColor, bgOpacity = effectiveBgOpacity, isSimplifiedUI = isSimplifiedUI, textSizeMultiplier = textSizeMultiplier, lightMode = lightMode)
                        screenId == "messages" -> MessagesScreen(
                            primaryColor = effectivePrimaryColor,
                            bgOpacity = effectiveBgOpacity,
                            isSimplifiedUI = isSimplifiedUI,
                            textSizeMultiplier = textSizeMultiplier,
                            lightMode = lightMode,
                            onBack = { currentSubScreen = null },
                            onOpenChat = { userId, userName ->
                                currentSubScreen = "chat_$userId"
                            }
                        )
                        screenId is String && screenId.startsWith("chat_") -> {
                            val otherUserId = screenId.removePrefix("chat_")
                            ChatScreen(
                                otherUserId = otherUserId,
                                onBack = { currentSubScreen = null },
                                primaryColor = effectivePrimaryColor,
                                bgOpacity = effectiveBgOpacity,
                                isSimplifiedUI = isSimplifiedUI,
                                textSizeMultiplier = textSizeMultiplier,
                                lightMode = lightMode
                            )
                        }
                    }
                } else {
                    when (screenId as Int) {
                        0 -> {
                            if (currentUser == null) {
                                if (showAuthFlow) {
                                    AuthScreen(
                                        onLoginSuccess = {
                                            currentUser = auth.currentUser
                                            showAuthFlow = false
                                        },
                                        onBack = { showAuthFlow = false },
                                        lightMode = lightMode
                                    )
                                } else {
                                    LoggedOutProfileScreen(onLoginClick = { showAuthFlow = true }, primaryColor = effectivePrimaryColor, bgOpacity = effectiveBgOpacity, isSimplifiedUI = isSimplifiedUI, lightMode = lightMode)
                                }
                            } else {
                                ProfileScreen(
                                    onLogout = {
                                        auth.signOut()
                                        currentUser = null
                                    },
                                    onFindLinksClick = { currentSubScreen = "find_links" },
                                    onConnectionRequestsClick = { currentSubScreen = "connection_requests" },
                                    onMyConnectionsClick = { currentSubScreen = "my_connections" },
                                    onMessagesClick = { currentSubScreen = "messages" },
                                    lightMode = lightMode,
                                    onLightModeChange = { scope.launch { SettingsStore.saveLightMode(context, it) } },
                                    bgOpacity = bgOpacity,
                                    onBgOpacityChange = { scope.launch { SettingsStore.saveBgOpacity(context, it) } },
                                    primaryColor = primaryColor,
                                    onPrimaryColorChange = { scope.launch { SettingsStore.savePrimaryColor(context, it) } },
                                    savedColors = savedColors,
                                    onSavedColorsChange = { scope.launch { SettingsStore.saveSavedColors(context, it) } },
                                    textSizeMultiplier = textSizeMultiplier,
                                    onTextSizeChange = { scope.launch { SettingsStore.saveTextSize(context, it) } },
                                    isSimplifiedUI = isSimplifiedUI,
                                    onSimplifiedUIChange = { scope.launch { SettingsStore.saveSimplifiedUi(context, it) } },
                                    notificationsEnabled = notificationsEnabled,
                                    onNotificationsChange = { scope.launch { SettingsStore.saveNotificationsEnabled(context, it) } },
                                    publicProfile = publicProfile,
                                    onPublicProfileChange = { scope.launch { SettingsStore.savePublicProfile(context, it) } }
                                )
                            }
                        }
                        1 -> EventsPlaceholder(effectivePrimary, effectiveBgOpacity, isSimplifiedUI, textSizeMultiplier, lightMode)
                        2 -> HomeScreen(
                            primaryColor = effectivePrimaryColor,
                            bgOpacity = effectiveBgOpacity,
                            isSimplifiedUI = isSimplifiedUI,
                            textSizeMultiplier = textSizeMultiplier,
                            lightMode = lightMode,
                            onNavigate = { tab, subScreen ->
                                selectedTab = tab
                                currentSubScreen = subScreen
                            }
                        )
                        3 -> NewsScreen(effectivePrimary, effectiveBgOpacity, isSimplifiedUI, textSizeMultiplier, lightMode)
                        4 -> ResourcesScreen(effectivePrimary, effectiveBgOpacity, isSimplifiedUI, textSizeMultiplier, lightMode, userState, userSchool)
                    }
                }
            }
        }
    }
}

@Composable
fun LoggedOutProfileScreen(onLoginClick: () -> Unit, primaryColor: Color, bgOpacity: Float, isSimplifiedUI: Boolean, lightMode: Boolean = false) {
    // Dynamic text color
    val textColor = if (lightMode) Color.Black else Color.White
    val textColorSecondary = if (lightMode) Color.Black.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.6f)
    val textColorTertiary = if (lightMode) Color.Black.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.5f)

    val white = textColor
    val black = if (lightMode) Color.White else Color.Black

    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        // Background overlay logic based on light/dark mode
        if (lightMode) {
            // Light mode: only white overlay
            Box(modifier = Modifier.fillMaxSize().background(Color.White.copy(alpha = bgOpacity)))
        } else {
            // Dark mode: only black overlay
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgOpacity)))
        }
        Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(Icons.Default.AccountCircle, null, modifier = Modifier.size(100.dp), tint = textColorSecondary.copy(alpha = 0.3f))
            Spacer(modifier = Modifier.height(24.dp))
            Text("Sign in to view your profile", color = textColorSecondary)
            Spacer(modifier = Modifier.height(24.dp))
            Button(
                onClick = onLoginClick,
                colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.width(200.dp).height(50.dp)
            ) {
                Text("LOGIN OR SIGNUP", color = if (primaryColor == Color.White) Color.Black else Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun ProfileScreen(
    onLogout: () -> Unit,
    onFindLinksClick: () -> Unit,
    onConnectionRequestsClick: () -> Unit,
    onMyConnectionsClick: () -> Unit,
    onMessagesClick: () -> Unit,
    lightMode: Boolean,
    onLightModeChange: (Boolean) -> Unit,
    bgOpacity: Float,
    onBgOpacityChange: (Float) -> Unit,
    primaryColor: Color,
    onPrimaryColorChange: (Color) -> Unit,
    savedColors: List<Int>,
    onSavedColorsChange: (List<Int>) -> Unit,
    textSizeMultiplier: Float,
    onTextSizeChange: (Float) -> Unit,
    isSimplifiedUI: Boolean,
    onSimplifiedUIChange: (Boolean) -> Unit,
    notificationsEnabled: Boolean,
    onNotificationsChange: (Boolean) -> Unit,
    publicProfile: Boolean,
    onPublicProfileChange: (Boolean) -> Unit
) {
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    val context = LocalContext.current

    var profile by remember { mutableStateOf<UserProfile?>(null) }
    var isEditing by remember { mutableStateOf(false) }
    var isProcessingImage by remember { mutableStateOf(false) }
    var unreadMessageCount by remember { mutableStateOf(0) }
    var unreadMessagesFrom by remember { mutableStateOf<List<String>>(emptyList()) }
    var showUnreadDialog by remember { mutableStateOf(false) }

    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var school by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }
    var statePref by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    var pfpUrl by remember { mutableStateOf("") }
    var instagram by remember { mutableStateOf("") }
    var twitter by remember { mutableStateOf("") }
    var facebook by remember { mutableStateOf("") }
    var linkedin by remember { mutableStateOf("") }

    var instagramError by remember { mutableStateOf("") }
    var twitterError by remember { mutableStateOf("") }
    var facebookError by remember { mutableStateOf("") }
    var linkedinError by remember { mutableStateOf("") }

    var connectionCount by remember { mutableIntStateOf(0) }
    var pendingRequestsCount by remember { mutableIntStateOf(0) }

    // Color picker state
    var showColorPicker by remember { mutableStateOf(false) }
    var pickerHue by remember { mutableFloatStateOf(45f) }
    var pickerSaturation by remember { mutableFloatStateOf(1f) }
    var pickerValue by remember { mutableFloatStateOf(1f) }

    // Delete account state
    var showDeleteDialog by remember { mutableStateOf(false) }
    var deleteConfirmText by remember { mutableStateOf("") }

    // About dialog state
    var showAboutDialog by remember { mutableStateOf(false) }

    val effectivePrimary = primaryColor
    val effectiveBgOpacity = bgOpacity

    val effectivePrimaryColor = invertColorValues(effectivePrimary, lightMode)

    // Calculate dynamic text color based on mode and brightness
    val textColor = if (lightMode) {
        // In light mode, use dark text when background is light
        if (bgOpacity > 0.5f) Color.Black else Color.Black.copy(alpha = 0.9f)
    } else {
        // In dark mode, use white text
        Color.White
    }

    val textColorSecondary = if (lightMode) {
        Color.Black.copy(alpha = 0.6f)
    } else {
        Color.White.copy(alpha = 0.6f)
    }

    val textColorTertiary = if (lightMode) {
        Color.Black.copy(alpha = 0.5f)
    } else {
        Color.White.copy(alpha = 0.5f)
    }

    val pfpLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            isProcessingImage = true
            try {
                val inputStream = context.contentResolver.openInputStream(it)
                val bitmap = BitmapFactory.decodeStream(inputStream)
                val resized = Bitmap.createScaledBitmap(bitmap, 200, 200, true)
                val outputStream = ByteArrayOutputStream()
                resized.compress(Bitmap.CompressFormat.JPEG, 70, outputStream)
                val bytes = outputStream.toByteArray()
                val base64String = "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.DEFAULT)
                pfpUrl = base64String
                db.collection("users").document(auth.currentUser!!.uid).update("pfpUrl", pfpUrl)
                isProcessingImage = false
                Toast.makeText(context, "Profile Picture Updated!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                isProcessingImage = false
                Toast.makeText(context, "Failed to process image", Toast.LENGTH_SHORT).show()
            }
        }
    }

    LaunchedEffect(Unit) {
        val uid = auth.currentUser?.uid
        if (uid != null) {
            db.collection("users").document(uid).addSnapshotListener { snapshot, error ->
                if (error != null) return@addSnapshotListener
                val data = snapshot?.toObject(UserProfile::class.java)
                profile = data
                if (data != null && !isEditing) {
                    name = data.name
                    email = data.email.ifEmpty { auth.currentUser?.email ?: "" }
                    school = data.school
                    year = data.year
                    statePref = data.state
                    bio = data.bio
                    pfpUrl = data.pfpUrl
                    instagram = data.instagram
                    twitter = data.twitter
                    facebook = data.facebook
                    linkedin = data.linkedin
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        val uid = auth.currentUser?.uid
        if (uid != null) {
            // Listen for pending connection requests
            db.collection("connectionRequests")
                .whereEqualTo("toUid", uid)
                .whereEqualTo("status", "pending")
                .addSnapshotListener { snapshot, _ ->
                    pendingRequestsCount = snapshot?.size() ?: 0
                }

            // Listen for total connections
            db.collection("connections").document(uid)
                .addSnapshotListener { snapshot, _ ->
                    val connectedUids = snapshot?.get("connectedUids") as? List<*>
                    connectionCount = connectedUids?.size ?: 0
                }

            // Listen for unread messages
            db.collection("messages")
                .addSnapshotListener { snapshot, _ ->
                    val messages = snapshot?.documents?.mapNotNull { it.toObject(ChatMessage::class.java) } ?: emptyList()

                    // Filter messages where current user is receiver
                    val unreadSenders = messages
                        .filter { it.receiverId == uid && it.senderId != uid }
                        .groupBy { it.senderId }
                        .keys
                        .toList()

                    unreadMessageCount = unreadSenders.size

                    // Get sender names
                    if (unreadSenders.isNotEmpty()) {
                        db.collection("users").whereIn("uid", unreadSenders.take(10))
                            .get()
                            .addOnSuccessListener { users ->
                                unreadMessagesFrom = users.documents.mapNotNull {
                                    it.toObject(UserProfile::class.java)?.name
                                }
                            }
                    } else {
                        unreadMessagesFrom = emptyList()
                    }
                }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        // Background overlay logic based on light/dark mode
        if (lightMode) {
            // Light mode: only white overlay, no black
            Box(modifier = Modifier.fillMaxSize().background(Color.White.copy(alpha = effectiveBgOpacity)))
        } else {
            // Dark mode: only black overlay, no white
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = effectiveBgOpacity)))
        }

        if (profile == null) {
            CircularProgressIndicator(modifier = Modifier.align(Alignment.Center), color = effectivePrimary)
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                item {
                    Spacer(modifier = Modifier.height(24.dp))
                    Box(
                        modifier = Modifier
                            .size(130.dp)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(120.dp)
                                .background(effectivePrimaryColor, CircleShape)
                                .clip(CircleShape)
                                .clickable { pfpLauncher.launch("image/*") },
                            contentAlignment = Alignment.Center
                        ) {
                            if (isProcessingImage) {
                                CircularProgressIndicator(color = Color.Black)
                            } else if (pfpUrl.isNotEmpty()) {
                                AsyncImage(
                                    model = pfpUrl,
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Text(name.take(1).ifEmpty { "U" }.uppercase(), color = Color.Black, style = MaterialTheme.typography.displayMedium.copy(fontSize = (MaterialTheme.typography.displayMedium.fontSize.value * textSizeMultiplier).sp), fontWeight = FontWeight.Bold)
                            }
                        }
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color.Black.copy(alpha = 0.7f), CircleShape)
                                .background(effectivePrimaryColor.copy(alpha = 0.2f), CircleShape)
                                .align(Alignment.BottomEnd)
                                .clickable { pfpLauncher.launch("image/*") },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.CameraAlt, null, tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                    }
                    Spacer(modifier = Modifier.height(24.dp))

                    if (isEditing) {
                        ProfileEditField(value = name, onValueChange = { name = it }, label = "Full Name")
                        ProfileEditField(value = email, onValueChange = { email = it }, label = "Email")
                        ProfileEditField(value = school, onValueChange = { school = it }, label = "School")
                        YearDropdown(selectedYear = year, onYearSelected = { year = it })
                        StateDropdown(selectedState = statePref, onStateSelected = { statePref = it })
                        ProfileEditField(value = bio, onValueChange = { bio = it }, label = "Short Bio")

                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "SOCIAL MEDIA (Optional)",
                            style = MaterialTheme.typography.labelMedium.copy(
                                letterSpacing = 1.5.sp,
                                fontWeight = FontWeight.Bold,
                                fontSize = (12 * textSizeMultiplier).sp
                            ),
                            color = effectivePrimary,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        ProfileEditField(
                            value = instagram,
                            onValueChange = {
                                instagram = it
                                val (isValid, error) = validateSocialMediaLink(it, "Instagram")
                                instagramError = error
                            },
                            label = "Instagram (instagram.com/username)",
                            errorMessage = instagramError
                        )
                        ProfileEditField(
                            value = twitter,
                            onValueChange = {
                                twitter = it
                                val (isValid, error) = validateSocialMediaLink(it, "Twitter")
                                twitterError = error
                            },
                            label = "X/Twitter (twitter.com/username)",
                            errorMessage = twitterError
                        )
                        ProfileEditField(
                            value = facebook,
                            onValueChange = {
                                facebook = it
                                val (isValid, error) = validateSocialMediaLink(it, "Facebook")
                                facebookError = error
                            },
                            label = "Facebook (facebook.com/username)",
                            errorMessage = facebookError
                        )
                        ProfileEditField(
                            value = linkedin,
                            onValueChange = {
                                linkedin = it
                                val (isValid, error) = validateSocialMediaLink(it, "LinkedIn")
                                linkedinError = error
                            },
                            label = "LinkedIn (linkedin.com/in/username)",
                            errorMessage = linkedinError
                        )
                    } else {
                        Text(text = name.ifEmpty { "Member" }, style = MaterialTheme.typography.headlineMedium.copy(fontSize = (MaterialTheme.typography.headlineMedium.fontSize.value * textSizeMultiplier).sp), color = textColor, fontWeight = FontWeight.Black)
                        Text(text = school.ifEmpty { "Unknown School" }, style = MaterialTheme.typography.bodyLarge.copy(fontSize = (MaterialTheme.typography.bodyLarge.fontSize.value * textSizeMultiplier).sp), color = effectivePrimary)
                        Text(text = "Class of ${year.ifEmpty { "20XX" }} • ${statePref.ifEmpty { "N/A" }}", style = MaterialTheme.typography.bodyMedium.copy(fontSize = (MaterialTheme.typography.bodyMedium.fontSize.value * textSizeMultiplier).sp), color = textColorSecondary)
                        if (email.isNotEmpty()) {
                            Text(text = email, style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp), color = textColorTertiary, textAlign = TextAlign.Center)
                        }
                        if (bio.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = bio, style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp), color = textColor.copy(alpha = 0.8f), textAlign = TextAlign.Center)
                        }

                        // Social Media Links
                        val hasSocialMedia = instagram.isNotEmpty() || twitter.isNotEmpty() || facebook.isNotEmpty() || linkedin.isNotEmpty()
                        if (hasSocialMedia) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (instagram.isNotEmpty()) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clickable {
                                                val url = normalizeSocialMediaUrl(instagram)
                                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                            }
                                    ) {
                                        SocialMediaLogo(platform = "Instagram", modifier = Modifier.size(40.dp))
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                }
                                if (twitter.isNotEmpty()) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clickable {
                                                val url = normalizeSocialMediaUrl(twitter)
                                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                            }
                                    ) {
                                        SocialMediaLogo(platform = "X (Twitter)", modifier = Modifier.size(40.dp))
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                }
                                if (facebook.isNotEmpty()) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clickable {
                                                val url = normalizeSocialMediaUrl(facebook)
                                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                            }
                                    ) {
                                        SocialMediaLogo(platform = "Facebook", modifier = Modifier.size(40.dp))
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                }
                                if (linkedin.isNotEmpty()) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clickable {
                                                val url = normalizeSocialMediaUrl(linkedin)
                                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                            }
                                    ) {
                                        SocialMediaLogo(platform = "LinkedIn", modifier = Modifier.size(40.dp))
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(32.dp))

                    Button(
                        onClick = onFindLinksClick,
                        modifier = Modifier.fillMaxWidth().height(50.dp).shadow(4.dp, RoundedCornerShape(12.dp)),
                        colors = ButtonDefaults.buttonColors(containerColor = effectivePrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Search, null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("LINK TO PEERS", color = Color.Black, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = (14 * textSizeMultiplier).sp))
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Box(modifier = Modifier.weight(1f)) {
                            Button(
                                onClick = onConnectionRequestsClick,
                                modifier = Modifier.fillMaxWidth().height(60.dp).shadow(4.dp, RoundedCornerShape(12.dp)),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF505050)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.PersonAdd, null, tint = effectivePrimaryColor, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("REQUESTS", color = textColor, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = (12 * textSizeMultiplier).sp))
                                }
                            }

                            if (pendingRequestsCount > 0) {
                                Badge(
                                    containerColor = Color.Red,
                                    modifier = Modifier.align(Alignment.TopEnd).offset(x = (-8).dp, y = 8.dp)
                                ) {
                                    Text(
                                        text = pendingRequestsCount.toString(),
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        Button(
                            onClick = onMyConnectionsClick,
                            modifier = Modifier.weight(1f).height(60.dp).shadow(4.dp, RoundedCornerShape(12.dp)),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF505050)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.People, null, tint = effectivePrimaryColor, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("CONNECTIONS ($connectionCount)", color = textColor, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = (12 * textSizeMultiplier).sp))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Box(modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = {
                                if (unreadMessageCount > 0) {
                                    showUnreadDialog = true
                                } else {
                                    onMessagesClick()
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(60.dp).shadow(4.dp, RoundedCornerShape(12.dp)),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF505050), contentColor = Color.White),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Chat, null, tint = effectivePrimaryColor, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("MESSAGES", color = textColor, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = (12 * textSizeMultiplier).sp))
                            }
                        }

                        // Badge for unread messages
                        if (unreadMessageCount > 0) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .offset(x = (-8).dp, y = 8.dp)
                                    .size(24.dp)
                                    .background(Color.Red, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (unreadMessageCount > 9) "9+" else unreadMessageCount.toString(),
                                    color = Color.White,
                                    fontSize = (10 * textSizeMultiplier).sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = {
                                if (isEditing) {
                                    // Check for validation errors
                                    val hasErrors = instagramError.isNotEmpty() ||
                                            twitterError.isNotEmpty() ||
                                            facebookError.isNotEmpty() ||
                                            linkedinError.isNotEmpty()

                                    if (hasErrors) {
                                        Toast.makeText(context, "Please fix social media link errors before saving", Toast.LENGTH_LONG).show()
                                        return@Button
                                    }

                                    val newProfile = profile!!.copy(name = name, email = email, school = school, year = year, state = statePref, bio = bio, pfpUrl = pfpUrl, instagram = instagram, twitter = twitter, facebook = facebook, linkedin = linkedin)
                                    db.collection("users").document(auth.currentUser!!.uid).set(newProfile)
                                    profile = newProfile
                                }
                                isEditing = !isEditing
                            },
                            modifier = Modifier.weight(1f).shadow(4.dp, RoundedCornerShape(8.dp)),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isEditing) Color.Green else Color(0xFF505050),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(if (isEditing) Icons.Default.Check else Icons.Default.Edit, null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (isEditing) "SAVE" else "EDIT", style = TextStyle(fontSize = (12 * textSizeMultiplier).sp))
                        }

                        Button(
                            onClick = onLogout,
                            modifier = Modifier.weight(1f).shadow(4.dp, RoundedCornerShape(8.dp)),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFDC143C),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Logout, null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("LOGOUT", style = TextStyle(fontSize = (12 * textSizeMultiplier).sp))
                        }
                    }

                    if (profile?.reminders?.isNotEmpty() == true) {
                        Spacer(modifier = Modifier.height(48.dp))
                        Text(
                            text = "MY REMINDERS",
                            style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 2.sp, fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp),
                            color = effectivePrimary,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Start
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        profile!!.reminders.forEach { reminder ->
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(reminder.name, color = textColor, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = (14 * textSizeMultiplier).sp))
                                        Text(reminder.date, color = textColorSecondary, style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp))
                                    }
                                    IconButton(onClick = {
                                        db.collection("users").document(auth.currentUser!!.uid).update(
                                            "reminders", FieldValue.arrayRemove(reminder)
                                        )
                                    }) {
                                        Icon(Icons.Default.Delete, null, tint = Color.Red.copy(alpha = 0.7f))
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(48.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(text = "VISUALS", style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 2.sp, fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp), color = effectivePrimary, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
                    Spacer(modifier = Modifier.height(16.dp))

                    // Light Mode toggle removed - feature was buggy
                    Text("Background Darkness", color = textColor, style = MaterialTheme.typography.bodyMedium.copy(fontSize = (MaterialTheme.typography.bodyMedium.fontSize.value * textSizeMultiplier).sp), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
                    Slider(value = bgOpacity, onValueChange = onBgOpacityChange, valueRange = 0.0f..0.95f, colors = SliderDefaults.colors(thumbColor = effectivePrimary, activeTrackColor = effectivePrimary))
                    Text(
                        "Slide RIGHT to darken (max dark)",
                        color = textColorTertiary,
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * 0.9f * textSizeMultiplier).sp),
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Start
                    )
                    Spacer(modifier = Modifier.height(48.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(text = "THEME COLORS", style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 2.sp, fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp), color = effectivePrimary, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Tap to apply • Long press custom colors to remove", color = textColorSecondary, style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp), modifier = Modifier.weight(1f))
                        Text("${savedColors.size}/5", color = effectivePrimary, style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp, fontWeight = FontWeight.Bold))
                    }
                    Spacer(modifier = Modifier.height(16.dp))

                    // Saved colors grid
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(6),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.height(120.dp)
                    ) {
                        itemsIndexed(
                            items = savedColors,
                            key = { index, color -> "$index-$color" }
                        ) { index, colorInt ->
                            val color = Color(colorInt)
                            val isSelected = color == primaryColor

                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .shadow(if (isSelected) 6.dp else 2.dp, CircleShape)
                                    .background(color, CircleShape)
                                    .border(if (isSelected) 3.dp else 0.dp, Color.White, CircleShape)
                                    .pointerInput(Unit) {
                                        detectTapGestures(
                                            onTap = {
                                                onPrimaryColorChange(color)
                                            },
                                            onLongPress = {
                                                // Only allow removing custom colors (not first 2 defaults)
                                                if (index >= 2) {
                                                    val newColors = savedColors.toMutableList()
                                                    newColors.removeAt(index)
                                                    onSavedColorsChange(newColors)
                                                    Toast.makeText(context, "Color removed", Toast.LENGTH_SHORT).show()
                                                } else {
                                                    Toast.makeText(context, "Can't remove default colors", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        )
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSelected) {
                                    // Calculate luminance manually: (0.299*R + 0.587*G + 0.114*B)
                                    val luminance = (0.299f * color.red + 0.587f * color.green + 0.114f * color.blue)
                                    Icon(Icons.Default.Check, null, tint = if (luminance > 0.5f) Color.Black else Color.White, modifier = Modifier.size(24.dp))
                                }
                            }
                        }

                        // Add custom color button (only show if less than 5 colors)
                        if (savedColors.size < 5) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .shadow(2.dp, CircleShape)
                                        .background(Color(0xFF333333), CircleShape)
                                        .border(1.dp, Color.White.copy(alpha = 0.3f), CircleShape)
                                        .clickable {
                                            showColorPicker = true
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Add, null, tint = Color.White, modifier = Modifier.size(24.dp))
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(32.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(text = "ACCESSIBILITY", style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 2.sp, fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp), color = effectivePrimary, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
                    Spacer(modifier = Modifier.height(16.dp))

                    SettingToggle(title = "Simplified UI", subtitle = "Hide background images", icon = Icons.Default.VisibilityOff, checked = isSimplifiedUI, onCheckedChange = onSimplifiedUIChange, primaryColor = effectivePrimaryColor, textSizeMultiplier = textSizeMultiplier)

                    Spacer(modifier = Modifier.height(48.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
                    Spacer(modifier = Modifier.height(24.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    TextButton(onClick = { showAboutDialog = true }, modifier = Modifier.fillMaxWidth()) { Text("About LeadLink v1.0", color = textColorTertiary.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp)) }
                    TextButton(onClick = { showDeleteDialog = true }, modifier = Modifier.fillMaxWidth()) { Text("Delete Account", color = Color.Red.copy(alpha = 0.5f), style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp)) }
                    Spacer(modifier = Modifier.height(40.dp))
                }
            }
        }
    }

    // Color Picker Dialog
    if (showColorPicker) {
        // Initialize picker with current primary color
        LaunchedEffect(showColorPicker) {
            if (showColorPicker) {
                val hsv = FloatArray(3)
                android.graphics.Color.colorToHSV(primaryColor.toArgb(), hsv)
                pickerHue = hsv[0]
                pickerSaturation = hsv[1]
                pickerValue = hsv[2]
            }
        }

        AlertDialog(
            onDismissRequest = { showColorPicker = false },
            title = {
                Text("Pick a Color", color = Color.White, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    // Color wheel with ring and square
                    Box(
                        modifier = Modifier.size(280.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(
                            modifier = Modifier
                                .size(280.dp)
                                .pointerInput(Unit) {
                                    detectDragGestures(
                                        onDragStart = { offset ->
                                            val centerX = size.width / 2f
                                            val centerY = size.height / 2f
                                            val dx = offset.x - centerX
                                            val dy = offset.y - centerY
                                            val distance = sqrt(dx * dx + dy * dy)
                                            val outerRadius = size.width / 2f
                                            val innerRadius = outerRadius * 0.65f
                                            val squareSize = innerRadius * 1.4f

                                            // Check if drag starts on the hue ring
                                            if (distance >= innerRadius && distance <= outerRadius) {
                                                var angle = atan2(dy, dx) * 180f / PI.toFloat()
                                                if (angle < 0) angle += 360f
                                                pickerHue = angle
                                            }
                                            // Check if drag starts in the saturation/value square
                                            else if (abs(dx) <= squareSize / 2f && abs(dy) <= squareSize / 2f) {
                                                pickerSaturation = ((dx + squareSize / 2f) / squareSize).coerceIn(0f, 1f)
                                                pickerValue = (1f - (dy + squareSize / 2f) / squareSize).coerceIn(0f, 1f)
                                            }
                                        },
                                        onDrag = { change, _ ->
                                            val centerX = size.width / 2f
                                            val centerY = size.height / 2f
                                            val dx = change.position.x - centerX
                                            val dy = change.position.y - centerY
                                            val distance = sqrt(dx * dx + dy * dy)
                                            val outerRadius = size.width / 2f
                                            val innerRadius = outerRadius * 0.65f
                                            val squareSize = innerRadius * 1.4f

                                            // Check if drag is on the hue ring
                                            if (distance >= innerRadius && distance <= outerRadius) {
                                                var angle = atan2(dy, dx) * 180f / PI.toFloat()
                                                if (angle < 0) angle += 360f
                                                pickerHue = angle
                                            }
                                            // Check if drag is in the saturation/value square
                                            else if (abs(dx) <= squareSize / 2f && abs(dy) <= squareSize / 2f) {
                                                pickerSaturation = ((dx + squareSize / 2f) / squareSize).coerceIn(0f, 1f)
                                                pickerValue = (1f - (dy + squareSize / 2f) / squareSize).coerceIn(0f, 1f)
                                            }
                                        }
                                    )
                                }
                        ) {
                            val centerX = size.width / 2f
                            val centerY = size.height / 2f
                            val outerRadius = size.width / 2f
                            val innerRadius = outerRadius * 0.65f

                            // Draw hue ring - smooth and clean using arcs
                            val ringThickness = outerRadius - innerRadius
                            for (angle in 0 until 360) {
                                val hueColor = android.graphics.Color.HSVToColor(floatArrayOf(angle.toFloat(), 1f, 1f))

                                drawArc(
                                    color = Color(hueColor),
                                    startAngle = angle.toFloat(),
                                    sweepAngle = 1f,
                                    useCenter = false,
                                    topLeft = Offset(centerX - outerRadius, centerY - outerRadius),
                                    size = Size(outerRadius * 2, outerRadius * 2),
                                    style = Stroke(width = ringThickness)
                                )
                            }

                            // Draw saturation/value square in center - optimized
                            val squareSize = innerRadius * 1.4f
                            val squareLeft = centerX - squareSize / 2f
                            val squareTop = centerY - squareSize / 2f

                            val selectedHueColor = android.graphics.Color.HSVToColor(floatArrayOf(pickerHue, 1f, 1f))

                            for (x in 0 until squareSize.toInt() step 3) {
                                for (y in 0 until squareSize.toInt() step 3) {
                                    val sat = x / squareSize
                                    val value = 1f - (y / squareSize)
                                    val color = android.graphics.Color.HSVToColor(
                                        floatArrayOf(pickerHue, sat, value)
                                    )

                                    drawCircle(
                                        color = Color(color),
                                        radius = 3f,
                                        center = Offset(squareLeft + x, squareTop + y)
                                    )
                                }
                            }

                            // Draw selector on hue ring
                            val hueAngleRad = pickerHue * PI.toFloat() / 180f
                            val hueRadius = (innerRadius + outerRadius) / 2f
                            val hueSelectorPos = Offset(
                                centerX + hueRadius * cos(hueAngleRad),
                                centerY + hueRadius * sin(hueAngleRad)
                            )

                            drawCircle(
                                color = Color.White,
                                radius = 10f,
                                center = hueSelectorPos,
                                style = Stroke(width = 3f)
                            )
                            drawCircle(
                                color = Color.Black,
                                radius = 10f,
                                center = hueSelectorPos,
                                style = Stroke(width = 1f)
                            )

                            // Draw selector in saturation/value square
                            val squareSelectorX = squareLeft + pickerSaturation * squareSize
                            val squareSelectorY = squareTop + (1f - pickerValue) * squareSize
                            val squareSelectorPos = Offset(squareSelectorX, squareSelectorY)

                            drawCircle(
                                color = Color.White,
                                radius = 8f,
                                center = squareSelectorPos,
                                style = Stroke(width = 3f)
                            )
                            drawCircle(
                                color = Color.Black,
                                radius = 8f,
                                center = squareSelectorPos,
                                style = Stroke(width = 1f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Color preview
                    val selectedColor = android.graphics.Color.HSVToColor(
                        floatArrayOf(pickerHue, pickerSaturation, pickerValue)
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                            .background(Color(selectedColor), RoundedCornerShape(12.dp))
                            .border(2.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    if (savedColors.size >= 5) {
                        Text(
                            "Maximum 5 colors (2 default + 3 custom). Remove a custom color to add more.",
                            color = Color.Yellow,
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val newColor = android.graphics.Color.HSVToColor(
                            floatArrayOf(pickerHue, pickerSaturation, pickerValue)
                        )
                        if (savedColors.size < 5 && !savedColors.contains(newColor)) {
                            onSavedColorsChange(savedColors + newColor)
                        }
                        onPrimaryColorChange(Color(newColor))
                        showColorPicker = false
                    }
                ) {
                    Text("SAVE COLOR", color = effectivePrimary, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showColorPicker = false }) {
                    Text("CANCEL", color = Color.White.copy(alpha = 0.7f))
                }
            },
            containerColor = Color(0xFF1A1A1A),
            titleContentColor = Color.White,
            textContentColor = Color.White
        )
    }

    // Delete Account Confirmation Dialog
    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = {
                showDeleteDialog = false
                deleteConfirmText = ""
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Warning, null, tint = Color(0xFFDC143C), modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("Delete Account", color = Color(0xFFDC143C), fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column {
                    Text(
                        "This action is PERMANENT and cannot be undone. All your data will be deleted:",
                        color = Color.White,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("• Profile information", color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall)
                    Text("• Competition reminders", color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall)
                    Text("• Connection requests", color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall)
                    Text("• All messages", color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Type 'DELETE' to confirm:", color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = deleteConfirmText,
                        onValueChange = { deleteConfirmText = it.uppercase() },
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedTextColor = Color.White,
                            focusedTextColor = Color.White,
                            unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
                            focusedBorderColor = Color(0xFFDC143C)
                        ),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val uid = auth.currentUser?.uid
                        if (uid != null && deleteConfirmText == "DELETE") {
                            // Delete user data from Firestore
                            db.collection("users").document(uid).delete()
                            db.collection("connections").document(uid).delete()
                            db.collection("connectionRequests")
                                .whereEqualTo("fromUid", uid)
                                .get()
                                .addOnSuccessListener { docs ->
                                    docs.forEach { it.reference.delete() }
                                }
                            db.collection("connectionRequests")
                                .whereEqualTo("toUid", uid)
                                .get()
                                .addOnSuccessListener { docs ->
                                    docs.forEach { it.reference.delete() }
                                }
                            db.collection("messages")
                                .whereEqualTo("senderId", uid)
                                .get()
                                .addOnSuccessListener { docs ->
                                    docs.forEach { it.reference.delete() }
                                }

                            // Delete Firebase Auth account
                            auth.currentUser?.delete()?.addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    Toast.makeText(context, "Account deleted successfully", Toast.LENGTH_SHORT).show()
                                    onLogout()
                                } else {
                                    Toast.makeText(context, "Error deleting account: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                                }
                            }
                            showDeleteDialog = false
                            deleteConfirmText = ""
                        } else if (deleteConfirmText != "DELETE") {
                            Toast.makeText(context, "Please type DELETE to confirm", Toast.LENGTH_SHORT).show()
                        }
                    },
                    enabled = deleteConfirmText == "DELETE",
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC143C))
                ) {
                    Text("DELETE ACCOUNT", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showDeleteDialog = false
                    deleteConfirmText = ""
                }) {
                    Text("CANCEL", color = Color.White.copy(alpha = 0.7f))
                }
            },
            containerColor = Color(0xFF1A1A1A),
            titleContentColor = Color.White,
            textContentColor = Color.White
        )
    }

    // About dialog
    if (showUnreadDialog) {
        AlertDialog(
            onDismissRequest = { showUnreadDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Chat, null, tint = effectivePrimaryColor, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("New Messages", color = textColor, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column {
                    Text(
                        "You have $unreadMessageCount unread conversation${if (unreadMessageCount > 1) "s" else ""}:",
                        color = textColor,
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    if (unreadMessagesFrom.isNotEmpty()) {
                        unreadMessagesFrom.forEach { senderName ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.AccountCircle,
                                    null,
                                    tint = effectivePrimaryColor,
                                    modifier = Modifier.size(32.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    senderName,
                                    color = textColor,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    } else {
                        Text(
                            "Loading...",
                            color = textColorSecondary,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showUnreadDialog = false
                        onMessagesClick()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = effectivePrimaryColor)
                ) {
                    Text("View Messages", color = Color.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { showUnreadDialog = false }) {
                    Text("Dismiss", color = textColor)
                }
            },
            containerColor = Color(0xFF1C1C1C)
        )
    }

    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Info, null, tint = effectivePrimaryColor, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("About LeadLink", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column {
                    Text(
                        "LeadLink v1.0",
                        color = effectivePrimary,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        modifier = Modifier.padding(bottom = 16.dp)
                    )
                    Text(
                        "The premier networking platform for FBLA members.",
                        color = Color.White,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Features:", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(8.dp))

                    Text("• Connect with FBLA members nationwide", color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall)
                    Text("• Access competition resources and study guides", color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall)
                    Text("• Track upcoming FBLA events and deadlines", color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall)
                    Text("• Receive leadership tips and career advice", color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall)
                    Text("• Send direct messages to your connections", color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall)
                    Text("• Customize your profile and experience", color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall)

                    Spacer(modifier = Modifier.height(16.dp))

                    // LeadLink Instagram Link
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                context.startActivity(
                                    Intent(Intent.ACTION_VIEW, Uri.parse("https://instagram.com/leadlink2026"))
                                )
                            }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        SocialMediaLogo(platform = "Instagram", modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "Follow us @leadlink2026",
                            color = effectivePrimary,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Built with passion for the FBLA community.",
                        color = Color.White.copy(alpha = 0.6f),
                        style = MaterialTheme.typography.bodySmall.copy(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showAboutDialog = false }) {
                    Text("GOT IT", color = effectivePrimary, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF1A1A1A),
            titleContentColor = Color.White,
            textContentColor = Color.White
        )
    }
}

@Composable
fun SettingToggle(title: String, subtitle: String, icon: ImageVector, checked: Boolean, onCheckedChange: (Boolean) -> Unit, primaryColor: Color, textSizeMultiplier: Float) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Color.White.copy(alpha = 0.6f), modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Color.White, style = MaterialTheme.typography.bodyLarge.copy(fontSize = (MaterialTheme.typography.bodyLarge.fontSize.value * textSizeMultiplier).sp))
            Text(subtitle, color = Color.White.copy(alpha = 0.5f), style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp))
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange, colors = SwitchDefaults.colors(checkedThumbColor = primaryColor, checkedTrackColor = primaryColor.copy(alpha = 0.3f), uncheckedThumbColor = Color.Gray, uncheckedTrackColor = Color.Gray.copy(alpha = 0.3f)))
    }
}

fun normalizeSocialMediaUrl(link: String): String {
    if (link.isEmpty()) return ""
    val trimmed = link.trim()
    // If it already starts with http:// or https://, return as is
    if (trimmed.startsWith("http://", ignoreCase = true) || trimmed.startsWith("https://", ignoreCase = true)) {
        return trimmed
    }
    // Otherwise, add https://
    return "https://$trimmed"
}

fun validateSocialMediaLink(link: String, platform: String): Pair<Boolean, String> {
    if (link.isEmpty()) return Pair(true, "") // Empty is OK

    val trimmedLink = link.trim()

    return when (platform) {
        "Instagram" -> {
            if (trimmedLink.contains("instagram.com", ignoreCase = true)) {
                Pair(true, "")
            } else {
                Pair(false, "Please enter a valid Instagram link (instagram.com/username)")
            }
        }
        "Twitter" -> {
            if (trimmedLink.contains("twitter.com", ignoreCase = true) || trimmedLink.contains("x.com", ignoreCase = true)) {
                Pair(true, "")
            } else {
                Pair(false, "Please enter a valid Twitter/X link (twitter.com/username)")
            }
        }
        "Facebook" -> {
            if (trimmedLink.contains("facebook.com", ignoreCase = true) || trimmedLink.contains("fb.com", ignoreCase = true)) {
                Pair(true, "")
            } else {
                Pair(false, "Please enter a valid Facebook link (facebook.com/username)")
            }
        }
        "LinkedIn" -> {
            if (trimmedLink.contains("linkedin.com", ignoreCase = true)) {
                Pair(true, "")
            } else {
                Pair(false, "Please enter a valid LinkedIn link (linkedin.com/in/username)")
            }
        }
        else -> Pair(true, "")
    }
}

@Composable
fun ProfileEditField(value: String, onValueChange: (String) -> Unit, label: String, errorMessage: String = "") {
    Column(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = { Text(label) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedTextColor = Color.White,
                focusedTextColor = Color.White,
                errorTextColor = Color.White
            ),
            isError = errorMessage.isNotEmpty()
        )
        if (errorMessage.isNotEmpty()) {
            Text(
                text = errorMessage,
                color = Color.White,
                fontSize = 12.sp,
                modifier = Modifier.padding(start = 16.dp, top = 4.dp)
            )
        }
    }
}

@Composable
fun YearDropdown(selectedYear: String, onYearSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val years = (2026..2033).map { it.toString() }

    Box(modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = selectedYear,
            onValueChange = { },
            readOnly = true,
            label = { Text("Graduation Year") },
            trailingIcon = {
                Icon(
                    imageVector = if (expanded) Icons.Filled.ArrowDropUp else Icons.Filled.ArrowDropDown,
                    contentDescription = "Dropdown",
                    modifier = Modifier.clickable { expanded = !expanded }
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = !expanded },
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedTextColor = Color.White,
                focusedTextColor = Color.White,
                unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
                focusedBorderColor = Color(0xFFFFB800),
                disabledTextColor = Color.White,
                disabledBorderColor = Color.White.copy(alpha = 0.3f),
                disabledLabelColor = Color.White.copy(alpha = 0.6f)
            ),
            shape = RoundedCornerShape(12.dp)
        )

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.fillMaxWidth(0.9f)
        ) {
            years.forEach { year ->
                DropdownMenuItem(
                    text = { Text(year) },
                    onClick = {
                        onYearSelected(year)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
fun StateDropdown(selectedState: String, onStateSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val states = listOf(
        "Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut",
        "Delaware", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa",
        "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan",
        "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire",
        "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio",
        "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota",
        "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", "West Virginia",
        "Wisconsin", "Wyoming"
    )

    Box(modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = selectedState,
            onValueChange = { },
            readOnly = true,
            label = { Text("State") },
            trailingIcon = {
                Icon(
                    imageVector = if (expanded) Icons.Filled.ArrowDropUp else Icons.Filled.ArrowDropDown,
                    contentDescription = "Dropdown",
                    modifier = Modifier.clickable { expanded = !expanded }
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = !expanded },
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedTextColor = Color.White,
                focusedTextColor = Color.White,
                unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
                focusedBorderColor = Color(0xFFFFB800),
                disabledTextColor = Color.White,
                disabledBorderColor = Color.White.copy(alpha = 0.3f),
                disabledLabelColor = Color.White.copy(alpha = 0.6f)
            ),
            shape = RoundedCornerShape(12.dp)
        )

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.fillMaxWidth(0.9f).heightIn(max = 300.dp)
        ) {
            states.forEach { state ->
                DropdownMenuItem(
                    text = { Text(state) },
                    onClick = {
                        onStateSelected(state)
                        expanded = false
                    }
                )
            }
        }
    }
}


@Composable
fun HomeScreen(primaryColor: Color, bgOpacity: Float, isSimplifiedUI: Boolean, textSizeMultiplier: Float, lightMode: Boolean = false, onNavigate: (Int, String?) -> Unit) {
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    var profile by remember { mutableStateOf<UserProfile?>(null) }
    var showSearch by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    // Dynamic text colors
    val textColor = if (lightMode) Color.Black else Color.White
    val textColorSecondary = if (lightMode) Color.Black.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.6f)
    val textColorTertiary = if (lightMode) Color.Black.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.5f)

    val white = textColor
    val black = if (lightMode) Color.White else Color.Black

    val tips = listOf(
        "Networking isn't just about collecting contacts; it's about planting relations.",
        "Success is not final, failure is not fatal: it is the courage to continue that counts.",
        "The best way to predict the future is to create it.",
        "Business opportunities are like buses, there's always another one coming.",
        "Build your own dreams, or someone else will hire you to build theirs.",
        "Never give up. Today is hard and tomorrow will be worse, but the day after tomorrow will be sunshine.",
        "Innovation distinguishes between a leader and a follower.",
        "Failure doesn't mean you are a failure it just means you haven't succeeded yet.",
        "Work like there is someone working 24 hours a day to take it all away from you."
    )
    var currentTipIndex by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        val uid = auth.currentUser?.uid
        if (uid != null) {
            db.collection("users").document(uid).addSnapshotListener { snapshot, _ ->
                profile = snapshot?.toObject(UserProfile::class.java)
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        // Background overlay logic based on light/dark mode
        if (lightMode) {
            // Light mode: only white overlay
            Box(modifier = Modifier.fillMaxSize().background(Color.White.copy(alpha = bgOpacity)))
        } else {
            // Dark mode: only black overlay
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgOpacity)))
        }

        LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(24.dp)) {
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "WELCOME, ${profile?.name?.split(" ")?.get(0)?.uppercase() ?: "MEMBER"}",
                            style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 4.sp, fontWeight = FontWeight.Bold, color = primaryColor, fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp)
                        )
                        Text(text = "LeadLink Dashboard", style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.Black, color = textColor, fontSize = (MaterialTheme.typography.displaySmall.fontSize.value * textSizeMultiplier).sp))
                    }
                    IconButton(
                        onClick = { showSearch = true },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(
                            Icons.Default.Search,
                            contentDescription = "Search",
                            tint = primaryColor,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }

            if (profile?.reminders?.isNotEmpty() == true) {
                itemsIndexed(profile!!.reminders) { index, reminder ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                            .animateContentSize(
                                animationSpec = spring(
                                    dampingRatio = Spring.DampingRatioMediumBouncy,
                                    stiffness = Spring.StiffnessLow
                                )
                            ),
                        colors = CardDefaults.cardColors(containerColor = primaryColor.copy(alpha = 0.15f)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, primaryColor.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(24.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.AutoMirrored.Filled.EventNote, null, tint = primaryColor, modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.width(12.dp))
                                Text("UPCOMING COMPETITION", color = Color.White.copy(alpha = 0.6f), style = MaterialTheme.typography.labelSmall.copy(fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * textSizeMultiplier).sp))
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(reminder.name, color = Color.White, style = MaterialTheme.typography.titleLarge.copy(fontSize = (MaterialTheme.typography.titleLarge.fontSize.value * textSizeMultiplier).sp), fontWeight = FontWeight.Bold)
                            Text(reminder.date, color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.bodyMedium.copy(fontSize = (MaterialTheme.typography.bodyMedium.fontSize.value * textSizeMultiplier).sp))

                            // Calculate days remaining properly by comparing calendar dates
                            val daysLeft = if (reminder.timestamp > System.currentTimeMillis()) {
                                val cal = Calendar.getInstance()
                                cal.timeInMillis = System.currentTimeMillis()
                                cal.set(Calendar.HOUR_OF_DAY, 0)
                                cal.set(Calendar.MINUTE, 0)
                                cal.set(Calendar.SECOND, 0)
                                cal.set(Calendar.MILLISECOND, 0)
                                val todayStart = cal.timeInMillis

                                val eventCal = Calendar.getInstance()
                                eventCal.timeInMillis = reminder.timestamp
                                eventCal.set(Calendar.HOUR_OF_DAY, 0)
                                eventCal.set(Calendar.MINUTE, 0)
                                eventCal.set(Calendar.SECOND, 0)
                                eventCal.set(Calendar.MILLISECOND, 0)
                                val eventStart = eventCal.timeInMillis

                                TimeUnit.MILLISECONDS.toDays(eventStart - todayStart)
                            } else 0

                            Spacer(modifier = Modifier.height(16.dp))
                            LinearProgressIndicator(
                                progress = { (100 - daysLeft.coerceIn(0, 100)) / 100f },
                                modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
                                color = primaryColor,
                                trackColor = Color.White.copy(alpha = 0.1f)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("$daysLeft DAYS REMAINING", color = primaryColor, style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Black, fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp))
                        }
                    }
                }
            } else {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.AutoMirrored.Filled.EventNote, null, tint = Color.White.copy(alpha = 0.3f), modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("No Active Reminders", color = Color.White.copy(alpha = 0.5f), style = TextStyle(fontSize = (14 * textSizeMultiplier).sp))
                            Text("Set one in the Events tab", color = Color.White.copy(alpha = 0.3f), style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp))
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(40.dp))
                Card(
                    onClick = { currentTipIndex = (currentTipIndex + 1) % tips.size },
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = primaryColor),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(24.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(Icons.Default.Lightbulb, null, tint = Color.Black)
                            Icon(
                                Icons.Default.TouchApp,
                                contentDescription = "Tap to change",
                                tint = Color.Black
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("LEADERSHIP TIP", color = Color.Black.copy(alpha = 0.6f), style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * textSizeMultiplier).sp))
                        Spacer(modifier = Modifier.height(8.dp))
                        AnimatedContent(
                            targetState = tips[currentTipIndex],
                            transitionSpec = {
                                fadeIn(animationSpec = tween(500)) + slideInVertically(
                                    initialOffsetY = { it / 2 },
                                    animationSpec = tween(500)
                                ) togetherWith fadeOut(animationSpec = tween(300))
                            },
                            label = "tip_transition"
                        ) { tip ->
                            Text(
                                text = tip,
                                color = Color.Black,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Serif,
                                    fontSize = (MaterialTheme.typography.bodyLarge.fontSize.value * textSizeMultiplier).sp
                                )
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }

    // Global Search Dialog
    if (showSearch) {
        AlertDialog(
            onDismissRequest = { showSearch = false },
            title = {
                Text("Search", color = Color.White, fontWeight = FontWeight.Bold)
            },
            text = {
                Column {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = { Text("Search anything...", color = Color.White.copy(alpha = 0.6f)) },
                        placeholder = { Text("Events, News, Resources, Connections...", color = Color.White.copy(alpha = 0.4f)) },
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = null, tint = primaryColor)
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Close, contentDescription = "Clear", tint = Color.White.copy(alpha = 0.6f))
                                }
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = primaryColor,
                            unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
                            cursorColor = primaryColor
                        ),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Search Results
                    if (searchQuery.isNotEmpty()) {
                        val query = searchQuery.lowercase()
                        val results = buildList {
                            // Tab/Screen results
                            if ("profile".contains(query) || "account".contains(query) || "settings".contains(query)) {
                                add(SearchResult("Profile & Settings", "View your profile and app settings", 0, null, Icons.Default.Person))
                            }
                            if ("events".contains(query) || "calendar".contains(query) || "competition".contains(query) || "reminder".contains(query)) {
                                add(SearchResult("Events & Calendar", "Manage competitions and reminders", 1, null, Icons.Default.Event))
                            }
                            if ("messages".contains(query) || "chat".contains(query) || "messaging".contains(query) || "dm".contains(query)) {
                                add(SearchResult("Messages", "Chat with your connections", 0, "messages", Icons.Default.Chat))
                            }
                            if ("news".contains(query) || "updates".contains(query) || "articles".contains(query)) {
                                add(SearchResult("FBLA News", "Latest FBLA news and updates", 3, null, Icons.AutoMirrored.Filled.Article))
                            }
                            if ("resources".contains(query) || "social media".contains(query) || "tools".contains(query)) {
                                add(SearchResult("Resources", "Helpful resources and social media", 4, null, Icons.AutoMirrored.Filled.MenuBook))
                            }
                            if ("connections".contains(query) || "peers".contains(query) || "network".contains(query) || "friends".contains(query)) {
                                add(SearchResult("My Connections", "View your network", 0, "my_connections", Icons.Default.People))
                            }
                            if ("find peers".contains(query) || "search users".contains(query) || "find members".contains(query)) {
                                add(SearchResult("Find Peers", "Search for FBLA members", 0, "find_links", Icons.Default.Search))
                            }
                            if ("requests".contains(query) || "pending".contains(query)) {
                                add(SearchResult("Connection Requests", "View pending requests", 0, "connection_requests", Icons.Default.PersonAdd))
                            }

                            // Search events from profile
                            profile?.reminders?.forEach { reminder ->
                                if (reminder.name.lowercase().contains(query) || reminder.date.lowercase().contains(query)) {
                                    add(SearchResult(reminder.name, "Event on ${reminder.date}", 1, null, Icons.Default.EmojiEvents))
                                }
                            }
                        }

                        if (results.isNotEmpty()) {
                            LazyColumn(modifier = Modifier.heightIn(max = 300.dp)) {
                                items(results.size) { index ->
                                    val result = results[index]
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp),
                                        onClick = {
                                            onNavigate(result.tabIndex, result.subScreen)
                                            showSearch = false
                                            searchQuery = ""
                                        },
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFF2A2A2A))
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(16.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                result.icon,
                                                contentDescription = null,
                                                tint = primaryColor,
                                                modifier = Modifier.size(24.dp)
                                            )
                                            Spacer(modifier = Modifier.width(16.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    result.title,
                                                    color = Color.White,
                                                    fontWeight = FontWeight.Bold,
                                                    style = MaterialTheme.typography.bodyLarge
                                                )
                                                Text(
                                                    result.subtitle,
                                                    color = Color.White.copy(alpha = 0.6f),
                                                    style = MaterialTheme.typography.bodySmall
                                                )
                                            }
                                            Icon(
                                                Icons.AutoMirrored.Filled.ArrowForward,
                                                contentDescription = null,
                                                tint = Color.White.copy(alpha = 0.4f),
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        Icons.Default.SearchOff,
                                        contentDescription = null,
                                        tint = Color.White.copy(alpha = 0.3f),
                                        modifier = Modifier.size(48.dp)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        "No results found",
                                        color = Color.White.copy(alpha = 0.6f),
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                            }
                        }
                    } else {
                        // Show quick shortcuts when no query
                        Text("Quick Access", color = primaryColor, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                        Spacer(modifier = Modifier.height(8.dp))

                        listOf(
                            SearchResult("Messages", "Chat with connections", 0, "messages", Icons.Default.Chat),
                            SearchResult("Events & Calendar", "Manage competitions", 1, null, Icons.Default.Event),
                            SearchResult("Find Peers", "Search for members", 0, "find_links", Icons.Default.Search),
                            SearchResult("FBLA News", "Latest updates", 3, null, Icons.AutoMirrored.Filled.Article),
                            SearchResult("Resources", "Tools & social media", 4, null, Icons.AutoMirrored.Filled.MenuBook)
                        ).forEach { result ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                onClick = {
                                    onNavigate(result.tabIndex, result.subScreen)
                                    showSearch = false
                                },
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF2A2A2A))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        result.icon,
                                        contentDescription = null,
                                        tint = primaryColor,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            result.title,
                                            color = Color.White,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Text(
                                            result.subtitle,
                                            color = Color.White.copy(alpha = 0.5f),
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSearch = false }) {
                    Text("CLOSE", color = primaryColor, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF1A1A1A),
            titleContentColor = Color.White,
            textContentColor = Color.White
        )
    }
}

data class SearchResult(
    val title: String,
    val subtitle: String,
    val tabIndex: Int,
    val subScreen: String?,
    val icon: ImageVector
)

@Composable
fun MemberSearchScreen(onBack: () -> Unit, primaryColor: Color, bgOpacity: Float, isSimplifiedUI: Boolean, textSizeMultiplier: Float, lightMode: Boolean = false) {
    // Dynamic text colors
    val textColor = if (lightMode) Color.Black else Color.White
    val textColorSecondary = if (lightMode) Color.Black.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.6f)
    val textColorTertiary = if (lightMode) Color.Black.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.5f)

    val white = textColor
    val black = if (lightMode) Color.White else Color.Black

    val db = FirebaseFirestore.getInstance()
    val auth = FirebaseAuth.getInstance()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var members by remember { mutableStateOf<List<UserProfile>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var searchQuery by remember { mutableStateOf("") }
    var sentRequests by remember { mutableStateOf<Set<String>>(emptySet()) }
    var connectedUsers by remember { mutableStateOf<Set<String>>(emptySet()) }

    LaunchedEffect(Unit) {
        val currentUid = auth.currentUser?.uid
        if (currentUid != null) {
            // Load users
            db.collection("users").addSnapshotListener { snapshot, _ ->
                members = snapshot?.toObjects(UserProfile::class.java)?.filter { it.uid != currentUid } ?: emptyList()
                isLoading = false
            }

            // Load sent requests
            db.collection("connectionRequests")
                .whereEqualTo("fromUid", currentUid)
                .whereEqualTo("status", "pending")
                .addSnapshotListener { snapshot, _ ->
                    sentRequests = snapshot?.documents?.mapNotNull { it.getString("toUid") }?.toSet() ?: emptySet()
                }

            // Load connections
            db.collection("connections")
                .document(currentUid)
                .addSnapshotListener { snapshot, _ ->
                    connectedUsers = (snapshot?.get("connectedUids") as? List<*>)?.mapNotNull { it as? String }?.toSet() ?: emptySet()
                }
        } else {
            isLoading = false
        }
    }

    val filteredMembers = remember(searchQuery, members) {
        if (searchQuery.isEmpty()) members
        else members.filter { it.name.contains(searchQuery, ignoreCase = true) }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        // Background overlay logic based on light/dark mode
        if (lightMode) {
            // Light mode: only white overlay
            Box(modifier = Modifier.fillMaxSize().background(Color.White.copy(alpha = bgOpacity)))
        } else {
            // Dark mode: only black overlay
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgOpacity)))
        }

        Column(modifier = Modifier.fillMaxSize()) {
            Spacer(modifier = Modifier.height(24.dp))
            Row(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Text("FIND PEERS", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black, fontSize = (MaterialTheme.typography.headlineSmall.fontSize.value * textSizeMultiplier).sp), color = Color.White)
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                placeholder = { Text("Search by name...", color = Color.White.copy(alpha = 0.5f), style = TextStyle(fontSize = (14 * textSizeMultiplier).sp)) },
                leadingIcon = { Icon(Icons.Default.Search, null, tint = primaryColor) },
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedTextColor = Color.White,
                    focusedTextColor = Color.White,
                    unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                    focusedBorderColor = primaryColor
                ),
                shape = RoundedCornerShape(12.dp)
            )

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = primaryColor)
                }
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                    itemsIndexed(filteredMembers) { _, member ->
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(modifier = Modifier.size(50.dp).background(primaryColor, CircleShape).clip(CircleShape)) {
                                        if (member.pfpUrl.isNotEmpty()) {
                                            AsyncImage(model = member.pfpUrl, contentDescription = null, contentScale = ContentScale.Crop)
                                        } else {
                                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                                Text(member.name.take(1).uppercase(), color = Color.Black, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = (16 * textSizeMultiplier).sp))
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column {
                                        Text(member.name, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge.copy(fontSize = (MaterialTheme.typography.titleLarge.fontSize.value * textSizeMultiplier).sp))
                                        Text(member.school, color = primaryColor, style = MaterialTheme.typography.bodyMedium.copy(fontSize = (MaterialTheme.typography.bodyMedium.fontSize.value * textSizeMultiplier).sp))
                                    }
                                }

                                if (member.bio.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(text = member.bio, color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp))
                                }

                                if (member.reminders.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text("Competitions:", color = Color.White.copy(alpha = 0.6f), style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * textSizeMultiplier).sp))
                                    member.reminders.forEach { reminder ->
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                                            Icon(Icons.Default.EmojiEvents, null, tint = primaryColor, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(reminder.name, color = Color.White, style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp))
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                val isConnected = connectedUsers.contains(member.uid)
                                val requestSent = sentRequests.contains(member.uid)

                                Button(
                                    onClick = {
                                        if (!isConnected && !requestSent) {
                                            scope.launch {
                                                try {
                                                    val currentUser = auth.currentUser ?: return@launch
                                                    val currentProfile = db.collection("users").document(currentUser.uid).get().await().toObject(UserProfile::class.java)

                                                    val request = ConnectionRequest(
                                                        id = UUID.randomUUID().toString(),
                                                        fromUid = currentUser.uid,
                                                        fromName = currentProfile?.name ?: "",
                                                        fromEmail = currentProfile?.email ?: currentUser.email ?: "",
                                                        fromSchool = currentProfile?.school ?: "",
                                                        fromPfpUrl = currentProfile?.pfpUrl ?: "",
                                                        toUid = member.uid,
                                                        toName = member.name,
                                                        status = "pending",
                                                        timestamp = System.currentTimeMillis()
                                                    )

                                                    db.collection("connectionRequests").document(request.id).set(request).await()
                                                    Toast.makeText(context, "Connection request sent!", Toast.LENGTH_SHORT).show()
                                                } catch (e: Exception) {
                                                    Log.e("ConnectionRequest", "Error sending request: ${e.message}", e)
                                                    Toast.makeText(context, "Failed to send: ${e.message}", Toast.LENGTH_LONG).show()
                                                }
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth().height(40.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = when {
                                            isConnected -> Color.Green.copy(alpha = 0.3f)
                                            requestSent -> Color.Gray.copy(alpha = 0.3f)
                                            else -> primaryColor
                                        }
                                    ),
                                    enabled = !isConnected && !requestSent,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(
                                        when {
                                            isConnected -> Icons.Default.Check
                                            requestSent -> Icons.Default.Schedule
                                            else -> Icons.Default.PersonAdd
                                        },
                                        null,
                                        tint = if (isConnected || requestSent) Color.White.copy(alpha = 0.5f) else Color.Black,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        when {
                                            isConnected -> "CONNECTED"
                                            requestSent -> "REQUEST SENT"
                                            else -> "SEND REQUEST"
                                        },
                                        color = if (isConnected || requestSent) Color.White.copy(alpha = 0.5f) else Color.Black,
                                        fontWeight = FontWeight.Bold,
                                        style = TextStyle(fontSize = (12 * textSizeMultiplier).sp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CalendarView(
    selectedDate: Calendar?,
    onDateSelected: (Calendar) -> Unit,
    eventDates: Set<String>,
    primaryColor: Color,
    textSizeMultiplier: Float
) {
    var currentMonth by remember {
        mutableStateOf(Calendar.getInstance(TimeZone.getTimeZone("UTC")))
    }
    var showMonthPicker by remember { mutableStateOf(false) }
    var showYearPicker by remember { mutableStateOf(false) }

    val dateFormat = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
    }
    val monthYearFormat = remember {
        SimpleDateFormat("MMMM yyyy", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
    }
    val monthFormat = remember {
        SimpleDateFormat("MMMM", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        // Month/Year Header with navigation
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {
                currentMonth = (currentMonth.clone() as Calendar).apply {
                    add(Calendar.MONTH, -1)
                    timeZone = TimeZone.getTimeZone("UTC")
                }
            }) {
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, null, tint = Color.White)
            }

            // Clickable month/year text
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier
                    .clickable { showMonthPicker = true }
                    .padding(8.dp)
            ) {
                Text(
                    text = monthYearFormat.format(currentMonth.time).uppercase(),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = (MaterialTheme.typography.titleMedium.fontSize.value * textSizeMultiplier).sp
                    ),
                    color = Color.White
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    Icons.Default.ArrowDropDown,
                    contentDescription = "Select month/year",
                    tint = primaryColor,
                    modifier = Modifier.size(20.dp)
                )
            }

            IconButton(onClick = {
                currentMonth = (currentMonth.clone() as Calendar).apply {
                    add(Calendar.MONTH, 1)
                    timeZone = TimeZone.getTimeZone("UTC")
                }
            }) {
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = Color.White)
            }
        }

        // Day of week headers
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("S", "M", "T", "W", "T", "F", "S").forEach { day ->
                Text(
                    text = day,
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    color = primaryColor,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * textSizeMultiplier).sp
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Calendar grid
        val firstDayOfMonth = (currentMonth.clone() as Calendar).apply {
            timeZone = TimeZone.getTimeZone("UTC")
            set(Calendar.DAY_OF_MONTH, 1)
        }
        val lastDayOfMonth = (currentMonth.clone() as Calendar).apply {
            timeZone = TimeZone.getTimeZone("UTC")
            set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
        }

        val startDayOfWeek = firstDayOfMonth.get(Calendar.DAY_OF_WEEK) - 1
        val daysInMonth = lastDayOfMonth.get(Calendar.DAY_OF_MONTH)
        val totalCells = ((startDayOfWeek + daysInMonth + 6) / 7) * 7

        Column {
            for (week in 0 until (totalCells / 7)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    for (day in 0..6) {
                        val cellIndex = week * 7 + day
                        val dayOfMonth = cellIndex - startDayOfWeek + 1

                        if (cellIndex >= startDayOfWeek && dayOfMonth <= daysInMonth) {
                            val cellDate = (currentMonth.clone() as Calendar).apply {
                                set(Calendar.DAY_OF_MONTH, dayOfMonth)
                                set(Calendar.HOUR_OF_DAY, 0)
                                set(Calendar.MINUTE, 0)
                                set(Calendar.SECOND, 0)
                                set(Calendar.MILLISECOND, 0)
                                timeZone = TimeZone.getTimeZone("UTC")
                            }
                            val dateString = dateFormat.format(cellDate.time)
                            val hasEvent = eventDates.contains(dateString)
                            val isSelected = selectedDate?.let {
                                dateFormat.format(it.time) == dateString
                            } ?: false

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                                    .padding(4.dp)
                                    .background(
                                        when {
                                            isSelected -> primaryColor
                                            hasEvent -> primaryColor.copy(alpha = 0.2f)
                                            else -> Color.Transparent
                                        },
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { onDateSelected(cellDate) },
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = dayOfMonth.toString(),
                                        color = if (isSelected) Color.Black else Color.White,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = if (hasEvent || isSelected) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = (MaterialTheme.typography.bodyMedium.fontSize.value * textSizeMultiplier).sp
                                        )
                                    )
                                    if (hasEvent && !isSelected) {
                                        Box(
                                            modifier = Modifier
                                                .size(4.dp)
                                                .background(primaryColor, CircleShape)
                                        )
                                    }
                                }
                            }
                        } else {
                            Spacer(modifier = Modifier.weight(1f).aspectRatio(1f))
                        }
                    }
                }
            }
        }
    }

    // Month Picker Dialog
    if (showMonthPicker) {
        AlertDialog(
            onDismissRequest = { showMonthPicker = false },
            containerColor = Color(0xFF1E1E1E),
            title = {
                Text(
                    "Select Month & Year",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Year selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = {
                            currentMonth = (currentMonth.clone() as Calendar).apply {
                                add(Calendar.YEAR, -1)
                            }
                        }) {
                            Icon(Icons.Default.KeyboardArrowLeft, null, tint = primaryColor)
                        }
                        Text(
                            text = currentMonth.get(Calendar.YEAR).toString(),
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Bold
                            ),
                            color = primaryColor,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                        IconButton(onClick = {
                            currentMonth = (currentMonth.clone() as Calendar).apply {
                                add(Calendar.YEAR, 1)
                            }
                        }) {
                            Icon(Icons.Default.KeyboardArrowRight, null, tint = primaryColor)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Month grid (3x4)
                    val months = listOf(
                        "January", "February", "March", "April",
                        "May", "June", "July", "August",
                        "September", "October", "November", "December"
                    )

                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        modifier = Modifier.height(300.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        itemsIndexed(months) { index, month ->
                            val isCurrentMonth = currentMonth.get(Calendar.MONTH) == index
                            Button(
                                onClick = {
                                    currentMonth = (currentMonth.clone() as Calendar).apply {
                                        set(Calendar.MONTH, index)
                                    }
                                    showMonthPicker = false
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isCurrentMonth) primaryColor else Color(0xFF2A2A2A),
                                    contentColor = if (isCurrentMonth) Color.Black else Color.White
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                            ) {
                                Text(
                                    text = month.take(3),
                                    fontSize = 12.sp,
                                    fontWeight = if (isCurrentMonth) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showMonthPicker = false }) {
                    Text("Close", color = Color.White.copy(alpha = 0.6f))
                }
            }
        )
    }
}

@Composable
fun EventsPlaceholder(primaryColor: Color, bgOpacity: Float, isSimplifiedUI: Boolean, textSizeMultiplier: Float, lightMode: Boolean = false) {
    // Dynamic text colors
    val textColor = if (lightMode) Color.Black else Color.White
    val textColorSecondary = if (lightMode) Color.Black.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.6f)
    val textColorTertiary = if (lightMode) Color.Black.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.5f)

    val white = textColor
    val black = if (lightMode) Color.White else Color.Black
    var selectedState by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    var selectedDate by remember { mutableStateOf<Calendar?>(null) }
    var showListView by remember { mutableStateOf(false) }
    var userReminders by remember { mutableStateOf<List<CompetitionReminder>>(emptyList()) }
    val context = LocalContext.current
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    val dateFormat = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
    }
    val displayDateFormat = remember {
        SimpleDateFormat("MMMM dd, yyyy", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
    }

    // Load user reminders
    LaunchedEffect(Unit) {
        val uid = auth.currentUser?.uid
        if (uid != null) {
            db.collection("users").document(uid).addSnapshotListener { snapshot, error ->
                if (error != null) return@addSnapshotListener
                val data = snapshot?.toObject(UserProfile::class.java)
                userReminders = data?.reminders ?: emptyList()
            }
        }
    }

    val nationalConference = FblaEvent("National Leadership Conference (NLC)", "June 29 - July 2, 2026", "Anaheim, CA", 1782709200000L)
    val eventsByState = remember {
        val statesList = listOf("Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming")
        val baseEvents = mapOf(
            "Alabama" to listOf(FblaEvent("District Workshops", "Jan-Feb 2026", "Various Locations"), FblaEvent("State Leadership Conference", "April 9–10, 2026", "Mobile", 1775710800000L)),
            "California" to listOf(FblaEvent("Section Leadership Conferences", "Feb-March 2026", "Various Sections"), FblaEvent("State Leadership Conference", "April 23–26, 2026", "Sacramento", 1776920400000L)),
            "Texas" to listOf(FblaEvent("Area Leadership Conferences", "Jan-Feb 2026", "Areas 1-9"), FblaEvent("State Leadership Conference", "March 25–27, 2026", "Galveston", 1774414800000L)),
            "Wisconsin" to listOf(FblaEvent("Region 1 Leadership Conference", "Feb 7, 2026", "Shell Lake", 1770444000000L), FblaEvent("State Leadership Conference", "April 13–14, 2026", "Madison", 1776056400000L))
        )
        statesList.associateWith { (baseEvents[it] ?: listOf(FblaEvent("Regional Leadership Conference", "Jan-Feb 2026", "Various"), FblaEvent("State Leadership Conference", "March-April 2026", "TBD", 1774674000000L))) + nationalConference }
    }
    val states = remember { eventsByState.keys.toList().sorted() }

    // Get all events based on selected state (or all states if none selected)
    val relevantEvents = remember(selectedState, eventsByState) {
        if (selectedState.isEmpty()) {
            // All events from all states - remove duplicates by name and date
            eventsByState.values.flatten().distinctBy { it.name + it.date }
        } else {
            // Events from selected state only
            eventsByState[selectedState] ?: emptyList()
        }
    }

    // Calculate event dates for calendar by parsing date strings
    val eventDates = remember(relevantEvents) {
        relevantEvents
            .flatMap { event -> parseEventDates(event.date) }
            .toSet()
    }

    // Filter events by selected date (only when not in list view)
    val filteredEvents = remember(selectedDate, relevantEvents, showListView) {
        // In list view, show all events regardless of selected date
        if (showListView) {
            relevantEvents
        } else {
            val currentSelectedDate = selectedDate
            if (currentSelectedDate == null) {
                relevantEvents
            } else {
                val selectedDateString = dateFormat.format(currentSelectedDate.time)
                relevantEvents.filter { event ->
                    // Check if the selected date falls within any of the event's dates
                    val eventDates = parseEventDates(event.date)
                    eventDates.contains(selectedDateString)
                }
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        // Background overlay logic based on light/dark mode
        if (lightMode) {
            // Light mode: only white overlay
            Box(modifier = Modifier.fillMaxSize().background(Color.White.copy(alpha = bgOpacity)))
        } else {
            // Dark mode: only black overlay
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgOpacity)))
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "FUTURE BUSINESS LEADERS",
                    style = MaterialTheme.typography.labelLarge.copy(
                        letterSpacing = 5.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp
                    ),
                    color = Color.White.copy(alpha = 0.9f)
                )
                Text(
                    text = if (selectedState.isEmpty()) "Events 2026" else "$selectedState Events",
                    style = MaterialTheme.typography.displaySmall.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = (MaterialTheme.typography.displaySmall.fontSize.value * textSizeMultiplier).sp
                    ),
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(24.dp))
            }

            // Calendar card
            if (!showListView) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .animateContentSize(
                                animationSpec = spring(
                                    dampingRatio = Spring.DampingRatioMediumBouncy,
                                    stiffness = Spring.StiffnessLow
                                )
                            ),
                        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(16.dp)
                                .animateContentSize(
                                    animationSpec = spring(
                                        dampingRatio = Spring.DampingRatioMediumBouncy,
                                        stiffness = Spring.StiffnessLow
                                    )
                                )
                        ) {
                            CalendarView(
                                selectedDate = selectedDate,
                                onDateSelected = { date -> selectedDate = date },
                                eventDates = eventDates,
                                primaryColor = primaryColor,
                                textSizeMultiplier = textSizeMultiplier
                            )

                            selectedDate?.let { date ->
                                Spacer(modifier = Modifier.height(16.dp))
                                HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = displayDateFormat.format(date.time),
                                        color = primaryColor,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontSize = (MaterialTheme.typography.bodyMedium.fontSize.value * textSizeMultiplier).sp
                                        )
                                    )
                                    TextButton(onClick = { selectedDate = null }) {
                                        Text(
                                            "CLEAR",
                                            color = Color.White.copy(alpha = 0.6f),
                                            style = TextStyle(fontSize = (12 * textSizeMultiplier).sp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // State selection / List view button
            item {
                if (selectedState.isEmpty()) {
                    // Show state selection button
                    Box {
                        Button(
                            onClick = { expanded = true },
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.LocationOn, null, tint = Color.Black)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "SELECT STATE",
                                    fontWeight = FontWeight.Bold,
                                    style = TextStyle(fontSize = (14 * textSizeMultiplier).sp),
                                    color = Color.Black
                                )
                                Text(
                                    text = "Filter events by your state",
                                    style = TextStyle(fontSize = (10 * textSizeMultiplier).sp),
                                    color = Color.Black.copy(alpha = 0.7f)
                                )
                            }
                        }
                        DropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false },
                            modifier = Modifier.fillMaxWidth(0.9f)
                        ) {
                            states.forEach { state ->
                                DropdownMenuItem(
                                    onClick = {
                                        selectedState = state
                                        expanded = false
                                        selectedDate = null
                                        showListView = false
                                    },
                                    text = {
                                        Text(state, style = TextStyle(fontSize = (14 * textSizeMultiplier).sp))
                                    }
                                )
                            }
                        }
                    }
                } else {
                    // Show clear state and list view buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = {
                                selectedState = ""
                                selectedDate = null
                                showListView = false
                            },
                            modifier = Modifier.weight(1f).height(64.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF505050)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Close, null, tint = Color.White, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "VIEW ALL STATES",
                                    fontWeight = FontWeight.Bold,
                                    style = TextStyle(fontSize = (11 * textSizeMultiplier).sp),
                                    color = Color.White,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }

                        Button(
                            onClick = {
                                // Clear selected date when entering list view
                                if (!showListView) {
                                    selectedDate = null
                                }
                                showListView = !showListView
                            },
                            modifier = Modifier.weight(1f).height(64.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (showListView) primaryColor else Color.White.copy(alpha = 0.1f)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    if (showListView) Icons.Default.CalendarMonth else Icons.AutoMirrored.Filled.List,
                                    null,
                                    tint = if (showListView) Color.Black else Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (showListView) "SHOW CALENDAR" else "VIEW FULL LIST",
                                    fontWeight = FontWeight.Bold,
                                    style = TextStyle(fontSize = (11 * textSizeMultiplier).sp),
                                    color = if (showListView) Color.Black else Color.White,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }

            // Events list header
            if (showListView || selectedDate != null) {
                item {
                    val eventCount = filteredEvents.size
                    val headerText = when {
                        showListView && selectedState.isNotEmpty() -> "All $selectedState Events ($eventCount)"
                        showListView -> "All Events ($eventCount)"
                        selectedDate != null && eventCount == 0 -> "No events on this date"
                        selectedDate != null -> "$eventCount event${if (eventCount != 1) "s" else ""} on this date"
                        else -> ""
                    }
                    if (headerText.isNotEmpty()) {
                        Text(
                            text = headerText,
                            color = primaryColor,
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp
                            )
                        )
                    }
                }
            }

            // Events list items
            if (showListView || selectedDate != null) {
                itemsIndexed(filteredEvents) { _, event ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .animateContentSize(
                                animationSpec = spring(
                                    dampingRatio = Spring.DampingRatioMediumBouncy,
                                    stiffness = Spring.StiffnessMedium
                                )
                            ),
                        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.1f)),
                        shape = MaterialTheme.shapes.extraSmall
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Text(
                                text = event.name,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = (MaterialTheme.typography.titleMedium.fontSize.value * textSizeMultiplier).sp
                                ),
                                color = Color.White
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CalendarMonth, null, modifier = Modifier.size(16.dp), tint = Color.White.copy(alpha = 0.7f))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = event.date, color = Color.White.copy(alpha = 0.8f), style = TextStyle(fontSize = (14 * textSizeMultiplier).sp))
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.LocationOn, null, modifier = Modifier.size(16.dp), tint = Color.White.copy(alpha = 0.7f))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = event.location, color = Color.White.copy(alpha = 0.8f), style = TextStyle(fontSize = (14 * textSizeMultiplier).sp))
                            }
                            if (auth.currentUser != null && event.timestamp > 0) {
                                Spacer(modifier = Modifier.height(16.dp))

                                // Check if reminder already exists
                                val hasReminder = userReminders.any { it.name == event.name && it.date == event.date }

                                Button(
                                    onClick = {
                                        if (!hasReminder) {
                                            val currentUid = auth.currentUser?.uid
                                            if (!currentUid.isNullOrEmpty()) {
                                                val reminder = CompetitionReminder(event.name, event.date, event.timestamp)
                                                db.collection("users").document(currentUid).update("reminders", FieldValue.arrayUnion(reminder))
                                                    .addOnSuccessListener {
                                                        Toast.makeText(context, "Reminder Set!", Toast.LENGTH_SHORT).show()
                                                    }
                                            }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (hasReminder) Color.Gray else primaryColor,
                                        contentColor = if (hasReminder) Color.White.copy(alpha = 0.5f) else Color.Black
                                    ),
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(8.dp),
                                    enabled = !hasReminder
                                ) {
                                    Icon(
                                        if (hasReminder) Icons.Default.Check else Icons.Default.NotificationsActive,
                                        null,
                                        tint = if (hasReminder) Color.White.copy(alpha = 0.5f) else Color.Black,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        if (hasReminder) "REMINDER SET" else "SET REMINDER",
                                        color = if (hasReminder) Color.White.copy(alpha = 0.5f) else Color.Black,
                                        fontWeight = FontWeight.Bold,
                                        style = TextStyle(fontSize = (14 * textSizeMultiplier).sp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Bottom spacer
            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }
}

@Composable
fun NewsScreen(primaryColor: Color, bgOpacity: Float, isSimplifiedUI: Boolean, textSizeMultiplier: Float, lightMode: Boolean = false) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Dynamic text colors
    val textColor = if (lightMode) Color.Black else Color.White
    val textColorSecondary = if (lightMode) Color.Black.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.6f)
    val textColorTertiary = if (lightMode) Color.Black.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.5f)

    val white = textColor
    val black = if (lightMode) Color.White else Color.Black

    var newsList by remember { mutableStateOf<List<NewsArticle>>(emptyList()) }
    var isLoading by remember { mutableStateOf(false) }
    var lastFetchTime by remember { mutableStateOf(0L) }

    // Function to scrape FBLA news
    suspend fun fetchFBLANews(): List<NewsArticle> = withContext(Dispatchers.IO) {
        try {
            val articles = mutableListOf<NewsArticle>()

            // Scrape FBLA newsroom page (where actual press releases are)
            val doc = org.jsoup.Jsoup.connect("https://www.fbla.org/newsroom/")
                .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .timeout(15000)
                .get()

            Log.d("NewsScreen", "Successfully loaded FBLA newsroom page")

            // Find all article/news elements - taking 20 now
            doc.select("article, .post, .news-item, .press-release, div[class*='news'], div[class*='article']").take(20).forEach { article ->
                try {
                    // Try to find the title and its link
                    val titleElement = article.select("h1, h2, h3, h4, .title, .headline, .entry-title, .post-title, [class*='title']").first()
                    val title = titleElement?.text()?.trim() ?: ""

                    // Try to get the link from the title element or its parent
                    var link = ""

                    // First try: link on the title itself
                    if (titleElement != null) {
                        val titleLink = titleElement.select("a[href]").first()
                        if (titleLink != null) {
                            link = titleLink.attr("abs:href") ?: titleLink.attr("href") ?: ""
                        }

                        // Second try: title is inside a link
                        if (link.isEmpty()) {
                            val parentLink = titleElement.parent()
                            if (parentLink != null && parentLink.tagName() == "a") {
                                link = parentLink.attr("abs:href") ?: parentLink.attr("href") ?: ""
                            }
                        }
                    }

                    // Third try: find any link that's NOT an author link
                    if (link.isEmpty()) {
                        article.select("a[href]").forEach { linkElement ->
                            val href = linkElement.attr("abs:href") ?: linkElement.attr("href") ?: ""
                            // Skip author links, social links, and category links
                            if (!href.contains("/author/") &&
                                !href.contains("facebook.com") &&
                                !href.contains("twitter.com") &&
                                !href.contains("linkedin.com") &&
                                !href.contains("/category/") &&
                                href.isNotEmpty()) {
                                link = href
                                return@forEach // Exit loop once we find a good link
                            }
                        }
                    }

                    // Try to find summary/excerpt
                    val summary = article.select("p, .excerpt, .entry-summary, .description, [class*='excerpt'], [class*='summary']").first()?.text()?.trim()?.take(200) ?: ""

                    // Try to find date
                    val dateStr = article.select("time, .date, .published, .entry-date, [class*='date']").first()?.text()?.trim() ?: ""

                    Log.d("NewsScreen", "Found: title='$title', link='$link', summary='${summary.take(50)}...'")

                    if (title.isNotEmpty() && link.isNotEmpty() && !link.contains("/author/")) {
                        val fullUrl = if (link.startsWith("http")) link else "https://www.fbla.org$link"
                        val formattedDate = if (dateStr.isNotEmpty()) dateStr else {
                            val sdf = SimpleDateFormat("MMM dd, yyyy", Locale.US)
                            sdf.format(Date())
                        }

                        // Use link for summary if summary is empty
                        val finalSummary = if (summary.isNotEmpty()) summary else "Click to read the full article on FBLA.org"

                        Log.d("NewsScreen", "✅ Adding article with URL: $fullUrl")

                        articles.add(NewsArticle(
                            title = title,
                            summary = finalSummary,
                            date = formattedDate,
                            url = fullUrl,
                            tag = determineNewsTag(title, finalSummary),
                            timestamp = System.currentTimeMillis()
                        ))
                    }
                } catch (e: Exception) {
                    Log.e("NewsScreen", "Error parsing article", e)
                }
            }

            Log.d("NewsScreen", "Total articles scraped: ${articles.size}")

            // If scraping didn't work well, add fallback articles (20 curated ones)
            if (articles.size < 5) {
                articles.addAll(listOf(
                    NewsArticle("Architects of Ambition", "The official 2025-2026 national theme focuses on building futures through FBLA.", "Jan 26, 2026", "https://www.fbla.org/news/", "NATIONAL", System.currentTimeMillis()),
                    NewsArticle("NLC 2026 Registration Open", "Join us in Anaheim, California for the National Leadership Conference June 29-July 2.", "Jan 20, 2026", "https://www.fbla.org/nlc/", "CONFERENCE", System.currentTimeMillis() - 86400000),
                    NewsArticle("Updated Competitive Events", "New guidelines released for 2025-2026 high school competitive events.", "Jan 15, 2026", "https://www.fbla.org/high-school/competitive-events/", "HS", System.currentTimeMillis() - 172800000),
                    NewsArticle("Scholarship Opportunities", "Over $250,000 in scholarships available to FBLA members nationwide.", "Jan 10, 2026", "https://www.fbla.org/high-school/program/scholarships/", "OPPORTUNITY", System.currentTimeMillis() - 259200000),
                    NewsArticle("State Leadership Conferences", "SLC season kicks off with competitions in all 50 states and territories.", "Jan 5, 2026", "https://www.fbla.org/slc/", "CONFERENCE", System.currentTimeMillis() - 345600000),
                    NewsArticle("Business Achievement Awards", "Nominations now open for the 2026 Business Achievement Awards program.", "Dec 20, 2025", "https://www.fbla.org/high-school/recognition/business-achievement-awards/", "OPPORTUNITY", System.currentTimeMillis() - 432000000),
                    NewsArticle("Chapter Excellence Awards", "Apply for Chapter Excellence Awards to showcase your chapter's impact.", "Dec 15, 2025", "https://www.fbla.org/chapter-excellence-awards/", "HS", System.currentTimeMillis() - 518400000),
                    NewsArticle("Community Service Projects", "FBLA chapters nationwide complete over 1 million service hours annually.", "Dec 10, 2025", "https://www.fbla.org/community-service/", "NATIONAL", System.currentTimeMillis() - 604800000),
                    NewsArticle("Professional Division Updates", "PBL announces new partnerships with leading corporations for 2026.", "Dec 5, 2025", "https://www.fbla.org/pbl/", "PBL", System.currentTimeMillis() - 691200000),
                    NewsArticle("Middle Level Competitions", "Middle Level competitive events see record participation this year.", "Dec 1, 2025", "https://www.fbla.org/middle-level/", "ML", System.currentTimeMillis() - 777600000),
                    NewsArticle("Membership Drive Success", "FBLA reaches 200,000+ members nationwide for the first time.", "Nov 25, 2025", "https://www.fbla.org/membership/", "NATIONAL", System.currentTimeMillis() - 864000000),
                    NewsArticle("Career Exploration Resources", "New career exploration tools launched on the FBLA website.", "Nov 20, 2025", "https://www.fbla.org/careers/", "OPPORTUNITY", System.currentTimeMillis() - 950400000),
                    NewsArticle("Alumni Spotlight Series", "Meet successful FBLA alumni making an impact in business.", "Nov 15, 2025", "https://www.fbla.org/alumni/", "NATIONAL", System.currentTimeMillis() - 1036800000),
                    NewsArticle("Entrepreneurship Programs", "FBLA launches enhanced entrepreneurship curriculum for all levels.", "Nov 10, 2025", "https://www.fbla.org/entrepreneurship/", "HS", System.currentTimeMillis() - 1123200000),
                    NewsArticle("Leadership Development", "New leadership development workshops available for chapter officers.", "Nov 5, 2025", "https://www.fbla.org/leadership/", "NATIONAL", System.currentTimeMillis() - 1209600000),
                    NewsArticle("Corporate Partnerships", "FBLA announces new corporate partners for student opportunities.", "Nov 1, 2025", "https://www.fbla.org/partners/", "OPPORTUNITY", System.currentTimeMillis() - 1296000000),
                    NewsArticle("Regional Conferences", "Fall regional conferences see high attendance across all divisions.", "Oct 25, 2025", "https://www.fbla.org/conferences/", "CONFERENCE", System.currentTimeMillis() - 1382400000),
                    NewsArticle("Adviser Resources Updated", "New chapter adviser resources and training materials now available.", "Oct 20, 2025", "https://www.fbla.org/advisers/", "NATIONAL", System.currentTimeMillis() - 1468800000),
                    NewsArticle("Digital Marketing Competition", "New digital marketing competitive event added to 2026 lineup.", "Oct 15, 2025", "https://www.fbla.org/competitions/", "HS", System.currentTimeMillis() - 1555200000),
                    NewsArticle("Financial Literacy Initiative", "FBLA launches nationwide financial literacy campaign for students.", "Oct 10, 2025", "https://www.fbla.org/financial-literacy/", "NATIONAL", System.currentTimeMillis() - 1641600000)
                ))
            }

            articles
        } catch (e: Exception) {
            Log.e("NewsScreen", "Error fetching news", e)
            // Return fallback articles on error (20 articles)
            listOf(
                NewsArticle("Architects of Ambition", "The official 2025-2026 national theme focuses on building futures through FBLA.", "Jan 26, 2026", "https://www.fbla.org/news/", "NATIONAL", System.currentTimeMillis()),
                NewsArticle("NLC 2026 Registration Open", "Join us in Anaheim, California for the National Leadership Conference June 29-July 2.", "Jan 20, 2026", "https://www.fbla.org/nlc/", "CONFERENCE", System.currentTimeMillis() - 86400000),
                NewsArticle("Updated Competitive Events", "New guidelines released for 2025-2026 high school competitive events.", "Jan 15, 2026", "https://www.fbla.org/high-school/competitive-events/", "HS", System.currentTimeMillis() - 172800000),
                NewsArticle("Scholarship Opportunities", "Over $250,000 in scholarships available to FBLA members nationwide.", "Jan 10, 2026", "https://www.fbla.org/high-school/program/scholarships/", "OPPORTUNITY", System.currentTimeMillis() - 259200000),
                NewsArticle("State Leadership Conferences", "SLC season kicks off with competitions in all 50 states and territories.", "Jan 5, 2026", "https://www.fbla.org/slc/", "CONFERENCE", System.currentTimeMillis() - 345600000),
                NewsArticle("Business Achievement Awards", "Nominations now open for the 2026 Business Achievement Awards program.", "Dec 20, 2025", "https://www.fbla.org/high-school/recognition/business-achievement-awards/", "OPPORTUNITY", System.currentTimeMillis() - 432000000),
                NewsArticle("Chapter Excellence Awards", "Apply for Chapter Excellence Awards to showcase your chapter's impact.", "Dec 15, 2025", "https://www.fbla.org/chapter-excellence-awards/", "HS", System.currentTimeMillis() - 518400000),
                NewsArticle("Community Service Projects", "FBLA chapters nationwide complete over 1 million service hours annually.", "Dec 10, 2025", "https://www.fbla.org/community-service/", "NATIONAL", System.currentTimeMillis() - 604800000),
                NewsArticle("Professional Division Updates", "PBL announces new partnerships with leading corporations for 2026.", "Dec 5, 2025", "https://www.fbla.org/pbl/", "PBL", System.currentTimeMillis() - 691200000),
                NewsArticle("Middle Level Competitions", "Middle Level competitive events see record participation this year.", "Dec 1, 2025", "https://www.fbla.org/middle-level/", "ML", System.currentTimeMillis() - 777600000),
                NewsArticle("Membership Drive Success", "FBLA reaches 200,000+ members nationwide for the first time.", "Nov 25, 2025", "https://www.fbla.org/membership/", "NATIONAL", System.currentTimeMillis() - 864000000),
                NewsArticle("Career Exploration Resources", "New career exploration tools launched on the FBLA website.", "Nov 20, 2025", "https://www.fbla.org/careers/", "OPPORTUNITY", System.currentTimeMillis() - 950400000),
                NewsArticle("Alumni Spotlight Series", "Meet successful FBLA alumni making an impact in business.", "Nov 15, 2025", "https://www.fbla.org/alumni/", "NATIONAL", System.currentTimeMillis() - 1036800000),
                NewsArticle("Entrepreneurship Programs", "FBLA launches enhanced entrepreneurship curriculum for all levels.", "Nov 10, 2025", "https://www.fbla.org/entrepreneurship/", "HS", System.currentTimeMillis() - 1123200000),
                NewsArticle("Leadership Development", "New leadership development workshops available for chapter officers.", "Nov 5, 2025", "https://www.fbla.org/leadership/", "NATIONAL", System.currentTimeMillis() - 1209600000),
                NewsArticle("Corporate Partnerships", "FBLA announces new corporate partners for student opportunities.", "Nov 1, 2025", "https://www.fbla.org/partners/", "OPPORTUNITY", System.currentTimeMillis() - 1296000000),
                NewsArticle("Regional Conferences", "Fall regional conferences see high attendance across all divisions.", "Oct 25, 2025", "https://www.fbla.org/conferences/", "CONFERENCE", System.currentTimeMillis() - 1382400000),
                NewsArticle("Adviser Resources Updated", "New chapter adviser resources and training materials now available.", "Oct 20, 2025", "https://www.fbla.org/advisers/", "NATIONAL", System.currentTimeMillis() - 1468800000),
                NewsArticle("Digital Marketing Competition", "New digital marketing competitive event added to 2026 lineup.", "Oct 15, 2025", "https://www.fbla.org/competitions/", "HS", System.currentTimeMillis() - 1555200000),
                NewsArticle("Financial Literacy Initiative", "FBLA launches nationwide financial literacy campaign for students.", "Oct 10, 2025", "https://www.fbla.org/financial-literacy/", "NATIONAL", System.currentTimeMillis() - 1641600000)
            )
        }
    }

    // Load news on first launch
    LaunchedEffect(Unit) {
        if (newsList.isEmpty()) {
            isLoading = true
            newsList = fetchFBLANews()
            lastFetchTime = System.currentTimeMillis()
            isLoading = false
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        // Background overlay logic based on light/dark mode
        if (lightMode) {
            // Light mode: only white overlay
            Box(modifier = Modifier.fillMaxSize().background(Color.White.copy(alpha = bgOpacity)))
        } else {
            // Dark mode: only black overlay
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgOpacity)))
        }

        if (isLoading && newsList.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = primaryColor)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(20.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(24.dp))
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "THE FEED",
                                    style = MaterialTheme.typography.labelLarge.copy(
                                        letterSpacing = 4.sp,
                                        fontWeight = FontWeight.Black,
                                        color = primaryColor,
                                        fontSize = (14 * textSizeMultiplier).sp
                                    )
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Latest FBLA News",
                                    style = MaterialTheme.typography.displaySmall.copy(
                                        fontWeight = FontWeight.Black,
                                        color = Color.White,
                                        fontSize = (32 * textSizeMultiplier).sp
                                    )
                                )
                            }

                            // Refresh button
                            Surface(
                                shape = CircleShape,
                                color = primaryColor.copy(alpha = 0.15f),
                                border = BorderStroke(1.dp, primaryColor.copy(alpha = 0.3f))
                            ) {
                                IconButton(
                                    onClick = {
                                        scope.launch {
                                            isLoading = true
                                            newsList = fetchFBLANews()
                                            lastFetchTime = System.currentTimeMillis()
                                            isLoading = false
                                            Toast.makeText(context, "News refreshed!", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                ) {
                                    Icon(
                                        Icons.Default.Refresh,
                                        contentDescription = "Refresh news",
                                        tint = primaryColor,
                                        modifier = if (isLoading) {
                                            Modifier
                                                .size(24.dp)
                                                .graphicsLayer {
                                                    rotationZ = (System.currentTimeMillis() % 1000) / 1000f * 360f
                                                }
                                        } else {
                                            Modifier.size(24.dp)
                                        }
                                    )
                                }
                            }
                        }

                        // Show last updated time
                        if (lastFetchTime > 0) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = Color.Green.copy(alpha = 0.6f),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                val minutes = (System.currentTimeMillis() - lastFetchTime) / 60000
                                Text(
                                    text = if (minutes < 1) "Just updated" else "Updated $minutes min ago",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = Color.White.copy(alpha = 0.5f),
                                        fontSize = (12 * textSizeMultiplier).sp
                                    )
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))
                }

                itemsIndexed(newsList) { index, article ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .animateContentSize(),
                        colors = CardDefaults.cardColors(
                            containerColor = Color.Transparent
                        ),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                        border = BorderStroke(1.dp, primaryColor.copy(alpha = 0.3f)),
                        onClick = {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(article.url)))
                        }
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            primaryColor.copy(alpha = 0.08f),
                                            Color.White.copy(alpha = 0.05f)
                                        )
                                    )
                                )
                        ) {
                            Column(modifier = Modifier.padding(20.dp)) {
                                // Tag and date row
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    // Tag pill
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = primaryColor.copy(alpha = 0.25f),
                                        border = BorderStroke(1.dp, primaryColor.copy(alpha = 0.5f))
                                    ) {
                                        Text(
                                            text = article.tag,
                                            color = primaryColor,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = (10 * textSizeMultiplier).sp,
                                                letterSpacing = 1.sp
                                            ),
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.weight(1f))

                                    // Date
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            Icons.Default.Schedule,
                                            contentDescription = null,
                                            tint = Color.White.copy(alpha = 0.5f),
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = article.date,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontSize = (11 * textSizeMultiplier).sp
                                            ),
                                            color = Color.White.copy(alpha = 0.6f)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                // Title
                                Text(
                                    text = article.title,
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = (20 * textSizeMultiplier).sp,
                                        lineHeight = (26 * textSizeMultiplier).sp
                                    ),
                                    color = Color.White
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                // Summary
                                Text(
                                    text = article.summary,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontSize = (14 * textSizeMultiplier).sp,
                                        lineHeight = (20 * textSizeMultiplier).sp
                                    ),
                                    color = Color.White.copy(alpha = 0.8f),
                                    maxLines = 3
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                // Read more indicator
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "Read Article",
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontSize = (12 * textSizeMultiplier).sp
                                        ),
                                        color = primaryColor
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(
                                        Icons.AutoMirrored.Filled.ArrowForward,
                                        contentDescription = null,
                                        tint = primaryColor,
                                        modifier = Modifier.size(16.dp)
                                    )

                                    Spacer(modifier = Modifier.weight(1f))

                                    // Share button
                                    Surface(
                                        shape = CircleShape,
                                        color = primaryColor.copy(alpha = 0.15f),
                                        border = BorderStroke(1.dp, primaryColor.copy(alpha = 0.3f)),
                                        modifier = Modifier.clickable {
                                            shareArticle(context, article.title, article.url)
                                        }
                                    ) {
                                        Icon(
                                            Icons.Default.Share,
                                            contentDescription = "Share Article",
                                            tint = primaryColor,
                                            modifier = Modifier
                                                .padding(8.dp)
                                                .size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fun determineNewsTag(title: String, summary: String): String {
    val text = (title + " " + summary).lowercase()

    return when {
        text.contains("nlc") || text.contains("slc") || text.contains("conference") -> "CONFERENCE"
        text.contains("scholarship") || text.contains("award") || text.contains("opportunity") -> "OPPORTUNITY"
        text.contains("high school") || text.contains("hs") -> "HS"
        text.contains("middle") || text.contains("ml") -> "ML"
        text.contains("college") || text.contains("pbl") -> "PBL"
        else -> "NATIONAL"
    }
}

fun shareArticle(context: Context, title: String, url: String) {
    val shareText = "$title\n\nRead more: $url"
    val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, shareText)
        putExtra(Intent.EXTRA_SUBJECT, title)
    }
    val chooser = Intent.createChooser(shareIntent, "Share Article")
    context.startActivity(chooser)
}

@Composable
fun SocialMediaLogo(platform: String, modifier: Modifier = Modifier) {
    when (platform) {
        "Instagram" -> {
            Image(
                painter = painterResource(id = R.drawable.instagram_logo),
                contentDescription = "Instagram",
                modifier = modifier
                    .size(32.dp)
                    .border(2.dp, Color.White, CircleShape)
                    .clip(CircleShape)
            )
        }
        "X (Twitter)" -> {
            Box(
                modifier = modifier
                    .size(32.dp)
                    .border(2.dp, Color.White, CircleShape)
                    .background(Color(0xFF000000), shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "𝕏",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        "Facebook" -> {
            Box(
                modifier = modifier
                    .size(32.dp)
                    .border(2.dp, Color.White, CircleShape)
                    .background(Color(0xFF1877F2), shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "f",
                    color = Color.White,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif
                )
            }
        }
        "LinkedIn" -> {
            Box(
                modifier = modifier
                    .size(32.dp)
                    .border(2.dp, Color.White, CircleShape)
                    .background(Color(0xFF0A66C2), shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "in",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun ResourcesScreen(primaryColor: Color, bgOpacity: Float, isSimplifiedUI: Boolean, textSizeMultiplier: Float, lightMode: Boolean = false, userState: String = "", userSchool: String = "") {
    // Dynamic text colors
    val textColor = if (lightMode) Color.Black else Color.White
    val textColorSecondary = if (lightMode) Color.Black.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.6f)
    val textColorTertiary = if (lightMode) Color.Black.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.5f)

    val white = textColor
    val black = if (lightMode) Color.White else Color.Black

    val context = LocalContext.current
    val resourceList = remember {
        listOf(
            ResourceItem("Guidelines", "Requirements for all High School events.", "https://www.fbla.org/high-school/competitive-events/", Icons.AutoMirrored.Filled.Assignment),
            ResourceItem("HS 101 Toolkit", "Essential toolkit for high school management.", "https://www.fbla.org/media/2023/05/FBLA-High-School-101-Toolkit.pdf", Icons.AutoMirrored.Filled.LibraryBooks),
            ResourceItem("Brand Center", "Official logos and professional standards.", "https://www.fbla.org/brand-center/", Icons.Default.Brush),
            ResourceItem("Dress Code", "Attire standards for conferences.", "https://www.fbla.org/dress-code/", Icons.Default.Checkroom)
        )
    }

    data class SocialMedia(val name: String, val handle: String, val url: String)
    val socialMediaList = remember {
        listOf(
            SocialMedia("Instagram", "@fbla_national", "https://www.instagram.com/fbla_national/"),
            SocialMedia("X (Twitter)", "@FBLA_National", "https://twitter.com/FBLA_National"),
            SocialMedia("Facebook", "FutureBusinessLeaders", "https://www.facebook.com/FutureBusinessLeaders/"),
            SocialMedia("LinkedIn", "FBLA", "https://www.linkedin.com/company/future-business-leaders-america")
        )
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        // Background overlay logic based on light/dark mode
        if (lightMode) {
            // Light mode: only white overlay
            Box(modifier = Modifier.fillMaxSize().background(Color.White.copy(alpha = bgOpacity)))
        } else {
            // Dark mode: only black overlay
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgOpacity)))
        }

        LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(24.dp)) {
            item {
                Spacer(modifier = Modifier.height(24.dp))
                Text(text = "TOOLKIT", style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 4.sp, fontWeight = FontWeight.Bold, color = primaryColor, fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp))
                Text(text = "LeadLink Resources", style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.Black, color = textColor, fontSize = (MaterialTheme.typography.displaySmall.fontSize.value * textSizeMultiplier).sp))
                Spacer(modifier = Modifier.height(32.dp))
            }

            // Resources Grid Header
            item {
                Text(
                    text = "RESOURCES",
                    style = MaterialTheme.typography.labelMedium.copy(
                        letterSpacing = 2.sp,
                        fontWeight = FontWeight.Bold,
                        fontSize = (MaterialTheme.typography.labelMedium.fontSize.value * textSizeMultiplier).sp
                    ),
                    color = primaryColor
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Resources Grid
            resourceList.chunked(2).forEach { rowItems ->
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        rowItems.forEach { resource ->
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(180.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.08f)),
                                shape = RoundedCornerShape(16.dp),
                                onClick = {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(resource.url)))
                                }
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxSize().padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Icon(resource.icon, null, modifier = Modifier.size(40.dp), tint = primaryColor)
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = resource.title,
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontSize = (MaterialTheme.typography.titleMedium.fontSize.value * textSizeMultiplier).sp
                                        ),
                                        color = Color.White,
                                        textAlign = TextAlign.Center
                                    )
                                    Text(
                                        text = "VIEW",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Black,
                                            fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * textSizeMultiplier).sp
                                        ),
                                        color = primaryColor
                                    )
                                }
                            }
                        }
                        // Add spacer if odd number of items
                        if (rowItems.size == 1) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(32.dp))
            }

            // Social Media Section
            item {
                Text(
                    text = "SOCIAL MEDIA",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = (MaterialTheme.typography.titleSmall.fontSize.value * textSizeMultiplier).sp,
                        letterSpacing = 1.2.sp
                    ),
                    color = primaryColor,
                    modifier = Modifier.padding(bottom = 12.dp, top = 8.dp)
                )
            }

            items(socialMediaList.size) { index ->
                val social = socialMediaList[index]
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.08f)),
                    shape = RoundedCornerShape(12.dp),
                    onClick = {
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse(social.url))
                        )
                    }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            SocialMediaLogo(
                                platform = social.name,
                                modifier = Modifier.size(32.dp)
                            )
                            Text(
                                text = social.name,
                                color = Color.White,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = (16 * textSizeMultiplier).sp
                                )
                            )
                        }
                        Icon(
                            Icons.Default.OpenInNew,
                            contentDescription = "Open ${social.name}",
                            tint = primaryColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(32.dp))
            }

            // State FBLA Social Media Section
            if (userState.isNotEmpty()) {
                item {
                    Text(
                        text = "$userState FBLA",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = (MaterialTheme.typography.titleSmall.fontSize.value * textSizeMultiplier).sp,
                            letterSpacing = 1.2.sp
                        ),
                        color = primaryColor,
                        modifier = Modifier.padding(bottom = 12.dp, top = 8.dp)
                    )
                }

                val stateSocialMedia = getStateFBLASocialMedia(userState)
                if (stateSocialMedia.isNotEmpty()) {
                    items(stateSocialMedia.keys.toList().size) { index ->
                        val platform = stateSocialMedia.keys.toList()[index]
                        val url = stateSocialMedia[platform] ?: ""
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp),
                            colors = CardDefaults.cardColors(containerColor = primaryColor.copy(alpha = 0.15f)),
                            shape = RoundedCornerShape(12.dp),
                            onClick = {
                                context.startActivity(
                                    Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                )
                            }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 20.dp, vertical = 18.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    SocialMediaLogo(
                                        platform = platform,
                                        modifier = Modifier.size(32.dp)
                                    )
                                    Text(
                                        text = platform,
                                        color = textColor,
                                        style = MaterialTheme.typography.bodyLarge.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = (16 * textSizeMultiplier).sp
                                        )
                                    )
                                }
                                Icon(
                                    Icons.Default.OpenInNew,
                                    contentDescription = "Open $platform",
                                    tint = primaryColor,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }

            // Sun Prairie Chapter Section (Wisconsin only)
            if (userState.equals("Wisconsin", ignoreCase = true) && userSchool.contains("Sun Prairie", ignoreCase = true)) {
                item {
                    Text(
                        text = "Sun Prairie FBLA Chapter",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = (MaterialTheme.typography.titleSmall.fontSize.value * textSizeMultiplier).sp,
                            letterSpacing = 1.2.sp
                        ),
                        color = primaryColor,
                        modifier = Modifier.padding(bottom = 4.dp, top = 8.dp)
                    )
                    Text(
                        text = "SP West High School",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontSize = (12 * textSizeMultiplier).sp
                        ),
                        color = textColorSecondary,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                }

                val chapterSocialMedia = getSunPrairieChapterSocialMedia()
                items(chapterSocialMedia.keys.toList().size) { index ->
                    val platform = chapterSocialMedia.keys.toList()[index]
                    val url = chapterSocialMedia[platform] ?: ""
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        colors = CardDefaults.cardColors(containerColor = primaryColor.copy(alpha = 0.1f)),
                        shape = RoundedCornerShape(12.dp),
                        onClick = {
                            context.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse(url))
                            )
                        }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 18.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                SocialMediaLogo(
                                    platform = platform,
                                    modifier = Modifier.size(32.dp)
                                )
                                Text(
                                    text = platform,
                                    color = textColor,
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = (16 * textSizeMultiplier).sp
                                    )
                                )
                            }
                            Icon(
                                Icons.Default.OpenInNew,
                                contentDescription = "Open $platform",
                                tint = primaryColor,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun ConnectionRequestsScreen(onBack: () -> Unit, primaryColor: Color, bgOpacity: Float, isSimplifiedUI: Boolean, textSizeMultiplier: Float, lightMode: Boolean = false) {
    // Dynamic text colors
    val textColor = if (lightMode) Color.Black else Color.White
    val textColorSecondary = if (lightMode) Color.Black.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.6f)
    val textColorTertiary = if (lightMode) Color.Black.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.5f)

    val white = textColor
    val black = if (lightMode) Color.White else Color.Black

    val db = FirebaseFirestore.getInstance()
    val auth = FirebaseAuth.getInstance()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var requests by remember { mutableStateOf<List<ConnectionRequest>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        val currentUid = auth.currentUser?.uid
        if (currentUid != null) {
            db.collection("connectionRequests")
                .whereEqualTo("toUid", currentUid)
                .whereEqualTo("status", "pending")
                .addSnapshotListener { snapshot, _ ->
                    requests = snapshot?.toObjects(ConnectionRequest::class.java) ?: emptyList()
                    isLoading = false
                }
        } else {
            isLoading = false
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        // Background overlay logic based on light/dark mode
        if (lightMode) {
            // Light mode: only white overlay
            Box(modifier = Modifier.fillMaxSize().background(Color.White.copy(alpha = bgOpacity)))
        } else {
            // Dark mode: only black overlay
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgOpacity)))
        }

        Column(modifier = Modifier.fillMaxSize()) {
            Spacer(modifier = Modifier.height(24.dp))
            Row(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Text("CONNECTION REQUESTS", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black, fontSize = (MaterialTheme.typography.headlineSmall.fontSize.value * textSizeMultiplier).sp), color = Color.White)
            }

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = primaryColor)
                }
            } else if (requests.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.PersonAdd, null, modifier = Modifier.size(80.dp), tint = Color.White.copy(alpha = 0.2f))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("No pending requests", color = Color.White.copy(alpha = 0.6f), style = MaterialTheme.typography.bodyLarge.copy(fontSize = (MaterialTheme.typography.bodyLarge.fontSize.value * textSizeMultiplier).sp))
                    }
                }
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                    itemsIndexed(requests) { _, request ->
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(modifier = Modifier.size(50.dp).background(primaryColor, CircleShape).clip(CircleShape)) {
                                        if (request.fromPfpUrl.isNotEmpty()) {
                                            AsyncImage(model = request.fromPfpUrl, contentDescription = null, contentScale = ContentScale.Crop)
                                        } else {
                                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                                Text(request.fromName.take(1).uppercase(), color = Color.Black, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = (16 * textSizeMultiplier).sp))
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(request.fromName, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium.copy(fontSize = (MaterialTheme.typography.titleMedium.fontSize.value * textSizeMultiplier).sp))
                                        Text(request.fromSchool, color = primaryColor, style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp))
                                        Text(request.fromEmail, color = Color.White.copy(alpha = 0.5f), style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp))
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Button(
                                        onClick = {
                                            scope.launch {
                                                try {
                                                    val currentUid = auth.currentUser?.uid ?: return@launch

                                                    // Add to both users' connections FIRST (before changing status)
                                                    db.collection("connections").document(currentUid)
                                                        .set(mapOf("connectedUids" to FieldValue.arrayUnion(request.fromUid)), com.google.firebase.firestore.SetOptions.merge()).await()

                                                    db.collection("connections").document(request.fromUid)
                                                        .set(mapOf("connectedUids" to FieldValue.arrayUnion(currentUid)), com.google.firebase.firestore.SetOptions.merge()).await()

                                                    // Update request status LAST (this removes it from the list)
                                                    db.collection("connectionRequests").document(request.id)
                                                        .update("status", "accepted").await()

                                                    Toast.makeText(context, "Request accepted!", Toast.LENGTH_SHORT).show()
                                                } catch (e: Exception) {
                                                    Log.e("ConnectionRequest", "Error accepting request: ${e.message}", e)
                                                    Toast.makeText(context, "Failed to accept: ${e.message}", Toast.LENGTH_LONG).show()
                                                }
                                            }
                                        },
                                        modifier = Modifier.weight(1f).height(40.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.Green),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("ACCEPT", color = Color.White, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = (12 * textSizeMultiplier).sp))
                                    }

                                    Button(
                                        onClick = {
                                            scope.launch {
                                                try {
                                                    db.collection("connectionRequests").document(request.id)
                                                        .update("status", "declined").await()
                                                    Toast.makeText(context, "Request declined", Toast.LENGTH_SHORT).show()
                                                } catch (e: Exception) {
                                                    Log.e("ConnectionRequest", "Error declining request: ${e.message}", e)
                                                    Toast.makeText(context, "Failed to decline: ${e.message}", Toast.LENGTH_LONG).show()
                                                }
                                            }
                                        },
                                        modifier = Modifier.weight(1f).height(40.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC143C)),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.Close, null, tint = Color.White, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("DECLINE", color = Color.White, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = (12 * textSizeMultiplier).sp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MyConnectionsScreen(onBack: () -> Unit, primaryColor: Color, bgOpacity: Float, isSimplifiedUI: Boolean, textSizeMultiplier: Float, lightMode: Boolean = false) {
    // Dynamic text colors
    val textColor = if (lightMode) Color.Black else Color.White
    val textColorSecondary = if (lightMode) Color.Black.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.6f)
    val textColorTertiary = if (lightMode) Color.Black.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.5f)

    val white = textColor
    val black = if (lightMode) Color.White else Color.Black

    val db = FirebaseFirestore.getInstance()
    val auth = FirebaseAuth.getInstance()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var connections by remember { mutableStateOf<List<Connection>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var showRemoveDialog by remember { mutableStateOf(false) }
    var connectionToRemove by remember { mutableStateOf<Connection?>(null) }

    LaunchedEffect(Unit) {
        val currentUid = auth.currentUser?.uid
        if (currentUid != null) {
            db.collection("connections").document(currentUid).addSnapshotListener { snapshot, _ ->
                val connectedUids = (snapshot?.get("connectedUids") as? List<*>)?.mapNotNull { it as? String } ?: emptyList()

                if (connectedUids.isEmpty()) {
                    connections = emptyList()
                    isLoading = false
                } else {
                    // Fetch user profiles for connected users
                    db.collection("users").whereIn("uid", connectedUids).addSnapshotListener { usersSnapshot, _ ->
                        connections = usersSnapshot?.toObjects(UserProfile::class.java)?.map { profile ->
                            Connection(
                                uid = profile.uid,
                                name = profile.name,
                                email = profile.email,
                                school = profile.school,
                                year = profile.year,
                                state = profile.state,
                                pfpUrl = profile.pfpUrl,
                                reminders = profile.reminders,
                                instagram = profile.instagram,
                                twitter = profile.twitter,
                                facebook = profile.facebook,
                                linkedin = profile.linkedin
                            )
                        } ?: emptyList()
                        isLoading = false
                    }
                }
            }
        } else {
            isLoading = false
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        // Background overlay based on light/dark mode
        if (lightMode) {
            // Light mode: add white overlay
            Box(modifier = Modifier.fillMaxSize().background(Color.White.copy(alpha = bgOpacity)))
        } else {
            // Dark mode: add black overlay
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgOpacity)))
        }

        Column(modifier = Modifier.fillMaxSize()) {
            Spacer(modifier = Modifier.height(24.dp))
            Row(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Text("MY CONNECTIONS", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black, fontSize = (MaterialTheme.typography.headlineSmall.fontSize.value * textSizeMultiplier).sp), color = Color.White)
            }

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = primaryColor)
                }
            } else if (connections.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.People, null, modifier = Modifier.size(80.dp), tint = Color.White.copy(alpha = 0.2f))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("No connections yet", color = Color.White.copy(alpha = 0.6f), style = MaterialTheme.typography.bodyLarge.copy(fontSize = (MaterialTheme.typography.bodyLarge.fontSize.value * textSizeMultiplier).sp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Send connection requests to other peers!", color = Color.White.copy(alpha = 0.4f), style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp), textAlign = TextAlign.Center)
                    }
                }
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                    itemsIndexed(connections) { _, connection ->
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Box(modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(modifier = Modifier.size(50.dp).background(primaryColor, CircleShape).clip(CircleShape)) {
                                            if (connection.pfpUrl.isNotEmpty()) {
                                                AsyncImage(model = connection.pfpUrl, contentDescription = null, contentScale = ContentScale.Crop)
                                            } else {
                                                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                                    Text(connection.name.take(1).uppercase(), color = Color.Black, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = (16 * textSizeMultiplier).sp))
                                                }
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(16.dp))
                                        Column {
                                            Text(connection.name, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge.copy(fontSize = (MaterialTheme.typography.titleLarge.fontSize.value * textSizeMultiplier).sp))
                                            Text(connection.school, color = primaryColor, style = MaterialTheme.typography.bodyMedium.copy(fontSize = (MaterialTheme.typography.bodyMedium.fontSize.value * textSizeMultiplier).sp))
                                            if (connection.year.isNotEmpty() || connection.state.isNotEmpty()) {
                                                Text(
                                                    text = "Class of ${connection.year.ifEmpty { "?" }} • ${connection.state.ifEmpty { "?" }}",
                                                    color = Color.White.copy(alpha = 0.6f),
                                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp)
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))

                                    // Email with clickable intent
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable {
                                        val intent = Intent(Intent.ACTION_SENDTO).apply {
                                            data = Uri.parse("mailto:${connection.email}")
                                        }
                                        try {
                                            auth.currentUser?.let { intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK }
                                        } catch (e: Exception) { }
                                    }) {
                                        Icon(Icons.Default.Email, null, tint = primaryColor, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(connection.email, color = Color.White, style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp))
                                    }

                                    // Social Media Icons
                                    val hasSocial = connection.instagram.isNotEmpty() || connection.twitter.isNotEmpty() || connection.facebook.isNotEmpty() || connection.linkedin.isNotEmpty()
                                    if (hasSocial) {
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.Start,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "Social Media:",
                                                color = Color.White.copy(alpha = 0.6f),
                                                style = MaterialTheme.typography.labelSmall.copy(fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * textSizeMultiplier).sp),
                                                fontWeight = FontWeight.Bold
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))

                                            if (connection.instagram.isNotEmpty()) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(32.dp)
                                                        .clickable {
                                                            val url = normalizeSocialMediaUrl(connection.instagram)
                                                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                                        }
                                                ) {
                                                    SocialMediaLogo(platform = "Instagram", modifier = Modifier.size(32.dp))
                                                }
                                                Spacer(modifier = Modifier.width(8.dp))
                                            }
                                            if (connection.twitter.isNotEmpty()) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(32.dp)
                                                        .clickable {
                                                            val url = normalizeSocialMediaUrl(connection.twitter)
                                                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                                        }
                                                ) {
                                                    SocialMediaLogo(platform = "X (Twitter)", modifier = Modifier.size(32.dp))
                                                }
                                                Spacer(modifier = Modifier.width(8.dp))
                                            }
                                            if (connection.facebook.isNotEmpty()) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(32.dp)
                                                        .clickable {
                                                            val url = normalizeSocialMediaUrl(connection.facebook)
                                                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                                        }
                                                ) {
                                                    SocialMediaLogo(platform = "Facebook", modifier = Modifier.size(32.dp))
                                                }
                                                Spacer(modifier = Modifier.width(8.dp))
                                            }
                                            if (connection.linkedin.isNotEmpty()) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(32.dp)
                                                        .clickable {
                                                            val url = normalizeSocialMediaUrl(connection.linkedin)
                                                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                                        }
                                                ) {
                                                    SocialMediaLogo(platform = "LinkedIn", modifier = Modifier.size(32.dp))
                                                }
                                            }
                                        }
                                    }

                                    if (connection.reminders.isNotEmpty()) {
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text("Attending Competitions:", color = Color.White.copy(alpha = 0.6f), style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * textSizeMultiplier).sp))
                                        connection.reminders.forEach { reminder ->
                                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                                                Icon(Icons.Default.EmojiEvents, null, tint = primaryColor, modifier = Modifier.size(14.dp))
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text("${reminder.name} - ${reminder.date}", color = Color.White, style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp))
                                            }
                                        }
                                    }
                                }

                                // Small red X button in bottom right
                                IconButton(
                                    onClick = {
                                        connectionToRemove = connection
                                        showRemoveDialog = true
                                    },
                                    modifier = Modifier
                                        .align(Alignment.BottomEnd)
                                        .size(32.dp)
                                        .padding(4.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Close,
                                        contentDescription = "Remove connection",
                                        tint = Color(0xFFDC143C),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Confirmation Dialog
        if (showRemoveDialog && connectionToRemove != null) {
            AlertDialog(
                onDismissRequest = {
                    showRemoveDialog = false
                    connectionToRemove = null
                },
                title = {
                    Text("Remove Connection?", color = Color.White, fontWeight = FontWeight.Bold)
                },
                text = {
                    Text("Are you sure you want to remove ${connectionToRemove?.name} from your connections?", color = Color.White.copy(alpha = 0.8f))
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            scope.launch {
                                try {
                                    val currentUid = auth.currentUser?.uid ?: return@launch
                                    val otherUid = connectionToRemove?.uid ?: return@launch

                                    // Remove from both users' connections
                                    db.collection("connections").document(currentUid)
                                        .update("connectedUids", FieldValue.arrayRemove(otherUid)).await()

                                    db.collection("connections").document(otherUid)
                                        .update("connectedUids", FieldValue.arrayRemove(currentUid)).await()

                                    Toast.makeText(context, "Connection removed", Toast.LENGTH_SHORT).show()
                                    showRemoveDialog = false
                                    connectionToRemove = null
                                } catch (e: Exception) {
                                    Log.e("RemoveConnection", "Error removing connection: ${e.message}", e)
                                    Toast.makeText(context, "Failed to remove: ${e.message}", Toast.LENGTH_LONG).show()
                                }
                            }
                        }
                    ) {
                        Text("REMOVE", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            showRemoveDialog = false
                            connectionToRemove = null
                        }
                    ) {
                        Text("CANCEL", color = Color.White.copy(alpha = 0.7f))
                    }
                },
                containerColor = Color(0xFF1A1A1A),
                titleContentColor = Color.White,
                textContentColor = Color.White
            )
        }
    }
}

@Composable
fun MessagesScreen(
    primaryColor: Color,
    bgOpacity: Float,
    isSimplifiedUI: Boolean,
    textSizeMultiplier: Float,
    lightMode: Boolean = false,
    onBack: () -> Unit,
    onOpenChat: (String, String) -> Unit
) {
    // Dynamic text colors
    val textColor = if (lightMode) Color.Black else Color.White
    val textColorSecondary = if (lightMode) Color.Black.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.6f)
    val textColorTertiary = if (lightMode) Color.Black.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.5f)

    val white = textColor
    val black = if (lightMode) Color.White else Color.Black

    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    val context = LocalContext.current

    var connections by remember { mutableStateOf<List<Connection>>(emptyList()) }
    var conversations by remember { mutableStateOf<Map<String, Conversation>>(emptyMap()) }

    // Load connections
    LaunchedEffect(Unit) {
        val currentUid = auth.currentUser?.uid ?: return@LaunchedEffect

        db.collection("connections").document(currentUid)
            .addSnapshotListener { snapshot, _ ->
                val connectedUids = snapshot?.get("connectedUids") as? List<String> ?: emptyList()

                if (connectedUids.isNotEmpty()) {
                    db.collection("users").whereIn("uid", connectedUids)
                        .addSnapshotListener { usersSnapshot, _ ->
                            connections = usersSnapshot?.documents?.mapNotNull { doc ->
                                doc.toObject(UserProfile::class.java)?.let { profile ->
                                    Connection(
                                        uid = profile.uid,
                                        name = profile.name,
                                        email = profile.email,
                                        school = profile.school,
                                        pfpUrl = profile.pfpUrl
                                    )
                                }
                            } ?: emptyList()
                        }
                } else {
                    connections = emptyList()
                }
            }

        // Load conversations with last messages
        db.collection("messages")
            .where(com.google.firebase.firestore.Filter.or(
                com.google.firebase.firestore.Filter.equalTo("senderId", currentUid),
                com.google.firebase.firestore.Filter.equalTo("receiverId", currentUid)
            ))
            .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, _ ->
                val convos = mutableMapOf<String, Conversation>()
                snapshot?.documents?.forEach { doc ->
                    val msg = doc.toObject(ChatMessage::class.java) ?: return@forEach
                    val otherUserId = if (msg.senderId == currentUid) msg.receiverId else msg.senderId

                    if (!convos.containsKey(otherUserId)) {
                        val connection = connections.find { it.uid == otherUserId }
                        convos[otherUserId] = Conversation(
                            otherUserId = otherUserId,
                            otherUserName = connection?.name ?: "Unknown User",
                            otherUserPfp = connection?.pfpUrl ?: "",
                            lastMessage = msg.message,
                            lastMessageTime = msg.timestamp
                        )
                    }
                }
                conversations = convos
            }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        // Background overlay based on light/dark mode
        if (lightMode) {
            // Light mode: add white overlay
            Box(modifier = Modifier.fillMaxSize().background(Color.White.copy(alpha = bgOpacity)))
        } else {
            // Dark mode: add black overlay
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgOpacity)))
        }

        Column(modifier = Modifier.fillMaxSize()) {
            // Header with back button
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFF1A1A1A),
                shadowElevation = 4.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 40.dp, start = 16.dp, end = 16.dp, bottom = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "MESSAGES",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Black,
                                color = primaryColor,
                                fontSize = (MaterialTheme.typography.titleLarge.fontSize.value * textSizeMultiplier).sp
                            )
                        )
                        Text(
                            "Chat with your connections",
                            color = Color.White.copy(alpha = 0.6f),
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp)
                        )
                    }
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(24.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }

                if (connections.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(40.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    Icons.Default.Chat,
                                    contentDescription = null,
                                    tint = Color.White.copy(alpha = 0.3f),
                                    modifier = Modifier.size(64.dp)
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    "No Connections Yet",
                                    color = Color.White.copy(alpha = 0.6f),
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium.copy(fontSize = (MaterialTheme.typography.titleMedium.fontSize.value * textSizeMultiplier).sp)
                                )
                                Text(
                                    "Connect with other members to start messaging",
                                    color = Color.White.copy(alpha = 0.4f),
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                } else {
                    items(connections.size) { index ->
                        val connection = connections[index]
                        val conversation = conversations[connection.uid]

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp),
                            onClick = { onOpenChat(connection.uid, connection.name) },
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A)),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(CircleShape)
                                        .background(primaryColor.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (connection.pfpUrl.isNotEmpty()) {
                                        AsyncImage(
                                            model = connection.pfpUrl,
                                            contentDescription = null,
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = ContentScale.Crop
                                        )
                                    } else {
                                        Icon(
                                            Icons.Default.Person,
                                            contentDescription = null,
                                            tint = primaryColor,
                                            modifier = Modifier.size(32.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(16.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        connection.name,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleMedium.copy(fontSize = (MaterialTheme.typography.titleMedium.fontSize.value * textSizeMultiplier).sp)
                                    )

                                }

                                Icon(
                                    Icons.AutoMirrored.Filled.ArrowForward,
                                    contentDescription = null,
                                    tint = primaryColor,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
fun ChatScreen(
    otherUserId: String,
    onBack: () -> Unit,
    primaryColor: Color,
    bgOpacity: Float,
    isSimplifiedUI: Boolean,
    textSizeMultiplier: Float,
    lightMode: Boolean = false
) {
    // Dynamic text colors
    val textColor = if (lightMode) Color.Black else Color.White
    val textColorSecondary = if (lightMode) Color.Black.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.6f)
    val textColorTertiary = if (lightMode) Color.Black.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.5f)

    val white = textColor
    val black = if (lightMode) Color.White else Color.Black

    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    val context = LocalContext.current
    val currentUserId = auth.currentUser?.uid ?: ""

    var messages by remember { mutableStateOf<List<ChatMessage>>(emptyList()) }
    var messageText by remember { mutableStateOf("") }
    var otherUserProfile by remember { mutableStateOf<UserProfile?>(null) }
    var previousMessageCount by remember { mutableStateOf(0) }
    var newMessageIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var selectedMessage by remember { mutableStateOf<ChatMessage?>(null) }
    var showMessageOptions by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    // Load other user profile
    LaunchedEffect(otherUserId) {
        db.collection("users").document(otherUserId).get().addOnSuccessListener { snapshot ->
            otherUserProfile = snapshot.toObject(UserProfile::class.java)
        }
    }

    // Load messages
    LaunchedEffect(Unit) {
        // Listen for messages in this conversation
        val listener = db.collection("messages")
            .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    android.util.Log.e("ChatScreen", "Error loading messages", error)
                    Toast.makeText(context, "Error loading messages: ${error.message}", Toast.LENGTH_SHORT).show()
                    return@addSnapshotListener
                }

                // Filter messages for this conversation
                val allMessages = snapshot?.documents?.mapNotNull {
                    try {
                        it.toObject(ChatMessage::class.java)
                    } catch (e: Exception) {
                        android.util.Log.e("ChatScreen", "Error parsing message", e)
                        null
                    }
                } ?: emptyList()

                val conversationMessages = allMessages.filter { msg ->
                    (msg.senderId == currentUserId && msg.receiverId == otherUserId) ||
                            (msg.senderId == otherUserId && msg.receiverId == currentUserId)
                }

                android.util.Log.d("ChatScreen", "Loaded ${conversationMessages.size} messages from Firebase")

                // Merge with existing messages (keep optimistic updates)
                val currentMessageIds = messages.map { it.id }.toSet()
                val newFromFirebase = conversationMessages.filter { it.id !in currentMessageIds }

                // Check if there's a new message from the other user
                if (newFromFirebase.isNotEmpty()) {
                    val latestNew = newFromFirebase.lastOrNull()
                    if (latestNew?.senderId == otherUserId) {
                        // Send notification for new message
                        sendMessageNotification(
                            context,
                            latestNew.senderName.ifEmpty { otherUserProfile?.name ?: "Unknown User" },
                            latestNew.message
                        )
                        // Mark as new for animation
                        newMessageIds = newMessageIds + latestNew.id
                        scope.launch {
                            delay(500)
                            newMessageIds = newMessageIds - latestNew.id
                        }
                    }
                }

                // Update messages list (keeping existing + adding new from Firebase)
                if (newFromFirebase.isNotEmpty()) {
                    messages = conversationMessages
                    scope.launch {
                        if (messages.isNotEmpty()) {
                            listState.animateScrollToItem(messages.size - 1)
                        }
                    }
                }

                previousMessageCount = conversationMessages.size
            }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        // Background overlay based on light/dark mode
        if (lightMode) {
            // Light mode: add white overlay
            Box(modifier = Modifier.fillMaxSize().background(Color.White.copy(alpha = bgOpacity)))
        } else {
            // Dark mode: add black overlay
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgOpacity)))
        }

        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFF1A1A1A),
                shadowElevation = 4.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 40.dp, start = 16.dp, end = 16.dp, bottom = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }

                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(primaryColor.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (otherUserProfile?.pfpUrl?.isNotEmpty() == true) {
                            AsyncImage(
                                model = otherUserProfile!!.pfpUrl,
                                contentDescription = null,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Icon(Icons.Default.Person, contentDescription = null, tint = primaryColor, modifier = Modifier.size(24.dp))
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            otherUserProfile?.name ?: "Loading...",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium.copy(fontSize = (MaterialTheme.typography.titleMedium.fontSize.value * textSizeMultiplier).sp)
                        )
                        if (otherUserProfile?.school?.isNotEmpty() == true) {
                            Text(
                                otherUserProfile!!.school,
                                color = Color.White.copy(alpha = 0.6f),
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp)
                            )
                        } else {
                            Text(
                                "${messages.size} messages",
                                color = Color.White.copy(alpha = 0.5f),
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp)
                            )
                        }
                    }
                }
            }

            // Messages list
            Box(modifier = Modifier.weight(1f)) {
                if (messages.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(vertical = 100.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            Icons.Default.Chat,
                            contentDescription = null,
                            tint = Color.White.copy(alpha = 0.2f),
                            modifier = Modifier.size(80.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            "No messages yet",
                            color = Color.White.copy(alpha = 0.4f),
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        state = listState,
                        contentPadding = PaddingValues(16.dp)
                    ) {
                        items(messages.size) { index ->
                            val message = messages[index]
                            val isMe = message.senderId == currentUserId
                            val isNew = message.id in newMessageIds

                            // Check if this is the last message from this sender (show timestamp)
                            val isLastInGroup = index == messages.size - 1 || messages[index + 1].senderId != message.senderId

                            // Animation state
                            val animatedAlpha = remember { androidx.compose.animation.core.Animatable(if (isNew) 0f else 1f) }
                            val animatedOffset = remember { androidx.compose.animation.core.Animatable(if (isNew) 50f else 0f) }

                            LaunchedEffect(isNew) {
                                if (isNew) {
                                    launch {
                                        animatedAlpha.animateTo(
                                            targetValue = 1f,
                                            animationSpec = androidx.compose.animation.core.tween(durationMillis = 300)
                                        )
                                    }
                                    launch {
                                        animatedOffset.animateTo(
                                            targetValue = 0f,
                                            animationSpec = androidx.compose.animation.core.spring(
                                                dampingRatio = androidx.compose.animation.core.Spring.DampingRatioMediumBouncy,
                                                stiffness = androidx.compose.animation.core.Spring.StiffnessLow
                                            )
                                        )
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = if (isLastInGroup) 6.dp else 2.dp)
                                    .graphicsLayer(
                                        alpha = animatedAlpha.value,
                                        translationY = animatedOffset.value
                                    ),
                                horizontalArrangement = if (isMe) Arrangement.End else Arrangement.Start
                            ) {
                                if (isMe) Spacer(modifier = Modifier.width(48.dp))

                                Column(
                                    horizontalAlignment = if (isMe) Alignment.End else Alignment.Start
                                ) {
                                    Card(
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isMe) primaryColor else Color(0xFF3A3A3A)
                                        ),
                                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                                        shape = RoundedCornerShape(
                                            topStart = 16.dp,
                                            topEnd = 16.dp,
                                            bottomStart = if (isMe) 16.dp else 4.dp,
                                            bottomEnd = if (isMe) 4.dp else 16.dp
                                        ),
                                        modifier = Modifier
                                            .shadow(2.dp, RoundedCornerShape(16.dp))
                                            .pointerInput(Unit) {
                                                detectTapGestures(
                                                    onLongPress = {
                                                        if (isMe) {
                                                            selectedMessage = message
                                                            showMessageOptions = true
                                                        }
                                                    }
                                                )
                                            }
                                    ) {
                                        Text(
                                            message.message,
                                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                            color = if (isMe) Color.Black else Color.White,
                                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = (MaterialTheme.typography.bodyMedium.fontSize.value * textSizeMultiplier).sp),
                                            fontWeight = FontWeight.Normal
                                        )
                                    }

                                    // Only show timestamp for last message in a group from same sender
                                    if (isLastInGroup) {
                                        val sdf = java.text.SimpleDateFormat("h:mm a", java.util.Locale.getDefault())
                                        Text(
                                            sdf.format(java.util.Date(message.timestamp)),
                                            color = Color.White.copy(alpha = 0.4f),
                                            style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * 0.8f * textSizeMultiplier).sp),
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                if (!isMe) Spacer(modifier = Modifier.width(48.dp))
                            }
                        }
                    }
                }
            }

            // Message input
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFF1A1A1A),
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = messageText,
                        onValueChange = { messageText = it },
                        placeholder = { Text("Type a message...", color = Color.White.copy(alpha = 0.4f)) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = primaryColor,
                            unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
                            cursorColor = primaryColor
                        ),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(24.dp),
                        maxLines = 3
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = {
                            if (currentUserId.isEmpty()) {
                                Toast.makeText(context, "Error: Not logged in", Toast.LENGTH_SHORT).show()
                                return@IconButton
                            }
                            if (otherUserId.isEmpty()) {
                                Toast.makeText(context, "Error: Invalid recipient", Toast.LENGTH_SHORT).show()
                                return@IconButton
                            }
                            if (messageText.isNotBlank()) {
                                val messageId = db.collection("messages").document().id
                                val msgText = messageText.trim()
                                val newMessage = ChatMessage(
                                    id = messageId,
                                    senderId = currentUserId,
                                    receiverId = otherUserId,
                                    message = msgText,
                                    timestamp = System.currentTimeMillis(),
                                    senderName = auth.currentUser?.displayName ?: ""
                                )

                                // OPTIMISTIC UPDATE: Add message to UI immediately
                                messages = messages + newMessage
                                newMessageIds = newMessageIds + messageId
                                messageText = ""

                                // Scroll to bottom
                                scope.launch {
                                    listState.animateScrollToItem(messages.size - 1)
                                }

                                // Remove animation flag after a delay
                                scope.launch {
                                    delay(500)
                                    newMessageIds = newMessageIds - messageId
                                }

                                android.util.Log.d("ChatScreen", "Sending message: $msgText from $currentUserId to $otherUserId")

                                // Save to Firebase
                                db.collection("messages").document(messageId).set(newMessage)
                                    .addOnSuccessListener {
                                        android.util.Log.d("ChatScreen", "Message saved successfully with ID: $messageId")
                                    }
                                    .addOnFailureListener { e ->
                                        android.util.Log.e("ChatScreen", "Failed to send message", e)
                                        // Remove message from UI if failed
                                        messages = messages.filter { it.id != messageId }
                                        Toast.makeText(context, "Failed: ${e.message}", Toast.LENGTH_SHORT).show()
                                    }
                            } else {
                                Toast.makeText(context, "Type a message first", Toast.LENGTH_SHORT).show()
                            }
                        },
                        enabled = messageText.isNotBlank(),
                        modifier = Modifier
                            .size(56.dp)
                            .background(
                                if (messageText.isNotBlank()) primaryColor else Color.Gray.copy(alpha = 0.5f),
                                CircleShape
                            )
                            .shadow(if (messageText.isNotBlank()) 4.dp else 0.dp, CircleShape)
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send",
                            tint = if (messageText.isNotBlank()) Color.Black else Color.White.copy(alpha = 0.3f),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }

        // Message Options Dialog
        if (showMessageOptions && selectedMessage != null) {
            val message = selectedMessage!!

            AlertDialog(
                onDismissRequest = { showMessageOptions = false },
                containerColor = Color(0xFF2A2A2A),
                title = {
                    Text(
                        "Delete Message?",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Column {
                        Text(
                            message.message,
                            color = Color.White.copy(alpha = 0.7f),
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 3
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            // IMMEDIATE delete from UI
                            messages = messages.filter { it.id != message.id }

                            // Delete from Firebase
                            db.collection("messages").document(message.id).delete()
                                .addOnSuccessListener {
                                    Toast.makeText(context, "Message deleted", Toast.LENGTH_SHORT).show()
                                }
                                .addOnFailureListener { e ->
                                    Toast.makeText(context, "Failed to delete: ${e.message}", Toast.LENGTH_SHORT).show()
                                }

                            showMessageOptions = false
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFDC143C),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Delete, null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Delete")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showMessageOptions = false }) {
                        Text("Cancel", color = Color.White.copy(alpha = 0.6f))
                    }
                }
            )
        }
    }
}

// Helper function to get state FBLA social media links
fun getStateFBLASocialMedia(state: String): Map<String, String> {
    return when (state.trim().lowercase()) {
        "wisconsin" -> mapOf(
            "Instagram" to "https://www.instagram.com/wifbla/",
            "Facebook" to "https://www.facebook.com/wifbla/",
            "X (Twitter)" to "https://twitter.com/wifbla"
        )
        "california" -> mapOf(
            "Instagram" to "https://www.instagram.com/cafbla/",
            "Facebook" to "https://www.facebook.com/cafbla/",
            "X (Twitter)" to "https://twitter.com/cafbla"
        )
        "texas" -> mapOf(
            "Instagram" to "https://www.instagram.com/texasfbla/",
            "Facebook" to "https://www.facebook.com/txfbla/",
            "X (Twitter)" to "https://twitter.com/txfbla"
        )
        "florida" -> mapOf(
            "Instagram" to "https://www.instagram.com/floridafbla/",
            "Facebook" to "https://www.facebook.com/floridafbla/",
            "X (Twitter)" to "https://twitter.com/floridafbla"
        )
        "new york" -> mapOf(
            "Instagram" to "https://www.instagram.com/nyfbla/",
            "Facebook" to "https://www.facebook.com/nyfbla/",
            "X (Twitter)" to "https://twitter.com/nyfbla"
        )
        "pennsylvania" -> mapOf(
            "Instagram" to "https://www.instagram.com/pafbla/",
            "Facebook" to "https://www.facebook.com/pafbla/",
            "X (Twitter)" to "https://twitter.com/pafbla"
        )
        "illinois" -> mapOf(
            "Instagram" to "https://www.instagram.com/ilfbla/",
            "Facebook" to "https://www.facebook.com/ilfbla/",
            "X (Twitter)" to "https://twitter.com/ilfbla"
        )
        "ohio" -> mapOf(
            "Instagram" to "https://www.instagram.com/ohiofbla/",
            "Facebook" to "https://www.facebook.com/ohiofbla/",
            "X (Twitter)" to "https://twitter.com/ohiofbla"
        )
        "georgia" -> mapOf(
            "Instagram" to "https://www.instagram.com/gafbla/",
            "Facebook" to "https://www.facebook.com/gafbla/",
            "X (Twitter)" to "https://twitter.com/gafbla"
        )
        "north carolina" -> mapOf(
            "Instagram" to "https://www.instagram.com/ncfbla/",
            "Facebook" to "https://www.facebook.com/ncfbla/",
            "X (Twitter)" to "https://twitter.com/ncfbla"
        )
        "michigan" -> mapOf(
            "Instagram" to "https://www.instagram.com/mifbla/",
            "Facebook" to "https://www.facebook.com/mifbla/",
            "X (Twitter)" to "https://twitter.com/mifbla"
        )
        "virginia" -> mapOf(
            "Instagram" to "https://www.instagram.com/vafbla/",
            "Facebook" to "https://www.facebook.com/vafbla/",
            "X (Twitter)" to "https://twitter.com/vafbla"
        )
        else -> emptyMap() // No state-specific links for other states
    }
}

// Helper function to get Sun Prairie FBLA chapter social media links
fun getSunPrairieChapterSocialMedia(): Map<String, String> {
    return mapOf(
        "Instagram" to "https://www.instagram.com/spwestfbla/",
        "X (Twitter)" to "https://twitter.com/spwestfbla",
        "Facebook" to "https://www.facebook.com/spwestfbla"
    )
}



