package com.example.myapplication

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.myapplication.ui.theme.MyApplicationTheme
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainScreen()
            }
        }
    }
}

data class CompetitionReminder(
    val name: String = "",
    val date: String = "",
    val timestamp: Long = 0L
)

data class UserProfile(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val school: String = "",
    val year: String = "",
    val state: String = "",
    val bio: String = "",
    val pfpUrl: String = "",
    val reminders: List<CompetitionReminder> = emptyList()
)

data class ConnectionRequest(
    val id: String = "",
    val fromUid: String = "",
    val fromName: String = "",
    val fromEmail: String = "",
    val fromSchool: String = "",
    val fromPfpUrl: String = "",
    val toUid: String = "",
    val toName: String = "",
    val status: String = "pending", // pending, accepted, declined
    val timestamp: Long = 0L
)

data class Connection(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val school: String = "",
    val pfpUrl: String = "",
    val reminders: List<CompetitionReminder> = emptyList()
)

@Composable
fun AuthScreen(onLoginSuccess: () -> Unit, onBack: () -> Unit) {
    var isLogin by remember { mutableStateOf(true) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var school by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }
    var statePref by remember { mutableStateOf("") }

    var isLoading by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()

    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.fbla_bg),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.9f)))

        IconButton(onClick = onBack, modifier = Modifier.padding(top = 48.dp, start = 16.dp)) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            item {
                Icon(Icons.Default.AccountCircle, null, modifier = Modifier.size(80.dp), tint = Color(0xFFFFB800))
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = if (isLogin) "WELCOME TO LEAD LINK" else "JOIN LEAD LINK",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White,
                    fontWeight = FontWeight.Black
                )
                Spacer(modifier = Modifier.height(32.dp))

                if (!isLogin) {
                    AuthTextField(value = name, onValueChange = { name = it }, label = "Full Name")
                    Spacer(modifier = Modifier.height(12.dp))
                    AuthTextField(value = school, onValueChange = { school = it }, label = "School Name")
                    Spacer(modifier = Modifier.height(12.dp))
                    AuthTextField(value = year, onValueChange = { year = it }, label = "Graduation Year")
                    Spacer(modifier = Modifier.height(12.dp))
                    AuthTextField(value = statePref, onValueChange = { statePref = it }, label = "State")
                    Spacer(modifier = Modifier.height(12.dp))
                }

                AuthTextField(value = email, onValueChange = { email = it }, label = "Email Address")
                Spacer(modifier = Modifier.height(12.dp))
                AuthTextField(value = password, onValueChange = { password = it }, label = "Password", isPassword = true)

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = {
                        if (email.isEmpty() || password.isEmpty() || (!isLogin && (name.isEmpty() || school.isEmpty()))) {
                            Toast.makeText(context, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        isLoading = true
                        if (isLogin) {
                            auth.signInWithEmailAndPassword(email, password).addOnCompleteListener { task ->
                                if (task.isSuccessful) onLoginSuccess()
                                else {
                                    isLoading = false
                                    Toast.makeText(context, "Error: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        } else {
                            auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    val profile = UserProfile(uid = auth.currentUser?.uid ?: "", name = name, email = email, school = school, year = year, state = statePref)
                                    db.collection("users").document(auth.currentUser!!.uid).set(profile)
                                        .addOnSuccessListener { onLoginSuccess() }
                                        .addOnFailureListener { isLoading = false }
                                } else {
                                    isLoading = false
                                    Toast.makeText(context, "Error: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB800)),
                    shape = RoundedCornerShape(12.dp),
                    enabled = !isLoading
                ) {
                    if (isLoading) CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(24.dp))
                    else Text(if (isLogin) "SIGN IN" else "REGISTER", color = Color.Black, fontWeight = FontWeight.Bold)
                }

                TextButton(onClick = { isLogin = !isLogin }) {
                    Text(if (isLogin) "New here? Create an account" else "Have an account? Sign in", color = Color(0xFFFFB800))
                }
            }
        }
    }
}

@Composable
fun AuthTextField(value: String, onValueChange: (String) -> Unit, label: String, isPassword: Boolean = false) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        visualTransformation = if (isPassword) PasswordVisualTransformation() else VisualTransformation.None,
        colors = OutlinedTextFieldDefaults.colors(
            unfocusedTextColor = Color.White,
            focusedTextColor = Color.White,
            unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
            focusedBorderColor = Color(0xFFFFB800)
        ),
        shape = RoundedCornerShape(12.dp)
    )
}

data class FblaEvent(val name: String, val date: String, val location: String, val timestamp: Long = 0L)
data class NewsArticle(val title: String, val summary: String, val date: String, val url: String, val tag: String = "NATIONAL")
data class ResourceItem(val title: String, val description: String, val url: String, val icon: ImageVector)

// Helper function to parse event dates
fun parseEventDates(eventDateString: String): List<String> {
    val dates = mutableListOf<String>()
    
    // Patterns to match: "April 9–10, 2026", "June 29 - July 2, 2026", "Feb 7, 2026", etc.
    val patterns = listOf(
        // Single day: "Feb 7, 2026"
        Regex("""(\w+)\s+(\d+),\s+(\d{4})"""),
        // Date range same month: "April 9–10, 2026" or "April 9-10, 2026"
        Regex("""(\w+)\s+(\d+)[–-](\d+),\s+(\d{4})"""),
        // Date range different months: "June 29 - July 2, 2026"
        Regex("""(\w+)\s+(\d+)\s*[-–]\s*(\w+)\s+(\d+),\s+(\d{4})""")
    )
    
    val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }
    val parseFormat = SimpleDateFormat("MMMM d, yyyy", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }
    
    try {
        // Try single day pattern
        patterns[0].find(eventDateString)?.let { match ->
            val (month, day, year) = match.destructured
            val dateStr = "$month $day, $year"
            parseFormat.parse(dateStr)?.let { parsedDate ->
                dates.add(dateFormat.format(parsedDate))
            }
            return dates
        }
        
        // Try same-month range pattern
        patterns[1].find(eventDateString)?.let { match ->
            val (month, startDay, endDay, year) = match.destructured
            val start = startDay.toInt()
            val end = endDay.toInt()
            
            for (day in start..end) {
                val dateStr = "$month $day, $year"
                parseFormat.parse(dateStr)?.let { parsedDate ->
                    dates.add(dateFormat.format(parsedDate))
                }
            }
            return dates
        }
        
        // Try different-month range pattern
        patterns[2].find(eventDateString)?.let { match ->
            val (startMonth, startDay, endMonth, endDay, year) = match.destructured
            
            // Parse start and end dates
            val startDateStr = "$startMonth $startDay, $year"
            val endDateStr = "$endMonth $endDay, $year"
            
            val startDate = parseFormat.parse(startDateStr)
            val endDate = parseFormat.parse(endDateStr)
            
            if (startDate != null && endDate != null) {
                val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
                cal.time = startDate
                
                while (!cal.time.after(endDate)) {
                    dates.add(dateFormat.format(cal.time))
                    cal.add(Calendar.DAY_OF_MONTH, 1)
                }
            }
            return dates
        }
    } catch (e: Exception) {
        // If parsing fails, return empty list
    }
    
    return dates
}

// Animated button modifier for press effect
@Composable
fun Modifier.animatedClickable(
    onClick: () -> Unit
): Modifier {
    var isPressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.95f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "button_scale"
    )
    
    return this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null
        ) {
            onClick()
        }
        .pointerInput(Unit) {
            detectTapGestures(
                onPress = {
                    isPressed = true
                    tryAwaitRelease()
                    isPressed = false
                }
            )
        }
}

@Composable
fun MainScreen() {
    var selectedTab by remember { mutableIntStateOf(2) }
    val auth = FirebaseAuth.getInstance()
    var currentUser by remember { mutableStateOf(auth.currentUser) }
    var showAuthFlow by remember { mutableStateOf(false) }
    var currentSubScreen by remember { mutableStateOf<String?>(null) }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Persisted settings
    val bgOpacity by SettingsStore.bgOpacityFlow(context).collectAsState(initial = 0.9f)
    val primaryColor by SettingsStore.primaryColorFlow(context).collectAsState(initial = Color(0xFFFFB800))
    val isHighContrast by SettingsStore.highContrastFlow(context).collectAsState(initial = false)
    val textSizeMultiplier by SettingsStore.textSizeFlow(context).collectAsState(initial = 1.0f)
    val isSimplifiedUI by SettingsStore.simplifiedUiFlow(context).collectAsState(initial = false)
    val notificationsEnabled by SettingsStore.notificationsEnabledFlow(context).collectAsState(initial = true)
    val publicProfile by SettingsStore.publicProfileFlow(context).collectAsState(initial = true)

    val effectivePrimary = if (isHighContrast) Color.White else primaryColor
    val effectiveBgOpacity = if (isHighContrast) 1.0f else bgOpacity

    Scaffold(
        bottomBar = {
            if (currentSubScreen == null) {
                NavigationBar(containerColor = Color(0xFF000D1A), contentColor = Color.White) {
                    listOf(
                        Triple(0, Icons.Filled.Person, "Profile"),
                        Triple(1, Icons.Filled.Event, "Events"),
                        Triple(2, Icons.Filled.Home, "Home"),
                        Triple(3, Icons.AutoMirrored.Filled.Article, "News"),
                        Triple(4, Icons.AutoMirrored.Filled.MenuBook, "Resources")
                    ).forEach { (index, icon, label) ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, style = TextStyle(fontSize = (12 * textSizeMultiplier).sp)) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = effectivePrimary,
                                selectedTextColor = effectivePrimary,
                                unselectedIconColor = Color.White.copy(alpha = 0.4f),
                                unselectedTextColor = Color.White.copy(alpha = 0.4f),
                                indicatorColor = Color.White.copy(alpha = 0.1f)
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        Crossfade(
            targetState = if (currentSubScreen != null) "subscreen" to currentSubScreen else "main" to selectedTab,
            animationSpec = tween(durationMillis = 600, easing = LinearEasing),
            label = "screen_transition",
            modifier = Modifier.fillMaxSize()
        ) { (screenType, screenId) ->
            Box(
                modifier = Modifier
                    .padding(if (screenType == "subscreen") PaddingValues(0.dp) else padding)
                    .fillMaxSize()
            ) {
                if (screenType == "subscreen") {
                    when (screenId) {
                        "find_links" -> MemberSearchScreen(onBack = { currentSubScreen = null }, primaryColor = effectivePrimary, bgOpacity = effectiveBgOpacity, isSimplifiedUI = isSimplifiedUI, textSizeMultiplier = textSizeMultiplier)
                        "connection_requests" -> ConnectionRequestsScreen(onBack = { currentSubScreen = null }, primaryColor = effectivePrimary, bgOpacity = effectiveBgOpacity, isSimplifiedUI = isSimplifiedUI, textSizeMultiplier = textSizeMultiplier)
                        "my_connections" -> MyConnectionsScreen(onBack = { currentSubScreen = null }, primaryColor = effectivePrimary, bgOpacity = effectiveBgOpacity, isSimplifiedUI = isSimplifiedUI, textSizeMultiplier = textSizeMultiplier)
                    }
                } else {
                    when (screenId as Int) {
                        0 -> {
                            if (currentUser == null) {
                                if (showAuthFlow) {
                                    AuthScreen(
                                        onLoginSuccess = {
                                            currentUser = auth.currentUser
                                            showAuthFlow = false
                                        },
                                        onBack = { showAuthFlow = false }
                                    )
                                } else {
                                    LoggedOutProfileScreen(onLoginClick = { showAuthFlow = true }, primaryColor = effectivePrimary, bgOpacity = effectiveBgOpacity, isSimplifiedUI = isSimplifiedUI)
                                }
                            } else {
                                ProfileScreen(
                                    onLogout = {
                                        auth.signOut()
                                        currentUser = null
                                    },
                                    onFindLinksClick = { currentSubScreen = "find_links" },
                                    onConnectionRequestsClick = { currentSubScreen = "connection_requests" },
                                    onMyConnectionsClick = { currentSubScreen = "my_connections" },
                                    bgOpacity = bgOpacity,
                                    onBgOpacityChange = { scope.launch { SettingsStore.saveBgOpacity(context, it) } },
                                    primaryColor = primaryColor,
                                    onPrimaryColorChange = { scope.launch { SettingsStore.savePrimaryColor(context, it) } },
                                    isHighContrast = isHighContrast,
                                    onHighContrastChange = { scope.launch { SettingsStore.saveHighContrast(context, it) } },
                                    textSizeMultiplier = textSizeMultiplier,
                                    onTextSizeChange = { scope.launch { SettingsStore.saveTextSize(context, it) } },
                                    isSimplifiedUI = isSimplifiedUI,
                                    onSimplifiedUIChange = { scope.launch { SettingsStore.saveSimplifiedUi(context, it) } },
                                    notificationsEnabled = notificationsEnabled,
                                    onNotificationsChange = { scope.launch { SettingsStore.saveNotificationsEnabled(context, it) } },
                                    publicProfile = publicProfile,
                                    onPublicProfileChange = { scope.launch { SettingsStore.savePublicProfile(context, it) } }
                                )
                            }
                        }
                        1 -> EventsPlaceholder(effectivePrimary, effectiveBgOpacity, isSimplifiedUI, textSizeMultiplier)
                        2 -> HomeScreen(effectivePrimary, effectiveBgOpacity, isSimplifiedUI, textSizeMultiplier)
                        3 -> NewsScreen(effectivePrimary, effectiveBgOpacity, isSimplifiedUI, textSizeMultiplier)
                        4 -> ResourcesScreen(effectivePrimary, effectiveBgOpacity, isSimplifiedUI, textSizeMultiplier)
                    }
                }
            }
        }
    }
}

@Composable
fun LoggedOutProfileScreen(onLoginClick: () -> Unit, primaryColor: Color, bgOpacity: Float, isSimplifiedUI: Boolean) {
    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgOpacity)))
        Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(Icons.Default.AccountCircle, null, modifier = Modifier.size(100.dp), tint = Color.White.copy(alpha = 0.2f))
            Spacer(modifier = Modifier.height(24.dp))
            Text("Sign in to view your profile", color = Color.White.copy(alpha = 0.6f))
            Spacer(modifier = Modifier.height(24.dp))
            Button(
                onClick = onLoginClick,
                colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.width(200.dp).height(50.dp)
            ) {
                Text("LOGIN OR SIGNUP", color = if (primaryColor == Color.White) Color.Black else Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun ProfileScreen(
    onLogout: () -> Unit,
    onFindLinksClick: () -> Unit,
    onConnectionRequestsClick: () -> Unit,
    onMyConnectionsClick: () -> Unit,
    bgOpacity: Float,
    onBgOpacityChange: (Float) -> Unit,
    primaryColor: Color,
    onPrimaryColorChange: (Color) -> Unit,
    isHighContrast: Boolean,
    onHighContrastChange: (Boolean) -> Unit,
    textSizeMultiplier: Float,
    onTextSizeChange: (Float) -> Unit,
    isSimplifiedUI: Boolean,
    onSimplifiedUIChange: (Boolean) -> Unit,
    notificationsEnabled: Boolean,
    onNotificationsChange: (Boolean) -> Unit,
    publicProfile: Boolean,
    onPublicProfileChange: (Boolean) -> Unit
) {
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    val context = LocalContext.current

    var profile by remember { mutableStateOf<UserProfile?>(null) }
    var isEditing by remember { mutableStateOf(false) }
    var isProcessingImage by remember { mutableStateOf(false) }

    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var school by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }
    var statePref by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    var pfpUrl by remember { mutableStateOf("") }

    val effectivePrimary = if (isHighContrast) Color.White else primaryColor
    val effectiveBgOpacity = if (isHighContrast) 1.0f else bgOpacity

    val pfpLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            isProcessingImage = true
            try {
                val inputStream = context.contentResolver.openInputStream(it)
                val bitmap = BitmapFactory.decodeStream(inputStream)
                val resized = Bitmap.createScaledBitmap(bitmap, 200, 200, true)
                val outputStream = ByteArrayOutputStream()
                resized.compress(Bitmap.CompressFormat.JPEG, 70, outputStream)
                val bytes = outputStream.toByteArray()
                val base64String = "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.DEFAULT)
                pfpUrl = base64String
                db.collection("users").document(auth.currentUser!!.uid).update("pfpUrl", pfpUrl)
                isProcessingImage = false
                Toast.makeText(context, "Profile Picture Updated!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                isProcessingImage = false
                Toast.makeText(context, "Failed to process image", Toast.LENGTH_SHORT).show()
            }
        }
    }

    LaunchedEffect(Unit) {
        val uid = auth.currentUser?.uid
        if (uid != null) {
            db.collection("users").document(uid).addSnapshotListener { snapshot, error ->
                if (error != null) return@addSnapshotListener
                val data = snapshot?.toObject(UserProfile::class.java)
                profile = data
                if (data != null && !isEditing) {
                    name = data.name
                    email = data.email.ifEmpty { auth.currentUser?.email ?: "" }
                    school = data.school
                    year = data.year
                    statePref = data.state
                    bio = data.bio
                    pfpUrl = data.pfpUrl
                }
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = effectiveBgOpacity)))

        if (profile == null) {
            CircularProgressIndicator(modifier = Modifier.align(Alignment.Center), color = effectivePrimary)
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                item {
                    Spacer(modifier = Modifier.height(60.dp))
                    Box(modifier = Modifier.size(130.dp)) {
                        Box(
                            modifier = Modifier
                                .size(120.dp)
                                .background(effectivePrimary, CircleShape)
                                .clip(CircleShape)
                                .clickable { pfpLauncher.launch("image/*") }
                                .align(Alignment.TopStart),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isProcessingImage) {
                                CircularProgressIndicator(color = Color.Black)
                            } else if (pfpUrl.isNotEmpty()) {
                                AsyncImage(
                                    model = pfpUrl,
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Text(name.take(1).ifEmpty { "U" }.uppercase(), color = Color.Black, style = MaterialTheme.typography.displayMedium.copy(fontSize = (MaterialTheme.typography.displayMedium.fontSize.value * textSizeMultiplier).sp), fontWeight = FontWeight.Bold)
                            }
                        }
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color.Black.copy(alpha = 0.7f), CircleShape)
                                .background(effectivePrimary.copy(alpha = 0.2f), CircleShape)
                                .align(Alignment.BottomEnd)
                                .clickable { pfpLauncher.launch("image/*") },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.CameraAlt, null, tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                    }
                    Spacer(modifier = Modifier.height(24.dp))

                    if (isEditing) {
                        ProfileEditField(value = name, onValueChange = { name = it }, label = "Full Name")
                        ProfileEditField(value = email, onValueChange = { email = it }, label = "Email")
                        ProfileEditField(value = school, onValueChange = { school = it }, label = "School")
                        ProfileEditField(value = year, onValueChange = { year = it }, label = "Grad Year")
                        ProfileEditField(value = statePref, onValueChange = { statePref = it }, label = "State")
                        ProfileEditField(value = bio, onValueChange = { bio = it }, label = "Short Bio")
                    } else {
                        Text(text = name.ifEmpty { "Member" }, style = MaterialTheme.typography.headlineMedium.copy(fontSize = (MaterialTheme.typography.headlineMedium.fontSize.value * textSizeMultiplier).sp), color = Color.White, fontWeight = FontWeight.Black)
                        Text(text = school.ifEmpty { "Unknown School" }, style = MaterialTheme.typography.bodyLarge.copy(fontSize = (MaterialTheme.typography.bodyLarge.fontSize.value * textSizeMultiplier).sp), color = effectivePrimary)
                        Text(text = "Class of ${year.ifEmpty { "20XX" }} • ${statePref.ifEmpty { "N/A" }}", style = MaterialTheme.typography.bodyMedium.copy(fontSize = (MaterialTheme.typography.bodyMedium.fontSize.value * textSizeMultiplier).sp), color = Color.White.copy(alpha = 0.6f))
                        if (email.isNotEmpty()) {
                            Text(text = email, style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp), color = Color.White.copy(alpha = 0.5f), textAlign = TextAlign.Center)
                        }
                        if (bio.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = bio, style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp), color = Color.White.copy(alpha = 0.8f), textAlign = TextAlign.Center)
                        }
                    }

                    Spacer(modifier = Modifier.height(32.dp))

                    Button(
                        onClick = onFindLinksClick,
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = effectivePrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Search, null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("FIND PEERS", color = Color.Black, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = (14 * textSizeMultiplier).sp))
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = onConnectionRequestsClick,
                            modifier = Modifier.weight(1f).height(50.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.1f)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.PersonAdd, null, tint = effectivePrimary, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("REQUESTS", color = Color.White, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = (11 * textSizeMultiplier).sp))
                            }
                        }
                        
                        Button(
                            onClick = onMyConnectionsClick,
                            modifier = Modifier.weight(1f).height(50.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.1f)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.People, null, tint = effectivePrimary, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("CONNECTIONS", color = Color.White, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = (11 * textSizeMultiplier).sp))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = {
                                if (isEditing) {
                                    val newProfile = profile!!.copy(name = name, email = email, school = school, year = year, state = statePref, bio = bio, pfpUrl = pfpUrl)
                                    db.collection("users").document(auth.currentUser!!.uid).set(newProfile)
                                    profile = newProfile
                                }
                                isEditing = !isEditing
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = if (isEditing) Color.Green else Color.White.copy(alpha = 0.1f)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(if (isEditing) Icons.Default.Check else Icons.Default.Edit, null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (isEditing) "SAVE" else "EDIT", style = TextStyle(fontSize = (12 * textSizeMultiplier).sp))
                        }

                        Button(
                            onClick = onLogout,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.7f)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Logout, null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("LOGOUT", style = TextStyle(fontSize = (12 * textSizeMultiplier).sp))
                        }
                    }

                    if (profile?.reminders?.isNotEmpty() == true) {
                        Spacer(modifier = Modifier.height(48.dp))
                        Text(
                            text = "MY REMINDERS",
                            style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 2.sp, fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp),
                            color = effectivePrimary,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Start
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        profile!!.reminders.forEach { reminder ->
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(reminder.name, color = Color.White, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = (14 * textSizeMultiplier).sp))
                                        Text(reminder.date, color = Color.White.copy(alpha = 0.6f), style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp))
                                    }
                                    IconButton(onClick = {
                                        db.collection("users").document(auth.currentUser!!.uid).update(
                                            "reminders", FieldValue.arrayRemove(reminder)
                                        )
                                    }) {
                                        Icon(Icons.Default.Delete, null, tint = Color.Red.copy(alpha = 0.7f))
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(48.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(text = "VISUALS", style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 2.sp, fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp), color = effectivePrimary, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Background Intensity", color = Color.White, style = MaterialTheme.typography.bodyMedium.copy(fontSize = (MaterialTheme.typography.bodyMedium.fontSize.value * textSizeMultiplier).sp), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
                    Slider(value = bgOpacity, onValueChange = onBgOpacityChange, valueRange = 0.4f..0.95f, colors = SliderDefaults.colors(thumbColor = effectivePrimary, activeTrackColor = effectivePrimary))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Theme Color", color = Color.White, style = MaterialTheme.typography.bodyMedium.copy(fontSize = (MaterialTheme.typography.bodyMedium.fontSize.value * textSizeMultiplier).sp), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        listOf(Color(0xFFFFB800), Color(0xFF00B4FF), Color(0xFFFF4D4D), Color(0xFF4DFF88)).forEach { color ->
                            Box(modifier = Modifier.size(40.dp).background(color, CircleShape).clip(CircleShape).clickable { onPrimaryColorChange(color) }.background(if (primaryColor == color) Color.White.copy(alpha = 0.3f) else Color.Transparent))
                        }
                    }

                    Spacer(modifier = Modifier.height(48.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(text = "ACCESSIBILITY", style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 2.sp, fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp), color = effectivePrimary, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
                    Spacer(modifier = Modifier.height(16.dp))

                    SettingToggle(title = "High Contrast", subtitle = "Use solid black/white for clarity", icon = Icons.Default.Contrast, checked = isHighContrast, onCheckedChange = onHighContrastChange, primaryColor = effectivePrimary, textSizeMultiplier = textSizeMultiplier)

                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Text Size Multiplier: ${String.format("%.1f", textSizeMultiplier)}x", color = Color.White, style = MaterialTheme.typography.bodyMedium.copy(fontSize = (MaterialTheme.typography.bodyMedium.fontSize.value * textSizeMultiplier).sp))
                    Slider(value = textSizeMultiplier, onValueChange = onTextSizeChange, valueRange = 0.8f..1.5f, colors = SliderDefaults.colors(thumbColor = effectivePrimary, activeTrackColor = effectivePrimary))

                    Spacer(modifier = Modifier.height(16.dp))
                    SettingToggle(title = "Simplified UI", subtitle = "Hide background images", icon = Icons.Default.VisibilityOff, checked = isSimplifiedUI, onCheckedChange = onSimplifiedUIChange, primaryColor = effectivePrimary, textSizeMultiplier = textSizeMultiplier)

                    Spacer(modifier = Modifier.height(48.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(text = "APP SETTINGS", style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 2.sp, fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp), color = effectivePrimary, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
                    Spacer(modifier = Modifier.height(16.dp))
                    SettingToggle(title = "Push Notifications", subtitle = "Get alerts for events and news", icon = Icons.Default.Notifications, checked = notificationsEnabled, onCheckedChange = onNotificationsChange, primaryColor = effectivePrimary, textSizeMultiplier = textSizeMultiplier)
                    SettingToggle(title = "Public Profile", subtitle = "Allow others to see your progress", icon = Icons.Default.Public, checked = publicProfile, onCheckedChange = onPublicProfileChange, primaryColor = effectivePrimary, textSizeMultiplier = textSizeMultiplier)
                    Spacer(modifier = Modifier.height(24.dp))
                    TextButton(onClick = { }, modifier = Modifier.fillMaxWidth()) { Text("About Lead Link v1.0.4", color = Color.White.copy(alpha = 0.4f), style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp)) }
                    TextButton(onClick = { }, modifier = Modifier.fillMaxWidth()) { Text("Delete Account", color = Color.Red.copy(alpha = 0.5f), style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp)) }
                    Spacer(modifier = Modifier.height(40.dp))
                }
            }
        }
    }
}

@Composable
fun SettingToggle(title: String, subtitle: String, icon: ImageVector, checked: Boolean, onCheckedChange: (Boolean) -> Unit, primaryColor: Color, textSizeMultiplier: Float) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Color.White.copy(alpha = 0.6f), modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Color.White, style = MaterialTheme.typography.bodyLarge.copy(fontSize = (MaterialTheme.typography.bodyLarge.fontSize.value * textSizeMultiplier).sp))
            Text(subtitle, color = Color.White.copy(alpha = 0.5f), style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp))
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange, colors = SwitchDefaults.colors(checkedThumbColor = primaryColor, checkedTrackColor = primaryColor.copy(alpha = 0.3f), uncheckedThumbColor = Color.Gray, uncheckedTrackColor = Color.Gray.copy(alpha = 0.3f)))
    }
}

@Composable
fun ProfileEditField(value: String, onValueChange: (String) -> Unit, label: String) {
    OutlinedTextField(value = value, onValueChange = onValueChange, label = { Text(label) }, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), colors = OutlinedTextFieldDefaults.colors(unfocusedTextColor = Color.White, focusedTextColor = Color.White))
}

@Composable
fun HomeScreen(primaryColor: Color, bgOpacity: Float, isSimplifiedUI: Boolean, textSizeMultiplier: Float) {
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    var profile by remember { mutableStateOf<UserProfile?>(null) }
    val tips = listOf(
        "Networking isn't just about collecting contacts; it's about planting relations.",
        "Success is not final, failure is not fatal: it is the courage to continue that counts.",
        "The best way to predict the future is to create it.",
        "Business opportunities are like buses, there's always another one coming.",
        "Build your own dreams, or someone else will hire you to build theirs.",
        "Never give up. Today is hard and tomorrow will be worse, but the day after tomorrow will be sunshine.",
        "Innovation distinguishes between a leader and a follower.",
        "Failure doesn't mean you are a failure it just means you haven't succeeded yet.",
        "Work like there is someone working 24 hours a day to take it all away from you."
    )
    var currentTipIndex by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        val uid = auth.currentUser?.uid
        if (uid != null) {
            db.collection("users").document(uid).addSnapshotListener { snapshot, _ ->
                profile = snapshot?.toObject(UserProfile::class.java)
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgOpacity)))

        LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(24.dp)) {
            item {
                Spacer(modifier = Modifier.height(40.dp))
                Text(
                    text = "WELCOME, ${profile?.name?.split(" ")?.get(0)?.uppercase() ?: "MEMBER"}",
                    style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 4.sp, fontWeight = FontWeight.Bold, color = primaryColor, fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp)
                )
                Text(text = "Lead Link Dashboard", style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.Black, color = Color.White, fontSize = (MaterialTheme.typography.displaySmall.fontSize.value * textSizeMultiplier).sp))
                Spacer(modifier = Modifier.height(32.dp))
            }

            if (profile?.reminders?.isNotEmpty() == true) {
                itemsIndexed(profile!!.reminders) { index, reminder ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                            .animateContentSize(
                                animationSpec = spring(
                                    dampingRatio = Spring.DampingRatioMediumBouncy,
                                    stiffness = Spring.StiffnessLow
                                )
                            ),
                        colors = CardDefaults.cardColors(containerColor = primaryColor.copy(alpha = 0.15f)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, primaryColor.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(24.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.AutoMirrored.Filled.EventNote, null, tint = primaryColor, modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.width(12.dp))
                                Text("UPCOMING COMPETITION", color = Color.White.copy(alpha = 0.6f), style = MaterialTheme.typography.labelSmall.copy(fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * textSizeMultiplier).sp))
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(reminder.name, color = Color.White, style = MaterialTheme.typography.titleLarge.copy(fontSize = (MaterialTheme.typography.titleLarge.fontSize.value * textSizeMultiplier).sp), fontWeight = FontWeight.Bold)
                            Text(reminder.date, color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.bodyMedium.copy(fontSize = (MaterialTheme.typography.bodyMedium.fontSize.value * textSizeMultiplier).sp))

                            val daysLeft = if (reminder.timestamp > System.currentTimeMillis()) {
                                TimeUnit.MILLISECONDS.toDays(reminder.timestamp - System.currentTimeMillis())
                            } else 0

                            Spacer(modifier = Modifier.height(16.dp))
                            LinearProgressIndicator(
                                progress = { (100 - daysLeft.coerceIn(0, 100)) / 100f },
                                modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
                                color = primaryColor,
                                trackColor = Color.White.copy(alpha = 0.1f)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("$daysLeft DAYS REMAINING", color = primaryColor, style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Black, fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp))
                        }
                    }
                }
            } else {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.AutoMirrored.Filled.EventNote, null, tint = Color.White.copy(alpha = 0.3f), modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("No Active Reminders", color = Color.White.copy(alpha = 0.5f), style = TextStyle(fontSize = (14 * textSizeMultiplier).sp))
                            Text("Set one in the Events tab", color = Color.White.copy(alpha = 0.3f), style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp))
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(40.dp))
                Card(
                    onClick = { currentTipIndex = (currentTipIndex + 1) % tips.size },
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = primaryColor),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(24.dp)) {
                        Icon(Icons.Default.Lightbulb, null, tint = Color.Black)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("LEADERSHIP TIP", color = Color.Black.copy(alpha = 0.6f), style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * textSizeMultiplier).sp))
                        Spacer(modifier = Modifier.height(8.dp))
                        AnimatedContent(
                            targetState = tips[currentTipIndex],
                            transitionSpec = {
                                fadeIn(animationSpec = tween(500)) + slideInVertically(
                                    initialOffsetY = { it / 2 },
                                    animationSpec = tween(500)
                                ) togetherWith fadeOut(animationSpec = tween(300))
                            },
                            label = "tip_transition"
                        ) { tip ->
                            Text(
                                text = tip,
                                color = Color.Black,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Serif,
                                    fontSize = (MaterialTheme.typography.bodyLarge.fontSize.value * textSizeMultiplier).sp
                                )
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}

@Composable
fun MemberSearchScreen(onBack: () -> Unit, primaryColor: Color, bgOpacity: Float, isSimplifiedUI: Boolean, textSizeMultiplier: Float) {
    val db = FirebaseFirestore.getInstance()
    val auth = FirebaseAuth.getInstance()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    var members by remember { mutableStateOf<List<UserProfile>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var searchQuery by remember { mutableStateOf("") }
    var sentRequests by remember { mutableStateOf<Set<String>>(emptySet()) }
    var connectedUsers by remember { mutableStateOf<Set<String>>(emptySet()) }

    LaunchedEffect(Unit) {
        val currentUid = auth.currentUser?.uid
        if (currentUid != null) {
            // Load users
            db.collection("users").addSnapshotListener { snapshot, _ ->
                members = snapshot?.toObjects(UserProfile::class.java)?.filter { it.uid != currentUid } ?: emptyList()
                isLoading = false
            }
            
            // Load sent requests
            db.collection("connectionRequests")
                .whereEqualTo("fromUid", currentUid)
                .whereEqualTo("status", "pending")
                .addSnapshotListener { snapshot, _ ->
                    sentRequests = snapshot?.documents?.mapNotNull { it.getString("toUid") }?.toSet() ?: emptySet()
                }
            
            // Load connections
            db.collection("connections")
                .document(currentUid)
                .addSnapshotListener { snapshot, _ ->
                    connectedUsers = (snapshot?.get("connectedUids") as? List<*>)?.mapNotNull { it as? String }?.toSet() ?: emptySet()
                }
        } else {
            isLoading = false
        }
    }

    val filteredMembers = remember(searchQuery, members) {
        if (searchQuery.isEmpty()) members
        else members.filter { it.name.contains(searchQuery, ignoreCase = true) }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgOpacity)))

        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 48.dp, start = 16.dp, end = 16.dp, bottom = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Text("FIND PEERS", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black, fontSize = (MaterialTheme.typography.headlineSmall.fontSize.value * textSizeMultiplier).sp), color = Color.White)
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                placeholder = { Text("Search by name...", color = Color.White.copy(alpha = 0.5f), style = TextStyle(fontSize = (14 * textSizeMultiplier).sp)) },
                leadingIcon = { Icon(Icons.Default.Search, null, tint = primaryColor) },
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedTextColor = Color.White,
                    focusedTextColor = Color.White,
                    unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                    focusedBorderColor = primaryColor
                ),
                shape = RoundedCornerShape(12.dp)
            )

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = primaryColor)
                }
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                    itemsIndexed(filteredMembers) { _, member ->
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(modifier = Modifier.size(50.dp).background(primaryColor, CircleShape).clip(CircleShape)) {
                                        if (member.pfpUrl.isNotEmpty()) {
                                            AsyncImage(model = member.pfpUrl, contentDescription = null, contentScale = ContentScale.Crop)
                                        } else {
                                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                                Text(member.name.take(1).uppercase(), color = Color.Black, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = (16 * textSizeMultiplier).sp))
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column {
                                        Text(member.name, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge.copy(fontSize = (MaterialTheme.typography.titleLarge.fontSize.value * textSizeMultiplier).sp))
                                        Text(member.school, color = primaryColor, style = MaterialTheme.typography.bodyMedium.copy(fontSize = (MaterialTheme.typography.bodyMedium.fontSize.value * textSizeMultiplier).sp))
                                    }
                                }

                                if (member.bio.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(text = member.bio, color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp))
                                }

                                if (member.reminders.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text("Competitions:", color = Color.White.copy(alpha = 0.6f), style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * textSizeMultiplier).sp))
                                    member.reminders.forEach { reminder ->
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                                            Icon(Icons.Default.EmojiEvents, null, tint = primaryColor, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(reminder.name, color = Color.White, style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp))
                                        }
                                    }
                                }
                                
                                Spacer(modifier = Modifier.height(12.dp))
                                
                                val isConnected = connectedUsers.contains(member.uid)
                                val requestSent = sentRequests.contains(member.uid)
                                
                                Button(
                                    onClick = {
                                        if (!isConnected && !requestSent) {
                                            scope.launch {
                                                try {
                                                    val currentUser = auth.currentUser ?: return@launch
                                                    val currentProfile = db.collection("users").document(currentUser.uid).get().await().toObject(UserProfile::class.java)
                                                    
                                                    val request = ConnectionRequest(
                                                        id = UUID.randomUUID().toString(),
                                                        fromUid = currentUser.uid,
                                                        fromName = currentProfile?.name ?: "",
                                                        fromEmail = currentProfile?.email ?: currentUser.email ?: "",
                                                        fromSchool = currentProfile?.school ?: "",
                                                        fromPfpUrl = currentProfile?.pfpUrl ?: "",
                                                        toUid = member.uid,
                                                        toName = member.name,
                                                        status = "pending",
                                                        timestamp = System.currentTimeMillis()
                                                    )
                                                    
                                                    db.collection("connectionRequests").document(request.id).set(request).await()
                                                    Toast.makeText(context, "Connection request sent!", Toast.LENGTH_SHORT).show()
                                                } catch (e: Exception) {
                                                    Log.e("ConnectionRequest", "Error sending request: ${e.message}", e)
                                                    Toast.makeText(context, "Failed to send: ${e.message}", Toast.LENGTH_LONG).show()
                                                }
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth().height(40.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = when {
                                            isConnected -> Color.Green.copy(alpha = 0.3f)
                                            requestSent -> Color.Gray.copy(alpha = 0.3f)
                                            else -> primaryColor
                                        }
                                    ),
                                    enabled = !isConnected && !requestSent,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(
                                        when {
                                            isConnected -> Icons.Default.Check
                                            requestSent -> Icons.Default.Schedule
                                            else -> Icons.Default.PersonAdd
                                        },
                                        null,
                                        tint = if (isConnected || requestSent) Color.White.copy(alpha = 0.5f) else Color.Black,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        when {
                                            isConnected -> "CONNECTED"
                                            requestSent -> "REQUEST SENT"
                                            else -> "SEND REQUEST"
                                        },
                                        color = if (isConnected || requestSent) Color.White.copy(alpha = 0.5f) else Color.Black,
                                        fontWeight = FontWeight.Bold,
                                        style = TextStyle(fontSize = (12 * textSizeMultiplier).sp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CalendarView(
    selectedDate: Calendar?,
    onDateSelected: (Calendar) -> Unit,
    eventDates: Set<String>,
    primaryColor: Color,
    textSizeMultiplier: Float
) {
    var currentMonth by remember { 
        mutableStateOf(Calendar.getInstance(TimeZone.getTimeZone("UTC"))) 
    }
    val dateFormat = remember { 
        SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
    }
    val monthYearFormat = remember {
        SimpleDateFormat("MMMM yyyy", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
    }
    
    Column(modifier = Modifier.fillMaxWidth()) {
        // Month/Year Header with navigation
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {
                currentMonth = (currentMonth.clone() as Calendar).apply { 
                    add(Calendar.MONTH, -1)
                    timeZone = TimeZone.getTimeZone("UTC")
                }
            }) {
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, null, tint = Color.White)
            }
            
            Text(
                text = monthYearFormat.format(currentMonth.time).uppercase(),
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = (MaterialTheme.typography.titleMedium.fontSize.value * textSizeMultiplier).sp
                ),
                color = Color.White
            )
            
            IconButton(onClick = {
                currentMonth = (currentMonth.clone() as Calendar).apply { 
                    add(Calendar.MONTH, 1)
                    timeZone = TimeZone.getTimeZone("UTC")
                }
            }) {
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = Color.White)
            }
        }
        
        // Day of week headers
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("S", "M", "T", "W", "T", "F", "S").forEach { day ->
                Text(
                    text = day,
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    color = primaryColor,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * textSizeMultiplier).sp
                    )
                )
            }
        }
        
        Spacer(modifier = Modifier.height(8.dp))
        
        // Calendar grid
        val firstDayOfMonth = (currentMonth.clone() as Calendar).apply {
            timeZone = TimeZone.getTimeZone("UTC")
            set(Calendar.DAY_OF_MONTH, 1)
        }
        val lastDayOfMonth = (currentMonth.clone() as Calendar).apply {
            timeZone = TimeZone.getTimeZone("UTC")
            set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
        }
        
        val startDayOfWeek = firstDayOfMonth.get(Calendar.DAY_OF_WEEK) - 1
        val daysInMonth = lastDayOfMonth.get(Calendar.DAY_OF_MONTH)
        val totalCells = ((startDayOfWeek + daysInMonth + 6) / 7) * 7
        
        Column {
            for (week in 0 until (totalCells / 7)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    for (day in 0..6) {
                        val cellIndex = week * 7 + day
                        val dayOfMonth = cellIndex - startDayOfWeek + 1
                        
                        if (cellIndex >= startDayOfWeek && dayOfMonth <= daysInMonth) {
                            val cellDate = (currentMonth.clone() as Calendar).apply {
                                set(Calendar.DAY_OF_MONTH, dayOfMonth)
                                set(Calendar.HOUR_OF_DAY, 0)
                                set(Calendar.MINUTE, 0)
                                set(Calendar.SECOND, 0)
                                set(Calendar.MILLISECOND, 0)
                                timeZone = TimeZone.getTimeZone("UTC")
                            }
                            val dateString = dateFormat.format(cellDate.time)
                            val hasEvent = eventDates.contains(dateString)
                            val isSelected = selectedDate?.let {
                                dateFormat.format(it.time) == dateString
                            } ?: false
                            
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                                    .padding(4.dp)
                                    .background(
                                        when {
                                            isSelected -> primaryColor
                                            hasEvent -> primaryColor.copy(alpha = 0.2f)
                                            else -> Color.Transparent
                                        },
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { onDateSelected(cellDate) },
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = dayOfMonth.toString(),
                                        color = if (isSelected) Color.Black else Color.White,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = if (hasEvent || isSelected) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = (MaterialTheme.typography.bodyMedium.fontSize.value * textSizeMultiplier).sp
                                        )
                                    )
                                    if (hasEvent && !isSelected) {
                                        Box(
                                            modifier = Modifier
                                                .size(4.dp)
                                                .background(primaryColor, CircleShape)
                                        )
                                    }
                                }
                            }
                        } else {
                            Spacer(modifier = Modifier.weight(1f).aspectRatio(1f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EventsPlaceholder(primaryColor: Color, bgOpacity: Float, isSimplifiedUI: Boolean, textSizeMultiplier: Float) {
    var selectedState by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    var selectedDate by remember { mutableStateOf<Calendar?>(null) }
    var showListView by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    val dateFormat = remember { 
        SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
    }
    val displayDateFormat = remember {
        SimpleDateFormat("MMMM dd, yyyy", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
    }
    val nationalConference = FblaEvent("National Leadership Conference (NLC)", "June 29 - July 2, 2026", "Anaheim, CA", 1782691200000L)
    val eventsByState = remember {
        val statesList = listOf("Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming")
        val baseEvents = mapOf(
            "Alabama" to listOf(FblaEvent("District Workshops", "Jan-Feb 2026", "Various Locations"), FblaEvent("State Leadership Conference", "April 9–10, 2026", "Mobile", 1775692800000L)),
            "California" to listOf(FblaEvent("Section Leadership Conferences", "Feb-March 2026", "Various Sections"), FblaEvent("State Leadership Conference", "April 23–26, 2026", "Sacramento", 1776902400000L)),
            "Texas" to listOf(FblaEvent("Area Leadership Conferences", "Jan-Feb 2026", "Areas 1-9"), FblaEvent("State Leadership Conference", "March 25–27, 2026", "Galveston", 1774396800000L)),
            "Wisconsin" to listOf(FblaEvent("Region 1 Leadership Conference", "Feb 7, 2026", "Shell Lake", 1770336000000L), FblaEvent("State Leadership Conference", "April 13–14, 2026", "Madison", 1776038400000L))
        )
        statesList.associateWith { (baseEvents[it] ?: listOf(FblaEvent("Regional Leadership Conference", "Jan-Feb 2026", "Various"), FblaEvent("State Leadership Conference", "March-April 2026", "TBD", 1775001600000L))) + nationalConference }
    }
    val states = remember { eventsByState.keys.toList().sorted() }
    
    // Get all events based on selected state (or all states if none selected)
    val relevantEvents = remember(selectedState, eventsByState) {
        if (selectedState.isEmpty()) {
            // All events from all states
            eventsByState.values.flatten()
        } else {
            // Events from selected state only
            eventsByState[selectedState] ?: emptyList()
        }
    }
    
    // Calculate event dates for calendar by parsing date strings
    val eventDates = remember(relevantEvents) {
        relevantEvents
            .flatMap { event -> parseEventDates(event.date) }
            .toSet()
    }
    
    // Filter events by selected date (only when not in list view)
    val filteredEvents = remember(selectedDate, relevantEvents, showListView) {
        // In list view, show all events regardless of selected date
        if (showListView) {
            relevantEvents
        } else {
            val currentSelectedDate = selectedDate
            if (currentSelectedDate == null) {
                relevantEvents
            } else {
                val selectedDateString = dateFormat.format(currentSelectedDate.time)
                relevantEvents.filter { event ->
                    // Check if the selected date falls within any of the event's dates
                    val eventDates = parseEventDates(event.date)
                    eventDates.contains(selectedDateString)
                }
            }
        }
    }
    
    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgOpacity)))
        
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(40.dp))
                Text(
                    text = "FUTURE BUSINESS LEADERS",
                    style = MaterialTheme.typography.labelLarge.copy(
                        letterSpacing = 5.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp
                    ),
                    color = Color.White.copy(alpha = 0.9f)
                )
                Text(
                    text = if (selectedState.isEmpty()) "Events 2026" else "$selectedState Events",
                    style = MaterialTheme.typography.displaySmall.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = (MaterialTheme.typography.displaySmall.fontSize.value * textSizeMultiplier).sp
                    ),
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(24.dp))
            }
            
            // Calendar card
            if (!showListView) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .animateContentSize(
                                animationSpec = spring(
                                    dampingRatio = Spring.DampingRatioMediumBouncy,
                                    stiffness = Spring.StiffnessLow
                                )
                            ),
                        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(16.dp)
                                .animateContentSize(
                                    animationSpec = spring(
                                        dampingRatio = Spring.DampingRatioMediumBouncy,
                                        stiffness = Spring.StiffnessLow
                                    )
                                )
                        ) {
                            CalendarView(
                                selectedDate = selectedDate,
                                onDateSelected = { date -> selectedDate = date },
                                eventDates = eventDates,
                                primaryColor = primaryColor,
                                textSizeMultiplier = textSizeMultiplier
                            )
                            
                            selectedDate?.let { date ->
                                Spacer(modifier = Modifier.height(16.dp))
                                HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = displayDateFormat.format(date.time),
                                        color = primaryColor,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontSize = (MaterialTheme.typography.bodyMedium.fontSize.value * textSizeMultiplier).sp
                                        )
                                    )
                                    TextButton(onClick = { selectedDate = null }) {
                                        Text(
                                            "CLEAR",
                                            color = Color.White.copy(alpha = 0.6f),
                                            style = TextStyle(fontSize = (12 * textSizeMultiplier).sp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            // State selection / List view button
            item {
                if (selectedState.isEmpty()) {
                    // Show state selection button
                    Box {
                        Button(
                            onClick = { expanded = true },
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.LocationOn, null, tint = Color.Black)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "SELECT STATE",
                                    fontWeight = FontWeight.Bold,
                                    style = TextStyle(fontSize = (14 * textSizeMultiplier).sp),
                                    color = Color.Black
                                )
                                Text(
                                    text = "Filter events by your state",
                                    style = TextStyle(fontSize = (10 * textSizeMultiplier).sp),
                                    color = Color.Black.copy(alpha = 0.7f)
                                )
                            }
                        }
                        DropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false },
                            modifier = Modifier.fillMaxWidth(0.9f)
                        ) {
                            states.forEach { state ->
                                DropdownMenuItem(
                                    onClick = {
                                        selectedState = state
                                        expanded = false
                                        selectedDate = null
                                        showListView = false
                                    },
                                    text = {
                                        Text(state, style = TextStyle(fontSize = (14 * textSizeMultiplier).sp))
                                    }
                                )
                            }
                        }
                    }
                } else {
                    // Show clear state and list view buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = {
                                selectedState = ""
                                selectedDate = null
                                showListView = false
                            },
                            modifier = Modifier.weight(1f).height(64.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.1f)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Close, null, tint = Color.White, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "VIEW ALL STATES",
                                    fontWeight = FontWeight.Bold,
                                    style = TextStyle(fontSize = (11 * textSizeMultiplier).sp),
                                    color = Color.White,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                        
                        Button(
                            onClick = {
                                // Clear selected date when entering list view
                                if (!showListView) {
                                    selectedDate = null
                                }
                                showListView = !showListView
                            },
                            modifier = Modifier.weight(1f).height(64.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (showListView) primaryColor else Color.White.copy(alpha = 0.1f)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    if (showListView) Icons.Default.CalendarMonth else Icons.AutoMirrored.Filled.List,
                                    null,
                                    tint = if (showListView) Color.Black else Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (showListView) "SHOW CALENDAR" else "VIEW FULL LIST",
                                    fontWeight = FontWeight.Bold,
                                    style = TextStyle(fontSize = (11 * textSizeMultiplier).sp),
                                    color = if (showListView) Color.Black else Color.White,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }
            
            // Events list header
            if (showListView || selectedDate != null) {
                item {
                    val eventCount = filteredEvents.size
                    val headerText = when {
                        showListView && selectedState.isNotEmpty() -> "All $selectedState Events ($eventCount)"
                        showListView -> "All Events ($eventCount)"
                        selectedDate != null && eventCount == 0 -> "No events on this date"
                        selectedDate != null -> "$eventCount event${if (eventCount != 1) "s" else ""} on this date"
                        else -> ""
                    }
                    if (headerText.isNotEmpty()) {
                        Text(
                            text = headerText,
                            color = primaryColor,
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp
                            )
                        )
                    }
                }
            }
            
            // Events list items
            if (showListView || selectedDate != null) {
                itemsIndexed(filteredEvents) { _, event ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .animateContentSize(
                                animationSpec = spring(
                                    dampingRatio = Spring.DampingRatioMediumBouncy,
                                    stiffness = Spring.StiffnessMedium
                                )
                            ),
                        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.1f)),
                        shape = MaterialTheme.shapes.extraSmall
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Text(
                                text = event.name,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = (MaterialTheme.typography.titleMedium.fontSize.value * textSizeMultiplier).sp
                                ),
                                color = Color.White
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CalendarMonth, null, modifier = Modifier.size(16.dp), tint = Color.White.copy(alpha = 0.7f))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = event.date, color = Color.White.copy(alpha = 0.8f), style = TextStyle(fontSize = (14 * textSizeMultiplier).sp))
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.LocationOn, null, modifier = Modifier.size(16.dp), tint = Color.White.copy(alpha = 0.7f))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = event.location, color = Color.White.copy(alpha = 0.8f), style = TextStyle(fontSize = (14 * textSizeMultiplier).sp))
                            }
                            if (auth.currentUser != null && event.timestamp > 0) {
                                Spacer(modifier = Modifier.height(16.dp))
                                Button(
                                    onClick = {
                                        val currentUid = auth.currentUser?.uid
                                        if (!currentUid.isNullOrEmpty()) {
                                            val reminder = CompetitionReminder(event.name, event.date, event.timestamp)
                                            db.collection("users").document(currentUid).update("reminders", FieldValue.arrayUnion(reminder))
                                                .addOnSuccessListener {
                                                    Toast.makeText(context, "Reminder Set!", Toast.LENGTH_SHORT).show()
                                                }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.NotificationsActive, null, tint = Color.Black, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("SET REMINDER", color = Color.Black, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = (14 * textSizeMultiplier).sp))
                                }
                            }
                        }
                    }
                }
            }
            
            // Bottom spacer
            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }
}

@Composable
fun NewsScreen(primaryColor: Color, bgOpacity: Float, isSimplifiedUI: Boolean, textSizeMultiplier: Float) {
    val context = LocalContext.current
    val newsList = remember {
        listOf(
            NewsArticle("Architects of Ambition", "Official theme for 2025-2026.", "Feb 10, 2026", "https://www.fbla.org/news/", "NATIONAL"),
            NewsArticle("NLC Anaheim 2026", "Register for the NLC in Anaheim.", "Jan 25, 2026", "https://www.fbla.org/nlc/", "CONFERENCE"),
            NewsArticle("Competitive Events", "Updated guidelines for high school events.", "Dec 15, 2025", "https://www.fbla.org/high-school/competitive-events/", "HS"),
            NewsArticle("Scholarship Hub", "Over $250k in scholarships available.", "Nov 1, 2025", "https://www.fbla.org/high-school/program/scholarships/", "OPPORTUNITY")
        )
    }
    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgOpacity)))
        LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item {
                Spacer(modifier = Modifier.height(40.dp))
                Text(text = "THE FEED", style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 4.sp, fontWeight = FontWeight.Bold, color = primaryColor, fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp))
                Text(text = "Lead Link News", style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.Black, color = Color.White, fontSize = (MaterialTheme.typography.displaySmall.fontSize.value * textSizeMultiplier).sp))
                Spacer(modifier = Modifier.height(16.dp))
            }
            itemsIndexed(newsList) { _, article ->
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.1f)), shape = MaterialTheme.shapes.extraSmall, onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(article.url))) }) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = article.tag, color = primaryColor, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * textSizeMultiplier).sp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(text = article.date, style = MaterialTheme.typography.labelSmall.copy(fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * textSizeMultiplier).sp), color = Color.White.copy(alpha = 0.5f))
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = article.title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = (MaterialTheme.typography.titleMedium.fontSize.value * textSizeMultiplier).sp), color = Color.White)
                        Text(text = article.summary, style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp), color = Color.White.copy(alpha = 0.7f))
                    }
                }
            }
        }
    }
}

@Composable
fun ResourcesScreen(primaryColor: Color, bgOpacity: Float, isSimplifiedUI: Boolean, textSizeMultiplier: Float) {
    val context = LocalContext.current
    val resourceList = remember {
        listOf(
            ResourceItem("Guidelines", "Requirements for all High School events.", "https://www.fbla.org/high-school/competitive-events/", Icons.AutoMirrored.Filled.Assignment),
            ResourceItem("HS 101 Toolkit", "Essential toolkit for high school management.", "https://www.fbla.org/media/2023/05/FBLA-High-School-101-Toolkit.pdf", Icons.AutoMirrored.Filled.LibraryBooks),
            ResourceItem("Brand Center", "Official logos and professional standards.", "https://www.fbla.org/brand-center/", Icons.Default.Brush),
            ResourceItem("Dress Code", "Attire standards for conferences.", "https://www.fbla.org/about/fbla/fbla-dress-code/", Icons.Default.Checkroom)
        )
    }
    
    data class SocialMedia(val name: String, val handle: String, val url: String, val icon: ImageVector)
    val socialMediaList = remember {
        listOf(
            SocialMedia("Instagram", "@fbla_national", "https://www.instagram.com/fbla_national/", Icons.Default.Camera),
            SocialMedia("Twitter", "@FBLA_National", "https://twitter.com/FBLA_National", Icons.Default.Tag),
            SocialMedia("Facebook", "FutureBusinessLeaders", "https://www.facebook.com/FutureBusinessLeaders/", Icons.Default.ThumbUp),
            SocialMedia("LinkedIn", "FBLA", "https://www.linkedin.com/company/future-business-leaders-america", Icons.Default.Work)
        )
    }
    
    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgOpacity)))
        
        LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp)) {
            item {
                Spacer(modifier = Modifier.height(64.dp))
                Text(text = "TOOLKIT", style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 4.sp, fontWeight = FontWeight.Bold, color = primaryColor, fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp))
                Text(text = "Lead Link Resources", style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.Black, color = Color.White, fontSize = (MaterialTheme.typography.displaySmall.fontSize.value * textSizeMultiplier).sp))
                Spacer(modifier = Modifier.height(32.dp))
            }
            
            // Social Media Section
            item {
                Text(
                    text = "SOCIAL MEDIA",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = (MaterialTheme.typography.titleSmall.fontSize.value * textSizeMultiplier).sp,
                        letterSpacing = 1.2.sp
                    ),
                    color = primaryColor,
                    modifier = Modifier.padding(bottom = 12.dp, top = 8.dp)
                )
            }
            
            items(socialMediaList.size) { index ->
                val social = socialMediaList[index]
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A)),
                    shape = RoundedCornerShape(12.dp),
                    onClick = {
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse(social.url))
                        )
                    }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                social.icon,
                                contentDescription = null,
                                tint = primaryColor,
                                modifier = Modifier.size(24.dp)
                            )
                            Text(
                                text = social.name,
                                color = Color.White,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = (16 * textSizeMultiplier).sp
                                )
                            )
                        }
                        Icon(
                            Icons.Default.OpenInNew,
                            contentDescription = "Open ${social.name}",
                            tint = primaryColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
            
            item {
                Spacer(modifier = Modifier.height(32.dp))
            }
            
            // Resources Grid Header
            item {
                Text(
                    text = "RESOURCES",
                    style = MaterialTheme.typography.labelMedium.copy(
                        letterSpacing = 2.sp,
                        fontWeight = FontWeight.Bold,
                        fontSize = (MaterialTheme.typography.labelMedium.fontSize.value * textSizeMultiplier).sp
                    ),
                    color = Color.White.copy(alpha = 0.6f)
                )
                Spacer(modifier = Modifier.height(16.dp))
            }
            
            // Resources Grid
            resourceList.chunked(2).forEach { rowItems ->
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        rowItems.forEach { resource ->
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(180.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.08f)),
                                shape = RoundedCornerShape(16.dp),
                                onClick = {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(resource.url)))
                                }
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxSize().padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Icon(resource.icon, null, modifier = Modifier.size(40.dp), tint = primaryColor)
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = resource.title,
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontSize = (MaterialTheme.typography.titleMedium.fontSize.value * textSizeMultiplier).sp
                                        ),
                                        color = Color.White,
                                        textAlign = TextAlign.Center
                                    )
                                    Text(
                                        text = "VIEW",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Black,
                                            fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * textSizeMultiplier).sp
                                        ),
                                        color = primaryColor
                                    )
                                }
                            }
                        }
                        // Add spacer if odd number of items
                        if (rowItems.size == 1) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
            
            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun ConnectionRequestsScreen(onBack: () -> Unit, primaryColor: Color, bgOpacity: Float, isSimplifiedUI: Boolean, textSizeMultiplier: Float) {
    val db = FirebaseFirestore.getInstance()
    val auth = FirebaseAuth.getInstance()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    var requests by remember { mutableStateOf<List<ConnectionRequest>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        val currentUid = auth.currentUser?.uid
        if (currentUid != null) {
            db.collection("connectionRequests")
                .whereEqualTo("toUid", currentUid)
                .whereEqualTo("status", "pending")
                .addSnapshotListener { snapshot, _ ->
                    requests = snapshot?.toObjects(ConnectionRequest::class.java) ?: emptyList()
                    isLoading = false
                }
        } else {
            isLoading = false
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgOpacity)))

        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 48.dp, start = 16.dp, end = 16.dp, bottom = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Text("CONNECTION REQUESTS", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black, fontSize = (MaterialTheme.typography.headlineSmall.fontSize.value * textSizeMultiplier).sp), color = Color.White)
            }

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = primaryColor)
                }
            } else if (requests.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.PersonAdd, null, modifier = Modifier.size(80.dp), tint = Color.White.copy(alpha = 0.2f))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("No pending requests", color = Color.White.copy(alpha = 0.6f), style = MaterialTheme.typography.bodyLarge.copy(fontSize = (MaterialTheme.typography.bodyLarge.fontSize.value * textSizeMultiplier).sp))
                    }
                }
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                    itemsIndexed(requests) { _, request ->
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(modifier = Modifier.size(50.dp).background(primaryColor, CircleShape).clip(CircleShape)) {
                                        if (request.fromPfpUrl.isNotEmpty()) {
                                            AsyncImage(model = request.fromPfpUrl, contentDescription = null, contentScale = ContentScale.Crop)
                                        } else {
                                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                                Text(request.fromName.take(1).uppercase(), color = Color.Black, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = (16 * textSizeMultiplier).sp))
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(request.fromName, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium.copy(fontSize = (MaterialTheme.typography.titleMedium.fontSize.value * textSizeMultiplier).sp))
                                        Text(request.fromSchool, color = primaryColor, style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp))
                                        Text(request.fromEmail, color = Color.White.copy(alpha = 0.5f), style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp))
                                    }
                                }
                                
                                Spacer(modifier = Modifier.height(12.dp))
                                
                                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Button(
                                        onClick = {
                                            scope.launch {
                                                try {
                                                    val currentUid = auth.currentUser?.uid ?: return@launch
                                                    
                                                    // Add to both users' connections FIRST (before changing status)
                                                    db.collection("connections").document(currentUid)
                                                        .set(mapOf("connectedUids" to FieldValue.arrayUnion(request.fromUid)), com.google.firebase.firestore.SetOptions.merge()).await()
                                                    
                                                    db.collection("connections").document(request.fromUid)
                                                        .set(mapOf("connectedUids" to FieldValue.arrayUnion(currentUid)), com.google.firebase.firestore.SetOptions.merge()).await()
                                                    
                                                    // Update request status LAST (this removes it from the list)
                                                    db.collection("connectionRequests").document(request.id)
                                                        .update("status", "accepted").await()
                                                    
                                                    Toast.makeText(context, "Request accepted!", Toast.LENGTH_SHORT).show()
                                                } catch (e: Exception) {
                                                    Log.e("ConnectionRequest", "Error accepting request: ${e.message}", e)
                                                    Toast.makeText(context, "Failed to accept: ${e.message}", Toast.LENGTH_LONG).show()
                                                }
                                            }
                                        },
                                        modifier = Modifier.weight(1f).height(40.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.Green),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("ACCEPT", color = Color.White, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = (12 * textSizeMultiplier).sp))
                                    }
                                    
                                    Button(
                                        onClick = {
                                            scope.launch {
                                                try {
                                                    db.collection("connectionRequests").document(request.id)
                                                        .update("status", "declined").await()
                                                    Toast.makeText(context, "Request declined", Toast.LENGTH_SHORT).show()
                                                } catch (e: Exception) {
                                                    Log.e("ConnectionRequest", "Error declining request: ${e.message}", e)
                                                    Toast.makeText(context, "Failed to decline: ${e.message}", Toast.LENGTH_LONG).show()
                                                }
                                            }
                                        },
                                        modifier = Modifier.weight(1f).height(40.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.7f)),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.Close, null, tint = Color.White, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("DECLINE", color = Color.White, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = (12 * textSizeMultiplier).sp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MyConnectionsScreen(onBack: () -> Unit, primaryColor: Color, bgOpacity: Float, isSimplifiedUI: Boolean, textSizeMultiplier: Float) {
    val db = FirebaseFirestore.getInstance()
    val auth = FirebaseAuth.getInstance()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    var connections by remember { mutableStateOf<List<Connection>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var showRemoveDialog by remember { mutableStateOf(false) }
    var connectionToRemove by remember { mutableStateOf<Connection?>(null) }

    LaunchedEffect(Unit) {
        val currentUid = auth.currentUser?.uid
        if (currentUid != null) {
            db.collection("connections").document(currentUid).addSnapshotListener { snapshot, _ ->
                val connectedUids = (snapshot?.get("connectedUids") as? List<*>)?.mapNotNull { it as? String } ?: emptyList()
                
                if (connectedUids.isEmpty()) {
                    connections = emptyList()
                    isLoading = false
                } else {
                    // Fetch user profiles for connected users
                    db.collection("users").whereIn("uid", connectedUids).addSnapshotListener { usersSnapshot, _ ->
                        connections = usersSnapshot?.toObjects(UserProfile::class.java)?.map { profile ->
                            Connection(
                                uid = profile.uid,
                                name = profile.name,
                                email = profile.email,
                                school = profile.school,
                                pfpUrl = profile.pfpUrl,
                                reminders = profile.reminders
                            )
                        } ?: emptyList()
                        isLoading = false
                    }
                }
            }
        } else {
            isLoading = false
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgOpacity)))

        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 48.dp, start = 16.dp, end = 16.dp, bottom = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Text("MY CONNECTIONS", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black, fontSize = (MaterialTheme.typography.headlineSmall.fontSize.value * textSizeMultiplier).sp), color = Color.White)
            }

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = primaryColor)
                }
            } else if (connections.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.People, null, modifier = Modifier.size(80.dp), tint = Color.White.copy(alpha = 0.2f))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("No connections yet", color = Color.White.copy(alpha = 0.6f), style = MaterialTheme.typography.bodyLarge.copy(fontSize = (MaterialTheme.typography.bodyLarge.fontSize.value * textSizeMultiplier).sp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Send connection requests to other peers!", color = Color.White.copy(alpha = 0.4f), style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp), textAlign = TextAlign.Center)
                    }
                }
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                    itemsIndexed(connections) { _, connection ->
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(modifier = Modifier.size(50.dp).background(primaryColor, CircleShape).clip(CircleShape)) {
                                        if (connection.pfpUrl.isNotEmpty()) {
                                            AsyncImage(model = connection.pfpUrl, contentDescription = null, contentScale = ContentScale.Crop)
                                        } else {
                                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                                Text(connection.name.take(1).uppercase(), color = Color.Black, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = (16 * textSizeMultiplier).sp))
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column {
                                        Text(connection.name, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge.copy(fontSize = (MaterialTheme.typography.titleLarge.fontSize.value * textSizeMultiplier).sp))
                                        Text(connection.school, color = primaryColor, style = MaterialTheme.typography.bodyMedium.copy(fontSize = (MaterialTheme.typography.bodyMedium.fontSize.value * textSizeMultiplier).sp))
                                    }
                                }
                                
                                Spacer(modifier = Modifier.height(12.dp))
                                
                                // Email with clickable intent
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable {
                                    val intent = Intent(Intent.ACTION_SENDTO).apply {
                                        data = Uri.parse("mailto:${connection.email}")
                                    }
                                    try {
                                        auth.currentUser?.let { intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK }
                                    } catch (e: Exception) { }
                                }) {
                                    Icon(Icons.Default.Email, null, tint = primaryColor, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(connection.email, color = Color.White, style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp))
                                }

                                if (connection.reminders.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text("Attending Competitions:", color = Color.White.copy(alpha = 0.6f), style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * textSizeMultiplier).sp))
                                    connection.reminders.forEach { reminder ->
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                                            Icon(Icons.Default.EmojiEvents, null, tint = primaryColor, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("${reminder.name} - ${reminder.date}", color = Color.White, style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp))
                                        }
                                    }
                                }
                                
                                Spacer(modifier = Modifier.height(12.dp))
                                
                                Button(
                                    onClick = {
                                        connectionToRemove = connection
                                        showRemoveDialog = true
                                    },
                                    modifier = Modifier.fillMaxWidth().height(40.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.7f)),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.PersonRemove, null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("REMOVE CONNECTION", color = Color.White, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = (12 * textSizeMultiplier).sp))
                                }
                            }
                        }
                    }
                }
            }
        }
        
        // Confirmation Dialog
        if (showRemoveDialog && connectionToRemove != null) {
            AlertDialog(
                onDismissRequest = {
                    showRemoveDialog = false
                    connectionToRemove = null
                },
                title = {
                    Text("Remove Connection?", color = Color.White, fontWeight = FontWeight.Bold)
                },
                text = {
                    Text("Are you sure you want to remove ${connectionToRemove?.name} from your connections?", color = Color.White.copy(alpha = 0.8f))
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            scope.launch {
                                try {
                                    val currentUid = auth.currentUser?.uid ?: return@launch
                                    val otherUid = connectionToRemove?.uid ?: return@launch
                                    
                                    // Remove from both users' connections
                                    db.collection("connections").document(currentUid)
                                        .update("connectedUids", FieldValue.arrayRemove(otherUid)).await()
                                    
                                    db.collection("connections").document(otherUid)
                                        .update("connectedUids", FieldValue.arrayRemove(currentUid)).await()
                                    
                                    Toast.makeText(context, "Connection removed", Toast.LENGTH_SHORT).show()
                                    showRemoveDialog = false
                                    connectionToRemove = null
                                } catch (e: Exception) {
                                    Log.e("RemoveConnection", "Error removing connection: ${e.message}", e)
                                    Toast.makeText(context, "Failed to remove: ${e.message}", Toast.LENGTH_LONG).show()
                                }
                            }
                        }
                    ) {
                        Text("REMOVE", color = Color.Red, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            showRemoveDialog = false
                            connectionToRemove = null
                        }
                    ) {
                        Text("CANCEL", color = Color.White.copy(alpha = 0.7f))
                    }
                },
                containerColor = Color(0xFF1A1A1A),
                titleContentColor = Color.White,
                textContentColor = Color.White
            )
        }
    }
}