package com.example.myapplication

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.myapplication.ui.theme.MyApplicationTheme
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainScreen()
            }
        }
    }
}

data class CompetitionReminder(
    val name: String = "",
    val date: String = "",
    val timestamp: Long = 0L
)

data class UserProfile(
    val uid: String = "",
    val name: String = "",
    val school: String = "",
    val year: String = "",
    val state: String = "",
    val bio: String = "",
    val pfpUrl: String = "",
    val reminders: List<CompetitionReminder> = emptyList()
)

@Composable
fun AuthScreen(onLoginSuccess: () -> Unit, onBack: () -> Unit) {
    var isLogin by remember { mutableStateOf(true) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var school by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }
    var statePref by remember { mutableStateOf("") }

    var isLoading by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()

    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.fbla_bg),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.9f)))

        IconButton(onClick = onBack, modifier = Modifier.padding(top = 48.dp, start = 16.dp)) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            item {
                Icon(Icons.Default.AccountCircle, null, modifier = Modifier.size(80.dp), tint = Color(0xFFFFB800))
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = if (isLogin) "WELCOME TO LEAD LINK" else "JOIN LEAD LINK",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White,
                    fontWeight = FontWeight.Black
                )
                Spacer(modifier = Modifier.height(32.dp))

                if (!isLogin) {
                    AuthTextField(value = name, onValueChange = { name = it }, label = "Full Name")
                    Spacer(modifier = Modifier.height(12.dp))
                    AuthTextField(value = school, onValueChange = { school = it }, label = "School Name")
                    Spacer(modifier = Modifier.height(12.dp))
                    AuthTextField(value = year, onValueChange = { year = it }, label = "Graduation Year")
                    Spacer(modifier = Modifier.height(12.dp))
                    AuthTextField(value = statePref, onValueChange = { statePref = it }, label = "State")
                    Spacer(modifier = Modifier.height(12.dp))
                }

                AuthTextField(value = email, onValueChange = { email = it }, label = "Email Address")
                Spacer(modifier = Modifier.height(12.dp))
                AuthTextField(value = password, onValueChange = { password = it }, label = "Password", isPassword = true)

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = {
                        if (email.isEmpty() || password.isEmpty() || (!isLogin && (name.isEmpty() || school.isEmpty()))) {
                            Toast.makeText(context, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        isLoading = true
                        if (isLogin) {
                            auth.signInWithEmailAndPassword(email, password).addOnCompleteListener { task ->
                                if (task.isSuccessful) onLoginSuccess()
                                else {
                                    isLoading = false
                                    Toast.makeText(context, "Error: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        } else {
                            auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    val profile = UserProfile(uid = auth.currentUser?.uid ?: "", name = name, school = school, year = year, state = statePref)
                                    db.collection("users").document(auth.currentUser!!.uid).set(profile)
                                        .addOnSuccessListener { onLoginSuccess() }
                                        .addOnFailureListener { isLoading = false }
                                } else {
                                    isLoading = false
                                    Toast.makeText(context, "Error: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB800)),
                    shape = RoundedCornerShape(12.dp),
                    enabled = !isLoading
                ) {
                    if (isLoading) CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(24.dp))
                    else Text(if (isLogin) "SIGN IN" else "REGISTER", color = Color.Black, fontWeight = FontWeight.Bold)
                }

                TextButton(onClick = { isLogin = !isLogin }) {
                    Text(if (isLogin) "New here? Create an account" else "Have an account? Sign in", color = Color(0xFFFFB800))
                }
            }
        }
    }
}

@Composable
fun AuthTextField(value: String, onValueChange: (String) -> Unit, label: String, isPassword: Boolean = false) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        visualTransformation = if (isPassword) PasswordVisualTransformation() else VisualTransformation.None,
        colors = OutlinedTextFieldDefaults.colors(
            unfocusedTextColor = Color.White,
            focusedTextColor = Color.White,
            unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
            focusedBorderColor = Color(0xFFFFB800)
        ),
        shape = RoundedCornerShape(12.dp)
    )
}

data class FblaEvent(val name: String, val date: String, val location: String, val timestamp: Long = 0L)
data class NewsArticle(val title: String, val summary: String, val date: String, val url: String, val tag: String = "NATIONAL")
data class ResourceItem(val title: String, val description: String, val url: String, val icon: ImageVector)

@Composable
fun MainScreen() {
    var selectedTab by remember { mutableIntStateOf(2) }
    val auth = FirebaseAuth.getInstance()
    var currentUser by remember { mutableStateOf(auth.currentUser) }
    var showAuthFlow by remember { mutableStateOf(false) }
    var currentSubScreen by remember { mutableStateOf<String?>(null) }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Persisted settings
    val bgOpacity by SettingsStore.bgOpacityFlow(context).collectAsState(initial = 0.9f)
    val primaryColor by SettingsStore.primaryColorFlow(context).collectAsState(initial = Color(0xFFFFB800))
    val isHighContrast by SettingsStore.highContrastFlow(context).collectAsState(initial = false)
    val textSizeMultiplier by SettingsStore.textSizeFlow(context).collectAsState(initial = 1.0f)
    val isSimplifiedUI by SettingsStore.simplifiedUiFlow(context).collectAsState(initial = false)
    val notificationsEnabled by SettingsStore.notificationsEnabledFlow(context).collectAsState(initial = true)
    val publicProfile by SettingsStore.publicProfileFlow(context).collectAsState(initial = true)

    val effectivePrimary = if (isHighContrast) Color.White else primaryColor
    val effectiveBgOpacity = if (isHighContrast) 1.0f else bgOpacity

    Scaffold(
        bottomBar = {
            if (currentSubScreen == null) {
                NavigationBar(containerColor = Color(0xFF000D1A), contentColor = Color.White) {
                    listOf(
                        Triple(0, Icons.Filled.Person, "Profile"),
                        Triple(1, Icons.Filled.Event, "Events"),
                        Triple(2, Icons.Filled.Home, "Home"),
                        Triple(3, Icons.AutoMirrored.Filled.Article, "News"),
                        Triple(4, Icons.AutoMirrored.Filled.MenuBook, "Resources")
                    ).forEach { (index, icon, label) ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, style = TextStyle(fontSize = (12 * textSizeMultiplier).sp)) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = effectivePrimary,
                                selectedTextColor = effectivePrimary,
                                unselectedIconColor = Color.White.copy(alpha = 0.4f),
                                unselectedTextColor = Color.White.copy(alpha = 0.4f),
                                indicatorColor = Color.White.copy(alpha = 0.1f)
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(if (currentSubScreen != null) PaddingValues(0.dp) else padding).fillMaxSize()) {
            if (currentSubScreen == "find_links") {
                MemberSearchScreen(onBack = { currentSubScreen = null }, primaryColor = effectivePrimary, bgOpacity = effectiveBgOpacity, isSimplifiedUI = isSimplifiedUI, textSizeMultiplier = textSizeMultiplier)
            } else {
                when (selectedTab) {
                    0 -> {
                        if (currentUser == null) {
                            if (showAuthFlow) {
                                AuthScreen(
                                    onLoginSuccess = {
                                        currentUser = auth.currentUser
                                        showAuthFlow = false
                                    },
                                    onBack = { showAuthFlow = false }
                                )
                            } else {
                                LoggedOutProfileScreen(onLoginClick = { showAuthFlow = true }, primaryColor = effectivePrimary, bgOpacity = effectiveBgOpacity, isSimplifiedUI = isSimplifiedUI)
                            }
                        } else {
                            ProfileScreen(
                                onLogout = {
                                    auth.signOut()
                                    currentUser = null
                                },
                                onFindLinksClick = { currentSubScreen = "find_links" },
                                bgOpacity = bgOpacity,
                                onBgOpacityChange = { scope.launch { SettingsStore.saveBgOpacity(context, it) } },
                                primaryColor = primaryColor,
                                onPrimaryColorChange = { scope.launch { SettingsStore.savePrimaryColor(context, it) } },
                                isHighContrast = isHighContrast,
                                onHighContrastChange = { scope.launch { SettingsStore.saveHighContrast(context, it) } },
                                textSizeMultiplier = textSizeMultiplier,
                                onTextSizeChange = { scope.launch { SettingsStore.saveTextSize(context, it) } },
                                isSimplifiedUI = isSimplifiedUI,
                                onSimplifiedUIChange = { scope.launch { SettingsStore.saveSimplifiedUi(context, it) } },
                                notificationsEnabled = notificationsEnabled,
                                onNotificationsChange = { scope.launch { SettingsStore.saveNotificationsEnabled(context, it) } },
                                publicProfile = publicProfile,
                                onPublicProfileChange = { scope.launch { SettingsStore.savePublicProfile(context, it) } }
                            )
                        }
                    }
                    1 -> EventsPlaceholder(effectivePrimary, effectiveBgOpacity, isSimplifiedUI, textSizeMultiplier)
                    2 -> HomeScreen(effectivePrimary, effectiveBgOpacity, isSimplifiedUI, textSizeMultiplier)
                    3 -> NewsScreen(effectivePrimary, effectiveBgOpacity, isSimplifiedUI, textSizeMultiplier)
                    4 -> ResourcesScreen(effectivePrimary, effectiveBgOpacity, isSimplifiedUI, textSizeMultiplier)
                }
            }
        }
    }
}

@Composable
fun LoggedOutProfileScreen(onLoginClick: () -> Unit, primaryColor: Color, bgOpacity: Float, isSimplifiedUI: Boolean) {
    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgOpacity)))
        Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(Icons.Default.AccountCircle, null, modifier = Modifier.size(100.dp), tint = Color.White.copy(alpha = 0.2f))
            Spacer(modifier = Modifier.height(24.dp))
            Text("Sign in to view your profile", color = Color.White.copy(alpha = 0.6f))
            Spacer(modifier = Modifier.height(24.dp))
            Button(
                onClick = onLoginClick,
                colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.width(200.dp).height(50.dp)
            ) {
                Text("LOGIN OR SIGNUP", color = if (primaryColor == Color.White) Color.Black else Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun ProfileScreen(
    onLogout: () -> Unit,
    onFindLinksClick: () -> Unit,
    bgOpacity: Float,
    onBgOpacityChange: (Float) -> Unit,
    primaryColor: Color,
    onPrimaryColorChange: (Color) -> Unit,
    isHighContrast: Boolean,
    onHighContrastChange: (Boolean) -> Unit,
    textSizeMultiplier: Float,
    onTextSizeChange: (Float) -> Unit,
    isSimplifiedUI: Boolean,
    onSimplifiedUIChange: (Boolean) -> Unit,
    notificationsEnabled: Boolean,
    onNotificationsChange: (Boolean) -> Unit,
    publicProfile: Boolean,
    onPublicProfileChange: (Boolean) -> Unit
) {
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    val context = LocalContext.current

    var profile by remember { mutableStateOf<UserProfile?>(null) }
    var isEditing by remember { mutableStateOf(false) }
    var isProcessingImage by remember { mutableStateOf(false) }

    var name by remember { mutableStateOf("") }
    var school by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }
    var statePref by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    var pfpUrl by remember { mutableStateOf("") }

    val effectivePrimary = if (isHighContrast) Color.White else primaryColor
    val effectiveBgOpacity = if (isHighContrast) 1.0f else bgOpacity

    val pfpLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            isProcessingImage = true
            try {
                val inputStream = context.contentResolver.openInputStream(it)
                val bitmap = BitmapFactory.decodeStream(inputStream)
                val resized = Bitmap.createScaledBitmap(bitmap, 200, 200, true)
                val outputStream = ByteArrayOutputStream()
                resized.compress(Bitmap.CompressFormat.JPEG, 70, outputStream)
                val bytes = outputStream.toByteArray()
                val base64String = "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.DEFAULT)
                pfpUrl = base64String
                db.collection("users").document(auth.currentUser!!.uid).update("pfpUrl", pfpUrl)
                isProcessingImage = false
                Toast.makeText(context, "Profile Picture Updated!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                isProcessingImage = false
                Toast.makeText(context, "Failed to process image", Toast.LENGTH_SHORT).show()
            }
        }
    }

    LaunchedEffect(Unit) {
        val uid = auth.currentUser?.uid
        if (uid != null) {
            db.collection("users").document(uid).addSnapshotListener { snapshot, error ->
                if (error != null) return@addSnapshotListener
                val data = snapshot?.toObject(UserProfile::class.java)
                profile = data
                if (data != null && !isEditing) {
                    name = data.name
                    school = data.school
                    year = data.year
                    statePref = data.state
                    bio = data.bio
                    pfpUrl = data.pfpUrl
                }
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = effectiveBgOpacity)))

        if (profile == null) {
            CircularProgressIndicator(modifier = Modifier.align(Alignment.Center), color = effectivePrimary)
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                item {
                    Spacer(modifier = Modifier.height(60.dp))
                    Box(modifier = Modifier.size(130.dp)) {
                        Box(
                            modifier = Modifier
                                .size(120.dp)
                                .background(effectivePrimary, CircleShape)
                                .clip(CircleShape)
                                .clickable { pfpLauncher.launch("image/*") }
                                .align(Alignment.TopStart),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isProcessingImage) {
                                CircularProgressIndicator(color = Color.Black)
                            } else if (pfpUrl.isNotEmpty()) {
                                AsyncImage(
                                    model = pfpUrl,
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Text(name.take(1).ifEmpty { "U" }.uppercase(), color = Color.Black, style = MaterialTheme.typography.displayMedium.copy(fontSize = (MaterialTheme.typography.displayMedium.fontSize.value * textSizeMultiplier).sp), fontWeight = FontWeight.Bold)
                            }
                        }
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color.Black.copy(alpha = 0.7f), CircleShape)
                                .background(effectivePrimary.copy(alpha = 0.2f), CircleShape)
                                .align(Alignment.BottomEnd)
                                .clickable { pfpLauncher.launch("image/*") },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.CameraAlt, null, tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                    }
                    Spacer(modifier = Modifier.height(24.dp))

                    if (isEditing) {
                        ProfileEditField(value = name, onValueChange = { name = it }, label = "Full Name")
                        ProfileEditField(value = school, onValueChange = { school = it }, label = "School")
                        ProfileEditField(value = year, onValueChange = { year = it }, label = "Grad Year")
                        ProfileEditField(value = statePref, onValueChange = { statePref = it }, label = "State")
                        ProfileEditField(value = bio, onValueChange = { bio = it }, label = "Short Bio")
                    } else {
                        Text(text = name.ifEmpty { "Member" }, style = MaterialTheme.typography.headlineMedium.copy(fontSize = (MaterialTheme.typography.headlineMedium.fontSize.value * textSizeMultiplier).sp), color = Color.White, fontWeight = FontWeight.Black)
                        Text(text = school.ifEmpty { "Unknown School" }, style = MaterialTheme.typography.bodyLarge.copy(fontSize = (MaterialTheme.typography.bodyLarge.fontSize.value * textSizeMultiplier).sp), color = effectivePrimary)
                        Text(text = "Class of ${year.ifEmpty { "20XX" }} • ${statePref.ifEmpty { "N/A" }}", style = MaterialTheme.typography.bodyMedium.copy(fontSize = (MaterialTheme.typography.bodyMedium.fontSize.value * textSizeMultiplier).sp), color = Color.White.copy(alpha = 0.6f))
                        if (bio.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = bio, style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp), color = Color.White.copy(alpha = 0.8f), textAlign = TextAlign.Center)
                        }
                    }

                    Spacer(modifier = Modifier.height(32.dp))

                    Button(
                        onClick = onFindLinksClick,
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = effectivePrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Search, null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("FIND PEERS", color = Color.Black, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = (14 * textSizeMultiplier).sp))
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = {
                                if (isEditing) {
                                    val newProfile = profile!!.copy(name = name, school = school, year = year, state = statePref, bio = bio, pfpUrl = pfpUrl)
                                    db.collection("users").document(auth.currentUser!!.uid).set(newProfile)
                                    profile = newProfile
                                }
                                isEditing = !isEditing
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = if (isEditing) Color.Green else Color.White.copy(alpha = 0.1f)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(if (isEditing) Icons.Default.Check else Icons.Default.Edit, null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (isEditing) "SAVE" else "EDIT", style = TextStyle(fontSize = (12 * textSizeMultiplier).sp))
                        }

                        Button(
                            onClick = onLogout,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.7f)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Logout, null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("LOGOUT", style = TextStyle(fontSize = (12 * textSizeMultiplier).sp))
                        }
                    }

                    if (profile?.reminders?.isNotEmpty() == true) {
                        Spacer(modifier = Modifier.height(48.dp))
                        Text(
                            text = "MY REMINDERS",
                            style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 2.sp, fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp),
                            color = effectivePrimary,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Start
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        profile!!.reminders.forEach { reminder ->
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(reminder.name, color = Color.White, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = (14 * textSizeMultiplier).sp))
                                        Text(reminder.date, color = Color.White.copy(alpha = 0.6f), style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp))
                                    }
                                    IconButton(onClick = {
                                        db.collection("users").document(auth.currentUser!!.uid).update(
                                            "reminders", FieldValue.arrayRemove(reminder)
                                        )
                                    }) {
                                        Icon(Icons.Default.Delete, null, tint = Color.Red.copy(alpha = 0.7f))
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(48.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(text = "VISUALS", style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 2.sp, fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp), color = effectivePrimary, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Background Intensity", color = Color.White, style = MaterialTheme.typography.bodyMedium.copy(fontSize = (MaterialTheme.typography.bodyMedium.fontSize.value * textSizeMultiplier).sp), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
                    Slider(value = bgOpacity, onValueChange = onBgOpacityChange, valueRange = 0.4f..0.95f, colors = SliderDefaults.colors(thumbColor = effectivePrimary, activeTrackColor = effectivePrimary))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Theme Color", color = Color.White, style = MaterialTheme.typography.bodyMedium.copy(fontSize = (MaterialTheme.typography.bodyMedium.fontSize.value * textSizeMultiplier).sp), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        listOf(Color(0xFFFFB800), Color(0xFF00B4FF), Color(0xFFFF4D4D), Color(0xFF4DFF88)).forEach { color ->
                            Box(modifier = Modifier.size(40.dp).background(color, CircleShape).clip(CircleShape).clickable { onPrimaryColorChange(color) }.background(if (primaryColor == color) Color.White.copy(alpha = 0.3f) else Color.Transparent))
                        }
                    }

                    Spacer(modifier = Modifier.height(48.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(text = "ACCESSIBILITY", style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 2.sp, fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp), color = effectivePrimary, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
                    Spacer(modifier = Modifier.height(16.dp))

                    SettingToggle(title = "High Contrast", subtitle = "Use solid black/white for clarity", icon = Icons.Default.Contrast, checked = isHighContrast, onCheckedChange = onHighContrastChange, primaryColor = effectivePrimary, textSizeMultiplier = textSizeMultiplier)

                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Text Size Multiplier: ${String.format("%.1f", textSizeMultiplier)}x", color = Color.White, style = MaterialTheme.typography.bodyMedium.copy(fontSize = (MaterialTheme.typography.bodyMedium.fontSize.value * textSizeMultiplier).sp))
                    Slider(value = textSizeMultiplier, onValueChange = onTextSizeChange, valueRange = 0.8f..1.5f, colors = SliderDefaults.colors(thumbColor = effectivePrimary, activeTrackColor = effectivePrimary))

                    Spacer(modifier = Modifier.height(16.dp))
                    SettingToggle(title = "Simplified UI", subtitle = "Hide background images", icon = Icons.Default.VisibilityOff, checked = isSimplifiedUI, onCheckedChange = onSimplifiedUIChange, primaryColor = effectivePrimary, textSizeMultiplier = textSizeMultiplier)

                    Spacer(modifier = Modifier.height(48.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(text = "APP SETTINGS", style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 2.sp, fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp), color = effectivePrimary, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
                    Spacer(modifier = Modifier.height(16.dp))
                    SettingToggle(title = "Push Notifications", subtitle = "Get alerts for events and news", icon = Icons.Default.Notifications, checked = notificationsEnabled, onCheckedChange = onNotificationsChange, primaryColor = effectivePrimary, textSizeMultiplier = textSizeMultiplier)
                    SettingToggle(title = "Public Profile", subtitle = "Allow others to see your progress", icon = Icons.Default.Public, checked = publicProfile, onCheckedChange = onPublicProfileChange, primaryColor = effectivePrimary, textSizeMultiplier = textSizeMultiplier)
                    Spacer(modifier = Modifier.height(24.dp))
                    TextButton(onClick = { }, modifier = Modifier.fillMaxWidth()) { Text("About Lead Link v1.0.4", color = Color.White.copy(alpha = 0.4f), style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp)) }
                    TextButton(onClick = { }, modifier = Modifier.fillMaxWidth()) { Text("Delete Account", color = Color.Red.copy(alpha = 0.5f), style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp)) }
                    Spacer(modifier = Modifier.height(40.dp))
                }
            }
        }
    }
}

@Composable
fun SettingToggle(title: String, subtitle: String, icon: ImageVector, checked: Boolean, onCheckedChange: (Boolean) -> Unit, primaryColor: Color, textSizeMultiplier: Float) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Color.White.copy(alpha = 0.6f), modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Color.White, style = MaterialTheme.typography.bodyLarge.copy(fontSize = (MaterialTheme.typography.bodyLarge.fontSize.value * textSizeMultiplier).sp))
            Text(subtitle, color = Color.White.copy(alpha = 0.5f), style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp))
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange, colors = SwitchDefaults.colors(checkedThumbColor = primaryColor, checkedTrackColor = primaryColor.copy(alpha = 0.3f), uncheckedThumbColor = Color.Gray, uncheckedTrackColor = Color.Gray.copy(alpha = 0.3f)))
    }
}

@Composable
fun ProfileEditField(value: String, onValueChange: (String) -> Unit, label: String) {
    OutlinedTextField(value = value, onValueChange = onValueChange, label = { Text(label) }, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), colors = OutlinedTextFieldDefaults.colors(unfocusedTextColor = Color.White, focusedTextColor = Color.White))
}

@Composable
fun HomeScreen(primaryColor: Color, bgOpacity: Float, isSimplifiedUI: Boolean, textSizeMultiplier: Float) {
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    var profile by remember { mutableStateOf<UserProfile?>(null) }
    val tips = listOf("Networking isn't just about collecting contacts.", "Success is not final, failure is not fatal.", "The best way to predict the future is to create it.", "Business opportunities are like buses.")
    var currentTipIndex by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        val uid = auth.currentUser?.uid
        if (uid != null) {
            db.collection("users").document(uid).addSnapshotListener { snapshot, _ ->
                profile = snapshot?.toObject(UserProfile::class.java)
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgOpacity)))

        LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(24.dp)) {
            item {
                Spacer(modifier = Modifier.height(40.dp))
                Text(
                    text = "WELCOME, ${profile?.name?.split(" ")?.get(0)?.uppercase() ?: "MEMBER"}",
                    style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 4.sp, fontWeight = FontWeight.Bold, color = primaryColor, fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp)
                )
                Text(text = "Lead Link Dashboard", style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.Black, color = Color.White, fontSize = (MaterialTheme.typography.displaySmall.fontSize.value * textSizeMultiplier).sp))
                Spacer(modifier = Modifier.height(32.dp))
            }

            if (profile?.reminders?.isNotEmpty() == true) {
                itemsIndexed(profile!!.reminders) { _, reminder ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                        colors = CardDefaults.cardColors(containerColor = primaryColor.copy(alpha = 0.15f)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, primaryColor.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(24.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.AutoMirrored.Filled.EventNote, null, tint = primaryColor, modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.width(12.dp))
                                Text("UPCOMING COMPETITION", color = Color.White.copy(alpha = 0.6f), style = MaterialTheme.typography.labelSmall.copy(fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * textSizeMultiplier).sp))
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(reminder.name, color = Color.White, style = MaterialTheme.typography.titleLarge.copy(fontSize = (MaterialTheme.typography.titleLarge.fontSize.value * textSizeMultiplier).sp), fontWeight = FontWeight.Bold)
                            Text(reminder.date, color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.bodyMedium.copy(fontSize = (MaterialTheme.typography.bodyMedium.fontSize.value * textSizeMultiplier).sp))

                            val daysLeft = if (reminder.timestamp > System.currentTimeMillis()) {
                                TimeUnit.MILLISECONDS.toDays(reminder.timestamp - System.currentTimeMillis())
                            } else 0

                            Spacer(modifier = Modifier.height(16.dp))
                            LinearProgressIndicator(
                                progress = { (100 - daysLeft.coerceIn(0, 100)) / 100f },
                                modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
                                color = primaryColor,
                                trackColor = Color.White.copy(alpha = 0.1f)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("$daysLeft DAYS REMAINING", color = primaryColor, style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Black, fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp))
                        }
                    }
                }
            } else {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.AutoMirrored.Filled.EventNote, null, tint = Color.White.copy(alpha = 0.3f), modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("No Active Reminders", color = Color.White.copy(alpha = 0.5f), style = TextStyle(fontSize = (14 * textSizeMultiplier).sp))
                            Text("Set one in the Events tab", color = Color.White.copy(alpha = 0.3f), style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp))
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    StatCard(Modifier.weight(1f), "COMPETITIONS", profile?.reminders?.size?.toString() ?: "0", Icons.Default.EmojiEvents, primaryColor, textSizeMultiplier)
                }
                Spacer(modifier = Modifier.height(32.dp))
            }

            item {
                Text(text = "CHAPTER UPDATES", color = Color.White.copy(alpha = 0.6f), style = MaterialTheme.typography.labelLarge.copy(fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp))
                Spacer(modifier = Modifier.height(16.dp))
            }

            itemsIndexed(listOf(
                "New 'Public Speaking' guide" to "Yesterday",
                "Chapter Meeting Minutes posted" to "2 hours ago",
                "SLC Registration is now open!" to "3 days ago"
            )) { _, (activity, time) ->
                Column {
                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(10.dp).background(primaryColor, CircleShape))
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(text = activity, color = Color.White, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold, fontSize = (MaterialTheme.typography.bodyMedium.fontSize.value * textSizeMultiplier).sp))
                            Text(text = time, color = Color.White.copy(alpha = 0.5f), style = MaterialTheme.typography.labelSmall.copy(fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * textSizeMultiplier).sp))
                        }
                    }
                    HorizontalDivider(color = Color.White.copy(alpha = 0.05f))
                }
            }

            item {
                Spacer(modifier = Modifier.height(40.dp))
                Card(
                    onClick = { currentTipIndex = (currentTipIndex + 1) % tips.size },
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = primaryColor),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(24.dp)) {
                        Icon(Icons.Default.Lightbulb, null, tint = Color.Black)
                        Text("LEADERSHIP TIP", color = Color.Black.copy(alpha = 0.6f), style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * textSizeMultiplier).sp))
                        Text(text = tips[currentTipIndex], color = Color.Black, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif, fontSize = (MaterialTheme.typography.bodyLarge.fontSize.value * textSizeMultiplier).sp))
                    }
                }
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}

@Composable
fun StatCard(modifier: Modifier, label: String, value: String, icon: ImageVector, primaryColor: Color, textSizeMultiplier: Float) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Icon(icon, null, tint = primaryColor, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(12.dp))
            Text(text = value, color = Color.White, style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black, fontSize = (MaterialTheme.typography.headlineSmall.fontSize.value * textSizeMultiplier).sp))
            Text(text = label, color = Color.White.copy(alpha = 0.4f), style = MaterialTheme.typography.labelSmall.copy(fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * textSizeMultiplier).sp))
        }
    }
}

@Composable
fun MemberSearchScreen(onBack: () -> Unit, primaryColor: Color, bgOpacity: Float, isSimplifiedUI: Boolean, textSizeMultiplier: Float) {
    val db = FirebaseFirestore.getInstance()
    val auth = FirebaseAuth.getInstance()
    var members by remember { mutableStateOf<List<UserProfile>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var searchQuery by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        val currentUid = auth.currentUser?.uid
        if (currentUid != null) {
            db.collection("users").addSnapshotListener { snapshot, _ ->
                members = snapshot?.toObjects(UserProfile::class.java)?.filter { it.uid != currentUid } ?: emptyList()
                isLoading = false
            }
        } else {
            isLoading = false
        }
    }

    val filteredMembers = remember(searchQuery, members) {
        if (searchQuery.isEmpty()) members
        else members.filter { it.name.contains(searchQuery, ignoreCase = true) }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgOpacity)))

        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 48.dp, start = 16.dp, end = 16.dp, bottom = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Text("FIND PEERS", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black, fontSize = (MaterialTheme.typography.headlineSmall.fontSize.value * textSizeMultiplier).sp), color = Color.White)
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                placeholder = { Text("Search by name...", color = Color.White.copy(alpha = 0.5f), style = TextStyle(fontSize = (14 * textSizeMultiplier).sp)) },
                leadingIcon = { Icon(Icons.Default.Search, null, tint = primaryColor) },
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedTextColor = Color.White,
                    focusedTextColor = Color.White,
                    unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                    focusedBorderColor = primaryColor
                ),
                shape = RoundedCornerShape(12.dp)
            )

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = primaryColor)
                }
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                    itemsIndexed(filteredMembers) { _, member ->
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(modifier = Modifier.size(50.dp).background(primaryColor, CircleShape).clip(CircleShape)) {
                                        if (member.pfpUrl.isNotEmpty()) {
                                            AsyncImage(model = member.pfpUrl, contentDescription = null, contentScale = ContentScale.Crop)
                                        } else {
                                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                                Text(member.name.take(1).uppercase(), color = Color.Black, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = (16 * textSizeMultiplier).sp))
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column {
                                        Text(member.name, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge.copy(fontSize = (MaterialTheme.typography.titleLarge.fontSize.value * textSizeMultiplier).sp))
                                        Text(member.school, color = primaryColor, style = MaterialTheme.typography.bodyMedium.copy(fontSize = (MaterialTheme.typography.bodyMedium.fontSize.value * textSizeMultiplier).sp))
                                    }
                                }

                                if (member.bio.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(text = member.bio, color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp))
                                }

                                if (member.reminders.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text("Competitions:", color = Color.White.copy(alpha = 0.6f), style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * textSizeMultiplier).sp))
                                    member.reminders.forEach { reminder ->
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                                            Icon(Icons.Default.EmojiEvents, null, tint = primaryColor, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(reminder.name, color = Color.White, style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EventsPlaceholder(primaryColor: Color, bgOpacity: Float, isSimplifiedUI: Boolean, textSizeMultiplier: Float) {
    var selectedState by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    val nationalConference = FblaEvent("National Leadership Conference (NLC)", "June 29 - July 2, 2026", "Anaheim, CA", 1782691200000L)
    val eventsByState = remember {
        val statesList = listOf("Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming")
        val baseEvents = mapOf(
            "Alabama" to listOf(FblaEvent("District Workshops", "Jan-Feb 2026", "Various Locations"), FblaEvent("State Leadership Conference", "April 9–10, 2026", "Mobile", 1775692800000L)),
            "California" to listOf(FblaEvent("Section Leadership Conferences", "Feb-March 2026", "Various Sections"), FblaEvent("State Leadership Conference", "April 23–26, 2026", "Sacramento", 1776902400000L)),
            "Texas" to listOf(FblaEvent("Area Leadership Conferences", "Jan-Feb 2026", "Areas 1-9"), FblaEvent("State Leadership Conference", "March 25–27, 2026", "Galveston", 1774396800000L)),
            "Wisconsin" to listOf(FblaEvent("Region 1 Leadership Conference", "Feb 7, 2026", "Shell Lake", 1770336000000L), FblaEvent("State Leadership Conference", "April 13–14, 2026", "Madison", 1776038400000L))
        )
        statesList.associateWith { (baseEvents[it] ?: listOf(FblaEvent("Regional Leadership Conference", "Jan-Feb 2026", "Various"), FblaEvent("State Leadership Conference", "March-April 2026", "TBD", 1775001600000L))) + nationalConference }
    }
    val states = remember { eventsByState.keys.toList().sorted() }
    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgOpacity)))
        Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            if (selectedState.isEmpty()) {
                Spacer(modifier = Modifier.height(100.dp))
                Text(text = "FUTURE BUSINESS LEADERS", style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 5.sp, fontWeight = FontWeight.SemiBold, fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp), color = Color.White.copy(alpha = 0.9f), modifier = Modifier.padding(horizontal = 24.dp))
                Text(text = "Events 2026", style = MaterialTheme.typography.displayMedium.copy(fontWeight = FontWeight.Bold, fontSize = (MaterialTheme.typography.displayMedium.fontSize.value * textSizeMultiplier).sp), color = Color.White, modifier = Modifier.padding(horizontal = 24.dp))
                Spacer(modifier = Modifier.height(60.dp))
            } else {
                Spacer(modifier = Modifier.height(24.dp))
            }
            Box(modifier = Modifier.padding(horizontal = 24.dp)) {
                Button(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth().height(64.dp), colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF001A35)), shape = MaterialTheme.shapes.extraSmall) {
                    Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Search, null); Spacer(modifier = Modifier.width(16.dp)); Text(text = if (selectedState.isEmpty()) "SEARCH BY STATE" else selectedState.uppercase(), style = TextStyle(fontSize = (14 * textSizeMultiplier).sp)) }
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }, modifier = Modifier.fillMaxWidth(0.9f)) {
                    states.forEach { state -> DropdownMenuItem(onClick = { selectedState = state; expanded = false }, text = { Text(state, style = TextStyle(fontSize = (14 * textSizeMultiplier).sp)) }) }
                }
            }
            if (selectedState.isNotEmpty()) {
                Spacer(modifier = Modifier.height(24.dp))
                LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    itemsIndexed(eventsByState[selectedState] ?: emptyList()) { _, event ->
                        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.1f)), shape = MaterialTheme.shapes.extraSmall) {
                            Column(modifier = Modifier.padding(20.dp)) {
                                Text(text = event.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = (MaterialTheme.typography.titleMedium.fontSize.value * textSizeMultiplier).sp), color = Color.White)
                                Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.CalendarMonth, null, modifier = Modifier.size(16.dp), tint = Color.White.copy(alpha = 0.7f)); Spacer(modifier = Modifier.width(8.dp)); Text(text = event.date, color = Color.White.copy(alpha = 0.8f), style = TextStyle(fontSize = (14 * textSizeMultiplier).sp)) }
                                Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.LocationOn, null, modifier = Modifier.size(16.dp), tint = Color.White.copy(alpha = 0.7f)); Spacer(modifier = Modifier.width(8.dp)); Text(text = event.location, color = Color.White.copy(alpha = 0.8f), style = TextStyle(fontSize = (14 * textSizeMultiplier).sp)) }
                                if (auth.currentUser != null && event.timestamp > 0) {
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Button(
                                        onClick = {
                                            val currentUid = auth.currentUser?.uid
                                            if (!currentUid.isNullOrEmpty()) {
                                                val reminder = CompetitionReminder(event.name, event.date, event.timestamp)
                                                db.collection("users").document(currentUid).update("reminders", FieldValue.arrayUnion(reminder)).addOnSuccessListener { Toast.makeText(context, "Reminder Set!", Toast.LENGTH_SHORT).show() }
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = primaryColor),
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.NotificationsActive, null, tint = Color.Black, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("SET REMINDER", color = Color.Black, fontWeight = FontWeight.Bold, style = TextStyle(fontSize = (14 * textSizeMultiplier).sp))
                                    }
                                }
                            }
                        }
                    }
                    item { Spacer(modifier = Modifier.height(24.dp)) }
                }
            }
        }
    }
}

@Composable
fun NewsScreen(primaryColor: Color, bgOpacity: Float, isSimplifiedUI: Boolean, textSizeMultiplier: Float) {
    val context = LocalContext.current
    val newsList = remember {
        listOf(
            NewsArticle("Architects of Ambition", "Official theme for 2025-2026.", "Feb 10, 2026", "https://www.fbla.org/news/", "NATIONAL"),
            NewsArticle("NLC Anaheim 2026", "Register for the NLC in Anaheim.", "Jan 25, 2026", "https://www.fbla.org/nlc/", "CONFERENCE"),
            NewsArticle("Competitive Events", "Updated guidelines for high school events.", "Dec 15, 2025", "https://www.fbla.org/high-school/competitive-events/", "HS"),
            NewsArticle("Scholarship Hub", "Over $250k in scholarships available.", "Nov 1, 2025", "https://www.fbla.org/high-school/program/scholarships/", "OPPORTUNITY")
        )
    }
    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgOpacity)))
        LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item {
                Spacer(modifier = Modifier.height(40.dp))
                Text(text = "THE FEED", style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 4.sp, fontWeight = FontWeight.Bold, color = primaryColor, fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp))
                Text(text = "Lead Link News", style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.Black, color = Color.White, fontSize = (MaterialTheme.typography.displaySmall.fontSize.value * textSizeMultiplier).sp))
                Spacer(modifier = Modifier.height(16.dp))
            }
            itemsIndexed(newsList) { _, article ->
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.1f)), shape = MaterialTheme.shapes.extraSmall, onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(article.url))) }) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = article.tag, color = primaryColor, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * textSizeMultiplier).sp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(text = article.date, style = MaterialTheme.typography.labelSmall.copy(fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * textSizeMultiplier).sp), color = Color.White.copy(alpha = 0.5f))
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = article.title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = (MaterialTheme.typography.titleMedium.fontSize.value * textSizeMultiplier).sp), color = Color.White)
                        Text(text = article.summary, style = MaterialTheme.typography.bodySmall.copy(fontSize = (MaterialTheme.typography.bodySmall.fontSize.value * textSizeMultiplier).sp), color = Color.White.copy(alpha = 0.7f))
                    }
                }
            }
        }
    }
}

@Composable
fun ResourcesScreen(primaryColor: Color, bgOpacity: Float, isSimplifiedUI: Boolean, textSizeMultiplier: Float) {
    val context = LocalContext.current
    val resourceList = remember {
        listOf(
            ResourceItem("Guidelines", "Requirements for all High School events.", "https://www.fbla.org/high-school/competitive-events/", Icons.AutoMirrored.Filled.Assignment),
            ResourceItem("HS 101 Toolkit", "Essential toolkit for high school management.", "https://www.fbla.org/media/2023/05/FBLA-High-School-101-Toolkit.pdf", Icons.AutoMirrored.Filled.LibraryBooks),
            ResourceItem("Brand Center", "Official logos and professional standards.", "https://www.fbla.org/brand-center/", Icons.Default.Brush),
            ResourceItem("Dress Code", "Attire standards for conferences.", "https://www.fbla.org/about/fbla/fbla-dress-code/", Icons.Default.Checkroom)
        )
    }
    Box(modifier = Modifier.fillMaxSize()) {
        if (!isSimplifiedUI) {
            Image(painter = painterResource(id = R.drawable.fbla_bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgOpacity)))
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp)) {
            Spacer(modifier = Modifier.height(64.dp))
            Text(text = "TOOLKIT", style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 4.sp, fontWeight = FontWeight.Bold, color = primaryColor, fontSize = (MaterialTheme.typography.labelLarge.fontSize.value * textSizeMultiplier).sp))
            Text(text = "Lead Link Resources", style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.Black, color = Color.White, fontSize = (MaterialTheme.typography.displaySmall.fontSize.value * textSizeMultiplier).sp))
            Spacer(modifier = Modifier.height(24.dp))
            LazyVerticalGrid(columns = GridCells.Fixed(2), horizontalArrangement = Arrangement.spacedBy(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxSize()) {
                itemsIndexed(resourceList) { _, resource ->
                    Card(modifier = Modifier.height(180.dp), colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.08f)), shape = RoundedCornerShape(16.dp), onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(resource.url))) }) {
                        Column(modifier = Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Icon(resource.icon, null, modifier = Modifier.size(40.dp), tint = primaryColor)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(text = resource.title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = (MaterialTheme.typography.titleMedium.fontSize.value * textSizeMultiplier).sp), color = Color.White, textAlign = TextAlign.Center)
                            Text(text = "VIEW", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Black, fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * textSizeMultiplier).sp), color = primaryColor)
                        }
                    }
                }
            }
        }
    }
}