const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineString } = require("firebase-functions/params");
const sgMail = require("@sendgrid/mail");

// Define SendGrid API key parameter
const sendgridKey = defineString("SENDGRID_API_KEY");

exports.send2FAEmail = onCall(async (request) => {
  // Initialize SendGrid with the API key
  sgMail.setApiKey(sendgridKey.value());

  // Verify user is authenticated
  if (!request.auth) {
    throw new HttpsError(
      "unauthenticated",
      "User must be authenticated"
    );
  }

  const { email, code } = request.data;

  // Validate inputs
  if (!email || !code) {
    throw new HttpsError(
      "invalid-argument",
      "Email and code are required"
    );
  }

  const msg = {
    to: email,
    from: "leadlink2026@gmail.com",
    subject: "Your Lead Link Verification Code",
    text: `Your verification code is: ${code}. This code will expire in 5 minutes.`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f5f5f5;">
        <div style="background-color: #000D1A; padding: 30px; border-radius: 10px; text-align: center;">
          <h1 style="color: #FFB800; margin: 0; font-size: 28px;">Lead Link</h1>
          <p style="color: white; margin-top: 10px;">FBLA Mobile App</p>
        </div>
        <div style="background-color: white; padding: 30px; border-radius: 10px; margin-top: 20px;">
          <p style="color: #333; font-size: 16px;">Your verification code is:</p>
          <div style="background-color: #FFB800; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0;">
            <h1 style="color: #000; font-size: 36px; letter-spacing: 8px; margin: 0;">${code}</h1>
          </div>
          <p style="color: #666; font-size: 14px;">This code will expire in 5 minutes.</p>
          <p style="color: #999; font-size: 12px; margin-top: 30px; border-top: 1px solid #eee; padding-top: 20px;">
            If you didn't request this code, please ignore this email.<br>
            This is an automated message from Lead Link FBLA Mobile App.
          </p>
        </div>
      </div>
    `,
  };

  try {
    await sgMail.send(msg);
    console.log("Email sent successfully to:", email);
    return { success: true, message: "Email sent successfully" };
  } catch (error) {
    console.error("SendGrid error:", error.response ? error.response.body : error);
    throw new HttpsError("internal", "Failed to send email");
  }
});
